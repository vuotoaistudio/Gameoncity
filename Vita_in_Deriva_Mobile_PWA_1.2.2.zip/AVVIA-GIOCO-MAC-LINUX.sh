#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js LTS 22 o superiore è necessario. Installa Node.js LTS da https://nodejs.org/"
  exit 1
fi
printf '\nVita in Deriva: http://localhost:8000\nIl server multiplayer resterà attivo in questa finestra.\n\n'
node server.mjs
