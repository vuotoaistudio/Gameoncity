@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js non trovato.
  echo Installa Node.js LTS da https://nodejs.org/ e riapri questo file.
  pause
  exit /b 1
)
echo.
echo  VITA IN DERIVA - avvio gioco e multiplayer locale
 echo  Si aprira http://localhost:8000 nel browser.
echo  Lascia questa finestra aperta mentre giochi.
echo.
start "" cmd /c "timeout /t 2 >nul & start http://localhost:8000"
node server.mjs
if errorlevel 1 (
 echo.
 echo Il server si e' fermato con un errore.
 pause
)
endlocal
