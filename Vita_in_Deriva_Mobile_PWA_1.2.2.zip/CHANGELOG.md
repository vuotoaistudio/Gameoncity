# Changelog

## 1.2.2 — Mobile/PWA delivery
- Added installable PWA manifest, app icons, standalone/fullscreen metadata and service-worker caching.
- Improved mobile touch control layout, safe-area support and compact landscape controls.
- Added in-game install guidance for Android browsers and iOS Safari.
- Added Render Blueprint for a public HTTPS/WSS deployment.
- Added gzip compression for HTML, JavaScript, manifests and JSON to reduce mobile download size.
- Versioned server health endpoint for smoke testing.

## 1.2.1
- Local multiplayer WebSocket server, diagnostics and interface refinements.
