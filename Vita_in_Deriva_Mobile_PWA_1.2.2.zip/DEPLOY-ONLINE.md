# Pubblicare Vita in Deriva per giocare dal telefono

## Giocare subito sulla stessa Wi-Fi
1. Avvia `AVVIA-GIOCO-WINDOWS.bat` sul PC.
2. Lascia aperta la finestra del server. Leggi la riga `Rete locale`, ad esempio `http://192.168.1.20:8000`.
3. Collega il telefono alla stessa Wi-Fi e apri quell'indirizzo in Chrome o Safari.
4. Se Windows chiede l'autorizzazione al firewall, consenti Node.js sulle reti private. Non serve HTTPS per la prova sulla rete locale, ma il browser potrebbe non consentire l'installazione PWA su un IP HTTP.

## Pubblicare su Internet (necessario per gli amici fuori casa)
Il progetto include `render.yaml` per un servizio Node su Render, con HTTPS e WebSocket sicuro forniti dalla piattaforma. Per pubblicare serve un account e un repository Git remoto: non è possibile creare il tuo deployment pubblico senza autorizzare l'accesso al tuo account.

1. Carica l'intera cartella del progetto in un repository GitHub. Includi `server.mjs`, `package.json`, `render.yaml`, `index.html`, `manifest.webmanifest`, `sw.js`, `icons/`, `src/`, `lib/` e `data/`.
2. In Render scegli **New + > Blueprint**, collega il repository e conferma il servizio descritto in `render.yaml`.
3. Attendi il completamento del deploy. Il dominio `https://...onrender.com` serve il gioco e usa WSS per il multiplayer.
4. Apri il dominio dal telefono. Android: menu Chrome > Installa app/Aggiungi a schermata Home. iPhone: Safari > Condividi > Aggiungi alla schermata Home.

Nota: il piano gratuito può andare in sospensione quando è inattivo; il primo avvio può essere lento e le stanze in memoria spariscono al riavvio del server. Il multiplayer richiede il server attivo e non funziona con il solo hosting statico. La chat vocale può richiedere un relay TURN per alcune reti.
