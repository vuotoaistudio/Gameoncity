# Vita in Deriva — 1.2.2

Gioco 3D esplorativo in Three.js ambientato in città italiane, con storia dinamica, personaggi, traffico, guida, fotografia, meteo, negozi, case, personalizzazione e multiplayer a stanze.

## Giocare dal telefono

Per provarlo subito sulla stessa Wi-Fi, avvia il server sul PC e apri sul telefono l’indirizzo `Rete locale` che compare nel terminale. Il gioco usa controlli touch, qualità grafica mobile, cache degli asset e dei dati visitati dopo un primo accesso online e può essere installato come PWA una volta pubblicato via HTTPS. Vedi [DEPLOY-ONLINE.md](DEPLOY-ONLINE.md) per pubblicazione Internet e installazione.

## Avvio su Windows

1. Installa Node.js LTS 22 o superiore da <https://nodejs.org/>.
2. Estrai **tutto** lo ZIP in una cartella normale.
3. Fai doppio clic su `AVVIA-GIOCO-WINDOWS.bat`.
4. Apri `http://localhost:8000` se non si apre automaticamente.
5. Lascia aperta la finestra del terminale mentre giochi.

Se la porta 8000 è già occupata, chiudi l'altro server o avvia con `set PORT=8123` (Windows CMD) prima di `node server.mjs`; poi apri `http://localhost:8123`.

## Avvio su macOS / Linux

```sh
chmod +x AVVIA-GIOCO-MAC-LINUX.sh
./AVVIA-GIOCO-MAC-LINUX.sh
```

Oppure `npm start`. Non sono richieste dipendenze npm esterne; serve Node.js 22+. Il server comprime automaticamente file HTML, JavaScript e JSON per ridurre i tempi di download su rete mobile.

## Multiplayer

**Sulla stessa rete o sullo stesso computer:** avvia il gioco e crea una stanza. Condividi il codice di 5 caratteri e fai entrare gli altri selezionando la stessa città. Per un test locale puoi aprire un secondo browser o una finestra anonima.

**Con amici su Internet:** lo ZIP è pronto per il deployment su un hosting che supporti Node.js e WebSocket. Pubblica l'intera cartella e configura il servizio per eseguire `npm start` con la porta `PORT` assegnata dall'hosting. Il servizio deve esporre HTTPS e WebSocket sicuro (WSS) in produzione. Il solo hosting statico non basta.

La chat vocale usa WebRTC con STUN pubblico; alcune reti possono richiedere un servizio TURN separato. Non è incluso un relay TURN. Le stanze e i loro codici risiedono in memoria e vengono eliminate quando restano vuote o il server si riavvia. Non c'è un account persistente né matchmaking globale.

## Controlli principali

- `W A S D` / frecce: movimento
- `Shift`: correre
- Mouse: guardare
- `Spazio`: saltare
- `E`: interagire
- `F`: fotocamera
- `V`: cambiare visuale
- `P`: telefono
- `Tab`: album
- `Esc`: pausa
- `F3`: diagnostica FPS / draw calls / triangoli / rete / DPR

## Fluidità e grafica

Nelle impostazioni usa qualità **Automatica** come punto di partenza. Se il frame rate è instabile, prova **Leggera** o **Media**. La qualità alta dipende da GPU, browser e risoluzione. F3 mostra dati diagnostici durante il gioco. Non esiste un FPS garantito per ogni dispositivo.

L'interfaccia usa animazioni discrete, stati di caricamento, feedback ai controlli, layout adattivo e rispetto della preferenza di sistema per la riduzione del movimento.

## Verifiche tecniche

```sh
npm run check
```

Il comando controlla la sintassi dei moduli principali e la presenza degli import relativi. È stato inoltre eseguito un test d'integrazione locale con due client WebSocket: creazione/ingresso stanza, chat e sincronizzazione dello stato. La resa grafica e gli FPS vanno verificati anche sul dispositivo finale.

## Note

- I progressi single-player sono salvati nel browser/dispositivo in uso.
- Meteo e dati cartografici possono richiedere Internet.
- Il gioco contiene funzioni opzionali legate a sostanze e violenza; le relative impostazioni sono disponibili nel gioco.
