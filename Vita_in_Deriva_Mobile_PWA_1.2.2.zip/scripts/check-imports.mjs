import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const missing = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (!['.git', 'node_modules'].includes(entry.name)) walk(file);
      continue;
    }
    if (!/\.(?:js|mjs|html)$/.test(entry.name)) continue;
    const source = fs.readFileSync(file, 'utf8');
    for (const match of source.matchAll(/(?:from\s*|import\s*\()\s*['"](\.[^'"]+)['"]/g)) {
      const target = path.resolve(path.dirname(file), match[1]);
      if (!fs.existsSync(target)) missing.push(`${path.relative(root, file)} -> ${match[1]}`);
    }
  }
}
walk(root);
if (missing.length) {
  console.error('Import relativi mancanti:');
  for (const item of missing) console.error(` - ${item}`);
  process.exitCode = 1;
} else console.log('Import relativi: OK');
