import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const fail = (message) => { console.error(`PWA check failed: ${message}`); process.exitCode = 1; };
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
let manifest;
try { manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.webmanifest'), 'utf8')); }
catch { fail('manifest.webmanifest is missing or invalid JSON'); process.exit(); }
for (const field of ['name', 'short_name', 'start_url', 'scope', 'display', 'icons']) if (!manifest[field]) fail(`manifest is missing ${field}`);
if (!html.includes('rel="manifest"') || !html.includes('id="btnInstall"') || !html.includes("navigator.serviceWorker.register")) fail('HTML PWA integration is incomplete');
const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');
const match = sw.match(/const CORE_ASSETS = (\[.*?\]);/s);
if (!match) fail('service worker precache list is missing');
else {
  const assets = JSON.parse(match[1]);
  for (const asset of assets) {
    const target = asset === '/' ? path.join(root, 'index.html') : path.join(root, asset.replace(/^\//, ''));
    if (!fs.existsSync(target)) fail(`missing precache asset ${asset}`);
  }
  console.log(`PWA cache: ${assets.length} assets verified`);
}
for (const icon of manifest.icons || []) {
  const file = path.join(root, icon.src.replace(/^\.\//, ''));
  if (!fs.existsSync(file)) fail(`missing app icon ${icon.src}`);
}
if (!html.includes('@media (pointer: coarse)') || !html.includes('grid-template-columns: repeat(3')) fail('mobile touch layout is missing');
if (!fs.existsSync(path.join(root, 'render.yaml'))) fail('Render deploy blueprint is missing');
if (!process.exitCode) console.log(`PWA check: OK (${manifest.display}, ${manifest.orientation}, ${manifest.icons.length} icons)`);
