import { spawn } from 'node:child_process';
import net from 'node:net';
import { setTimeout as delay } from 'node:timers/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
async function freePort() {
  const server = net.createServer();
  await new Promise((resolve, reject) => server.once('error', reject).listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  await new Promise((resolve) => server.close(resolve));
  return port;
}
function waitFor(ws, predicate, timeout = 3000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { ws.removeEventListener('message', onMessage); reject(new Error('timeout WebSocket')); }, timeout);
    const onMessage = (event) => {
      try { const data = JSON.parse(event.data); if (predicate(data)) { clearTimeout(timer); ws.removeEventListener('message', onMessage); resolve(data); } } catch { }
    };
    ws.addEventListener('message', onMessage);
  });
}
const port = await freePort();
const server = spawn(process.execPath, ['server.mjs'], { cwd: root, env: { ...process.env, PORT: String(port), HOST: '127.0.0.1' }, stdio: 'ignore' });
let a, b;
try {
  let healthy = false;
  for (let i = 0; i < 50; i++) {
    try { const r = await fetch(`http://127.0.0.1:${port}/api/health`); if (r.ok) { healthy = true; break; } } catch { }
    await delay(100);
  }
  if (!healthy) throw new Error('server did not start');
  a = new WebSocket(`ws://127.0.0.1:${port}/ws`); b = new WebSocket(`ws://127.0.0.1:${port}/ws`);
  await Promise.all([new Promise((r, j) => { a.onopen = r; a.onerror = j; }), new Promise((r, j) => { b.onopen = r; b.onerror = j; })]);
  a.send(JSON.stringify({ t: 'hello', mode: 'create', city: 'fi', name: 'Test A', look: null, anchors: [] }));
  const joinedA = await waitFor(a, (m) => m.t === 'joined');
  const peerJoin = waitFor(a, (m) => m.t === 'peer' && m.ev === 'join');
  b.send(JSON.stringify({ t: 'hello', mode: 'join', city: 'fi', code: joinedA.code, name: 'Test B', look: null, anchors: [] }));
  const joinedB = await waitFor(b, (m) => m.t === 'joined'); await peerJoin;
  const snap = waitFor(b, (m) => m.t === 'snap');
  a.send(JSON.stringify({ t: 'state', p: [1, 2, 3], r: [0.2, 0.3], f: 0 }));
  const received = await snap;
  if (joinedB.players.length !== 2 || received.ps?.[0]?.p?.[0] !== 1) throw new Error('state not synchronised');
  const chat = waitFor(b, (m) => m.t === 'chat'); a.send(JSON.stringify({ t: 'chat', text: 'test online' }));
  const msg = await chat;
  if (msg.text !== 'test online') throw new Error('chat not delivered');
  console.log(`Multiplayer smoke test: OK (${joinedB.players.length} clients, room ${joinedA.code}, sync + chat)`);
} finally {
  try { a?.close(); } catch { }
  try { b?.close(); } catch { }
  server.kill('SIGTERM');
}
