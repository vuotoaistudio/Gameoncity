import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { createGzip } from 'node:zlib';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 8000);
const HOST = process.env.HOST || '0.0.0.0';
const VERSION = '1.2.2';
const MAX_FRAME = 262144;
const MAX_PLAYERS = 12;
const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const COLORS = ['#f2b8c6', '#8fd3c7', '#f2b36b', '#b9a7f2', '#9fd38f', '#f28f8f', '#8fb8f2', '#e6d38f'];
const rooms = new Map();
const clients = new Set();

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json; charset=utf-8', '.woff': 'font/woff', '.woff2': 'font/woff2', '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.wav': 'audio/wav'
};

function json(res, status, value) {
  const body = JSON.stringify(value);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Length': Buffer.byteLength(body), 'X-Content-Type-Options': 'nosniff' });
  res.end(body);
}
function clean(value, limit = 20) {
  return [...String(value ?? '')].filter((ch) => {
    const c = ch.codePointAt(0);
    return !(c < 32 || (c > 126 && c < 160) || (c >= 0x200b && c <= 0x200f) || (c >= 0x2028 && c <= 0x202e) || (c >= 0x2060 && c <= 0x206f) || c === 0xfeff);
  }).join('').trim().slice(0, limit);
}
function colorFor(id) { let h = 0; for (const c of String(id)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return COLORS[h % COLORS.length]; }
function newCode() { let code = ''; for (let i = 0; i < 5; i++) code += ALPHA[Math.floor(Math.random() * ALPHA.length)]; return code; }
function roomKey(city, code) { return `${city}:${code}`; }
function send(client, value) {
  if (!client || client.closed || !client.socket || client.socket.destroyed) return;
  const payload = Buffer.from(JSON.stringify(value));
  let header;
  if (payload.length < 126) { header = Buffer.from([0x81, payload.length]); }
  else if (payload.length < 65536) { header = Buffer.alloc(4); header[0] = 0x81; header[1] = 126; header.writeUInt16BE(payload.length, 2); }
  else { header = Buffer.alloc(10); header[0] = 0x81; header[1] = 127; header.writeBigUInt64BE(BigInt(payload.length), 2); }
  try { client.socket.write(Buffer.concat([header, payload])); } catch { }
}
function broadcast(room, value, except = null) { for (const c of room.players.values()) if (c !== except) send(c, value); }
function hostId(room) { return room.players.keys().next().value || null; }
function roomPlayers(room) {
  return [...room.players.values()].map((c) => ({ id: c.id, name: c.name, color: c.color, look: c.look }));
}
function roomSummary(room) {
  return { code: room.code, city: room.city, names: [...room.players.values()].map((p) => p.name), at: room.createdAt, count: room.players.size };
}
function closeClient(c) {
  if (!c || c.closed) return;
  c.closed = true;
  clients.delete(c);
  const room = c.room;
  if (room) {
    room.players.delete(c.id);
    c.room = null;
    if (room.players.size === 0) rooms.delete(room.key);
    else {
      room.host = hostId(room);
      broadcast(room, { t: 'peer', ev: 'leave', id: c.id, name: c.name, host: room.host });
    }
  }
}
function joinRoom(c, msg) {
  const city = clean(msg.city, 24).toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 24) || 'fi';
  const mode = msg.mode === 'create' ? 'create' : 'join';
  let code = clean(msg.code, 5).toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (mode === 'create') {
    for (let tries = 0; tries < 30; tries++) {
      if (!code || rooms.has(roomKey(city, code))) code = newCode();
      else break;
    }
    if (rooms.has(roomKey(city, code))) return send(c, { t: 'error', message: 'Non riesco a creare una stanza libera. Riprova.' });
  } else {
    if (!/^[A-Z0-9]{5}$/.test(code)) return send(c, { t: 'error', message: 'Il codice deve avere 5 caratteri.' });
    if (!rooms.has(roomKey(city, code))) return send(c, { t: 'error', message: 'Stanza non trovata. Controlla il codice e la città selezionata.' });
  }
  const key = roomKey(city, code);
  let room = rooms.get(key);
  if (!room) { room = { key, city, code, players: new Map(), createdAt: Date.now(), anchors: new Set(), host: null }; rooms.set(key, room); }
  if (room.players.size >= MAX_PLAYERS) return send(c, { t: 'error', message: `Stanza piena (massimo ${MAX_PLAYERS} giocatori).` });
  if (c.room) closeClient(c);
  c.id = crypto.randomUUID().slice(0, 12);
  c.name = clean(msg.name, 20) || 'Viandante';
  c.look = msg.look && typeof msg.look === 'object' ? msg.look : null;
  c.city = city; c.color = colorFor(c.id); c.room = room; c.state = null; c.lastState = 0; c.lastChat = 0; c.talking = false;
  const incoming = Array.isArray(msg.anchors) ? msg.anchors.slice(-260) : [];
  c.anchors = new Set(incoming.filter((v) => Number.isInteger(v) && v >= 0 && v < 1_000_000));
  for (const v of c.anchors) room.anchors.add(v);
  room.players.set(c.id, c);
  room.host = hostId(room);
  const anchors = [...room.anchors].slice(-1040);
  send(c, { t: 'joined', code: room.code, you: c.id, host: room.host, players: roomPlayers(room), anchors });
  broadcast(room, { t: 'peer', ev: 'join', id: c.id, name: c.name, color: c.color, look: c.look, host: room.host }, c);
}
function validVector(v, n) { return Array.isArray(v) && v.length === n && v.every((x) => typeof x === 'number' && Number.isFinite(x) && Math.abs(x) < 1_000_000); }
function handleMessage(c, msg) {
  if (!msg || typeof msg !== 'object' || typeof msg.t !== 'string') return;
  if (msg.t === 'hello') return joinRoom(c, msg);
  if (msg.t === 'leave') return closeClient(c);
  const room = c.room;
  if (!room || !room.players.has(c.id)) return;
  if (msg.t === 'state') {
    const now = Date.now();
    if (now - c.lastState < 45) return;
    if (!validVector(msg.p, 3) || !validVector(msg.r, 2)) return;
    c.lastState = now;
    c.state = { id: c.id, p: msg.p.map((v) => Math.round(v * 100) / 100), r: msg.r.map((v) => Math.round(v * 1000) / 1000), f: Number.isInteger(msg.f) ? msg.f | 0 : 0 };
    broadcast(room, { t: 'snap', ps: [c.state] }, c);
  } else if (msg.t === 'chat') {
    const now = Date.now();
    if (now - c.lastChat < 450) return;
    const text = clean(msg.text, 140);
    if (!text) return;
    c.lastChat = now;
    broadcast(room, { t: 'chat', id: c.id, name: c.name, text }, c);
  } else if (msg.t === 'rename') {
    c.name = clean(msg.name, 20) || 'Viandante';
    broadcast(room, { t: 'peer', ev: 'rename', id: c.id, name: c.name, host: room.host }, c);
  } else if (msg.t === 'look') {
    c.look = msg.look && typeof msg.look === 'object' ? msg.look : null;
    broadcast(room, { t: 'peer', ev: 'look', id: c.id, look: c.look, host: room.host }, c);
  } else if (msg.t === 'anchor') {
    const bids = Array.isArray(msg.bids) ? msg.bids.filter((v) => Number.isInteger(v) && v >= 0 && v < 1_000_000).slice(0, 64) : [];
    for (const bid of bids) { room.anchors.add(bid); c.anchors.add(bid); }
    if (bids.length) broadcast(room, { t: 'anchor', bids, by: c.id }, c);
  } else if (msg.t === 'unanchor') {
    const bids = Array.isArray(msg.bids) ? msg.bids.filter((v) => Number.isInteger(v) && v >= 0 && v < 1_000_000).slice(0, 64) : [];
    for (const bid of bids) { room.anchors.delete(bid); c.anchors.delete(bid); }
    if (bids.length) broadcast(room, { t: 'unanchor', bids, by: c.id }, c);
  } else if (msg.t === 'voice') {
    c.talking = !!msg.on;
    broadcast(room, { t: 'voice', id: c.id, on: c.talking }, c);
  } else if (msg.t === 'rtc') {
    const to = String(msg.to || '');
    const target = room.players.get(to);
    if (target && msg.data && typeof msg.data === 'object') send(target, { t: 'rtc', from: c.id, data: msg.data });
  }
}

function parseFrames(c) {
  while (c.buffer.length >= 2) {
    const b0 = c.buffer[0], b1 = c.buffer[1];
    const fin = !!(b0 & 0x80), opcode = b0 & 0x0f, masked = !!(b1 & 0x80);
    let length = b1 & 0x7f, offset = 2;
    if (!masked) { c.socket.destroy(); return; }
    if (length === 126) { if (c.buffer.length < 4) return; length = c.buffer.readUInt16BE(2); offset = 4; }
    else if (length === 127) { if (c.buffer.length < 10) return; const n = c.buffer.readBigUInt64BE(2); if (n > BigInt(MAX_FRAME)) { c.socket.destroy(); return; } length = Number(n); offset = 10; }
    if (length > MAX_FRAME) { c.socket.destroy(); return; }
    if (c.buffer.length < offset + 4 + length) return;
    const mask = c.buffer.subarray(offset, offset + 4); offset += 4;
    const payload = Buffer.from(c.buffer.subarray(offset, offset + length));
    for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
    c.buffer = c.buffer.subarray(offset + length);
    if (opcode === 0x8) { try { c.socket.end(Buffer.from([0x88, 0x00])); } catch {} closeClient(c); return; }
    if (opcode === 0x9) { c.socket.write(Buffer.from([0x8a, payload.length, ...payload])); continue; }
    if (opcode === 0xA) continue;
    if (opcode === 0x1 && fin) {
      try { handleMessage(c, JSON.parse(payload.toString('utf8'))); } catch { send(c, { t: 'error', message: 'Messaggio non valido.' }); }
    } else if (opcode === 0x1 && !fin) { c.fragmentOpcode = opcode; c.fragments = [payload]; }
    else if (opcode === 0x0 && c.fragments) {
      c.fragments.push(payload);
      if (fin) { const complete = Buffer.concat(c.fragments); c.fragments = null; try { handleMessage(c, JSON.parse(complete.toString('utf8'))); } catch { send(c, { t: 'error', message: 'Messaggio non valido.' }); } }
    } else if (opcode !== 0x2) { /* ignora opcode sconosciuti */ }
  }
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  if (url.pathname === '/api/health') return json(res, 200, { ok: true, multiplayer: true, version: VERSION, activeRooms: rooms.size, players: clients.size });
  if (url.pathname === '/api/rooms') {
    const city = clean(url.searchParams.get('city'), 24).toLowerCase();
    const list = [...rooms.values()].filter((r) => !city || r.city === city).map(roomSummary).sort((a, b) => b.at - a.at);
    return json(res, 200, { rooms: list });
  }
  let pathname;
  try { pathname = decodeURIComponent(url.pathname); } catch { return json(res, 400, { error: 'URL non valida' }); }
  if (pathname === '/') pathname = '/index.html';
  const file = path.resolve(ROOT, '.' + pathname);
  if (!file.startsWith(ROOT + path.sep) && file !== path.join(ROOT, 'index.html')) return json(res, 403, { error: 'Accesso negato' });
  fs.stat(file, (err, stat) => {
    if (err || !stat.isFile()) return json(res, 404, { error: 'File non trovato' });
    const ext = path.extname(file).toLowerCase();
    const compressible = /\.(?:html|js|mjs|json|webmanifest|svg|css)$/.test(ext);
    const acceptsGzip = compressible && /\bgzip\b/.test(String(req.headers['accept-encoding'] || ''));
    const headers = {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': ['.html', '.json', '.webmanifest', '.js', '.mjs'].includes(ext) ? 'no-cache' : 'public, max-age=3600',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      'Cross-Origin-Opener-Policy': 'same-origin-allow-popups',
      'Vary': 'Accept-Encoding'
    };
    if (acceptsGzip) headers['Content-Encoding'] = 'gzip';
    else headers['Content-Length'] = stat.size;
    res.writeHead(200, headers);
    if (req.method === 'HEAD') return res.end();
    const stream = fs.createReadStream(file);
    stream.on('error', () => { if (!res.headersSent) res.writeHead(500); res.end(); });
    if (acceptsGzip) stream.pipe(createGzip({ level: 6 })).pipe(res);
    else stream.pipe(res);
  });
});

server.on('upgrade', (req, socket) => {
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  const key = req.headers['sec-websocket-key'];
  if (url.pathname !== '/ws' || req.headers.upgrade?.toLowerCase() !== 'websocket' || !key) { socket.write('HTTP/1.1 404 Not Found\r\n\r\n'); socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  const c = { socket, id: null, name: 'Viandante', room: null, city: 'fi', buffer: Buffer.alloc(0), fragments: null, closed: false };
  clients.add(c);
  socket.on('data', (chunk) => { c.buffer = Buffer.concat([c.buffer, chunk]); parseFrames(c); });
  socket.on('close', () => closeClient(c));
  socket.on('end', () => closeClient(c));
  socket.on('error', () => closeClient(c));
});

server.listen(PORT, HOST, () => {
  const interfaces = Object.values(os.networkInterfaces()).flat().filter((v) => v && v.family === 'IPv4' && !v.internal).map((v) => v.address);
  console.log(`\nVita in Deriva ${VERSION}`);
  console.log(`Locale: http://localhost:${PORT}`);
  if (interfaces.length) console.log(`Rete locale: ${interfaces.map((a) => `http://${a}:${PORT}`).join(' · ')}`);
  console.log(`Server multiplayer WebSocket attivo su /ws · massimo ${MAX_PLAYERS} giocatori per stanza`);
  console.log('Per consentire agli amici di collegarsi via Internet, pubblica questo progetto su un hosting Node con HTTPS/WSS.\n');
});

process.on('SIGINT', () => { for (const c of clients) { try { c.socket.destroy(); } catch {} } server.close(() => process.exit(0)); });
