// Riflesso planare dell'acqua: la città vista da sotto la superficie del canale, a risoluzione ridotta.
// Stessa tecnica di Reflector di three.js (camera specchiata + piano di taglio obliquo).
import * as THREE from 'three';

export function createMirror(renderer, planeY) {
  const rt = new THREE.WebGLRenderTarget(4, 4, { type: THREE.HalfFloatType, depthBuffer: true });
  rt.texture.generateMipmaps = false;
  const cam = new THREE.PerspectiveCamera();
  const textureMatrix = new THREE.Matrix4();
  const normal = new THREE.Vector3(0, 1, 0);
  const planePos = new THREE.Vector3(0, planeY, 0);
  const camPos = new THREE.Vector3(), rot = new THREE.Matrix4(), lookAt = new THREE.Vector3(), view = new THREE.Vector3(), target = new THREE.Vector3();
  const plane = new THREE.Plane(), clip = new THREE.Vector4(), q = new THREE.Vector4();
  const uniforms = { tReflect: { value: rt.texture }, uReflMatrix: { value: textureMatrix }, uReflOn: { value: 0 } };
  let scale = 0.5;

  return {
    uniforms, rt,
    setScale(s) { scale = s; },
    setSize(w, h) { rt.setSize(Math.max(4, Math.floor(w * scale)), Math.max(4, Math.floor(h * scale))); },
    // hide: oggetti da nascondere nel riflesso (l'acqua stessa, la pioggia)
    render(scene, camera, hide) {
      camPos.setFromMatrixPosition(camera.matrixWorld);
      view.subVectors(planePos, camPos);
      planePos.x = camPos.x; planePos.z = camPos.z;
      if (camPos.y < planeY) { uniforms.uReflOn.value = 0; return; }
      rot.extractRotation(camera.matrixWorld);
      lookAt.set(0, 0, -1).applyMatrix4(rot).add(camPos);
      view.subVectors(planePos, camPos).reflect(normal).negate().add(planePos);
      target.subVectors(planePos, lookAt).reflect(normal).negate().add(planePos);
      cam.position.copy(view);
      cam.up.set(0, 1, 0).applyMatrix4(rot).reflect(normal);
      cam.lookAt(target);
      cam.far = Math.min(camera.far, 600);
      cam.updateMatrixWorld();
      cam.projectionMatrix.copy(camera.projectionMatrix);
      textureMatrix.set(0.5, 0, 0, 0.5, 0, 0.5, 0, 0.5, 0, 0, 0.5, 0.5, 0, 0, 0, 1);
      textureMatrix.multiply(cam.projectionMatrix).multiply(cam.matrixWorldInverse);
      // piano di taglio obliquo: niente di ciò che sta sott'acqua entra nel riflesso
      plane.setFromNormalAndCoplanarPoint(normal, planePos).applyMatrix4(cam.matrixWorldInverse);
      clip.set(plane.normal.x, plane.normal.y, plane.normal.z, plane.constant);
      const P = cam.projectionMatrix.elements;
      q.x = (Math.sign(clip.x) + P[8]) / P[0];
      q.y = (Math.sign(clip.y) + P[9]) / P[5];
      q.z = -1.0;
      q.w = (1.0 + P[10]) / P[14];
      clip.multiplyScalar(2.0 / clip.dot(q));
      P[2] = clip.x; P[6] = clip.y; P[10] = clip.z + 1.0; P[14] = clip.w;

      const vis = hide.map((o) => o && o.visible);
      hide.forEach((o) => { if (o) o.visible = false; });
      const prevRT = renderer.getRenderTarget(), prevAuto = renderer.shadowMap.autoUpdate;
      renderer.shadowMap.autoUpdate = false;
      renderer.setRenderTarget(rt);
      renderer.clear();
      renderer.render(scene, cam);
      renderer.setRenderTarget(prevRT);
      renderer.shadowMap.autoUpdate = prevAuto;
      hide.forEach((o, i) => { if (o) o.visible = vis[i]; });
      uniforms.uReflOn.value = 1;
    },
    off() { uniforms.uReflOn.value = 0; }
  };
}
