// Post-elaborazione: bagliore delle luci, livello "sogno" (deriva, Ambra, postumi, blackout, flash), tone mapping.
import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';

const DreamShader = {
  uniforms: {
    tDiffuse: { value: null }, uTime: { value: 0 }, uRes: { value: new THREE.Vector2(1, 1) },
    uDream: { value: 0 }, uDrunk: { value: 0 }, uHangover: { value: 0 }, uBlack: { value: 0 }, uFlash: { value: 0 },
    uSafe: { value: 0 }, uInside: { value: 0 }, uWhite: { value: 0 },
    uStim: { value: 0 }, uOpi: { value: 0 }, uWeed: { value: 0 }, uTrip: { value: 0 }, uBad: { value: 0 }, uNod: { value: 0 }, uTired: { value: 0 }
  },
  vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
  fragmentShader: /* glsl */`
    uniform sampler2D tDiffuse; uniform float uTime, uDream, uDrunk, uHangover, uBlack, uFlash, uSafe, uInside, uWhite; uniform vec2 uRes;
    uniform float uStim, uOpi, uWeed, uTrip, uBad, uNod, uTired;
    vec3 hueRot(vec3 c, float a){ const vec3 k = vec3(0.57735); float ca = cos(a); return c * ca + cross(k, c) * sin(a) + k * dot(k, c) * (1.0 - ca); }
    varying vec2 vUv;
    float rnd(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233)) + uTime) * 43758.5453); }
    vec3 grab(vec2 uv){ return texture2D(tDiffuse, uv).rgb; }
    void main(){
      float safe = 1.0 - uSafe * 0.8;
      vec2 uv = vUv;
      float dk = uDrunk * safe;
      uv += vec2(sin(uv.y * 6.0 + uTime * 1.1), cos(uv.x * 5.0 + uTime * 0.9)) * 0.004 * dk;
      // nel sogno le linee respirano piano
      uv += vec2(sin(uv.y * 3.0 + uTime * 0.5), cos(uv.x * 2.0 + uTime * 0.4)) * 0.0015 * uInside * safe;
      // Francobollo: le linee respirano; Kokka: il battito spinge l'immagine
      float trip = uTrip * safe;
      uv += vec2(sin(uv.y * 9.0 + uTime * 1.3), sin(uv.x * 7.0 - uTime * 1.1)) * 0.006 * trip * (1.0 + uBad);
      float beat = pow(max(0.0, sin(uTime * 10.0)), 12.0) * uStim * safe;
      uv = 0.5 + (uv - 0.5) * (1.0 - beat * 0.012);
      vec2 c = uv - 0.5;
      float ab = (0.001 + uDream * 0.006 + uInside * 0.004 + trip * 0.012) * safe * dot(c, c) * 4.0;
      vec3 col = vec3(grab(uv + c * ab).r, grab(uv).g, grab(uv - c * ab).b);
      if (dk > 0.01) {
        vec2 off = vec2(0.012 + 0.006 * sin(uTime * 0.8), 0.003 * sin(uTime * 1.3)) * smoothstep(0.2, 1.0, uDrunk) * safe;
        vec3 ghost = grab(uv + off) * 0.5 + grab(uv - off * 0.6) * 0.5;
        col = mix(col, ghost, 0.45 * smoothstep(0.2, 0.9, uDrunk));
        col *= vec3(1.06, 1.0, 0.9);
      }
      // Lyn: morbido e caldo
      if (uOpi > 0.01) { vec2 px = 2.0 / uRes; vec3 soft = (grab(uv + px) + grab(uv - px) + grab(uv + vec2(px.x, -px.y)) + grab(uv - vec2(px.x, -px.y))) * 0.25; col = mix(col, soft * vec3(1.08, 0.98, 0.86), uOpi * 0.7); }
      col *= 1.0 + uHangover * 0.6;
      float lum = dot(col, vec3(0.3, 0.59, 0.11));
      col = mix(col, vec3(lum) * 1.1 + 0.05, uHangover * 0.35);
      // tinta del sogno: pastelli, neri sollevati
      vec3 dreamTint = col * vec3(1.05, 0.95, 1.08) + vec3(0.025, 0.012, 0.035);
      col = mix(col, dreamTint, clamp(uDream * 0.7 + uInside * 0.6, 0.0, 1.0));
      // Fumo: colori più vicini; Kokka: contrasto; Francobollo: i colori girano
      float l2 = dot(col, vec3(0.3, 0.59, 0.11));
      col = mix(vec3(l2), col, 1.0 + uWeed * 0.45 + uStim * 0.15);
      col = (col - 0.18) * (1.0 + uStim * 0.25) + 0.18;
      col = mix(col, hueRot(col, uTime * 0.6 + length(c) * 6.0), trip * 0.55);
      col = mix(col, col * vec3(1.15, 0.6, 0.6) * 0.8, uBad * 0.5);
      col = mix(col, vec3(dot(col, vec3(0.3, 0.59, 0.11))), uTired * 0.5);
      float tunnel = uStim * 0.6 + uTired * 0.5 + uOpi * 0.3;
      float vig = smoothstep(0.9 - tunnel * 0.35, 0.25 - tunnel * 0.15, length(c) * (1.0 + uHangover * 0.5 * (0.5 + 0.5 * sin(uTime * 2.2))));
      col *= mix(0.7, 1.0, vig);
      col += (rnd(vUv * uRes) - 0.5) * (0.02 + uDream * 0.02 + uInside * 0.025) * (0.4 + lum);
      col = mix(col, vec3(1.6), uFlash * safe);
      col = mix(col, vec3(2.2, 2.1, 2.3), uWhite);
      col *= 1.0 - max(uBlack, uNod * smoothstep(0.2, 0.7, abs(c.y) * 2.0 + uNod * 0.6));
      gl_FragColor = vec4(col, 1.0);
    }`
};


// Antialiasing FXAA (versione compatta della 3.11 di Timothy Lottes): bordi puliti senza costo del MSAA.
const FXAAShader = {
  uniforms: { tDiffuse: { value: null }, uRes: { value: new THREE.Vector2(1, 1) }, uGrade: { value: 1 } },
  vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
  fragmentShader: /* glsl */`
    uniform sampler2D tDiffuse; uniform vec2 uRes; uniform float uGrade; varying vec2 vUv;
    float lum(vec3 c){ return dot(c, vec3(0.299, 0.587, 0.114)); }
    void main(){
      vec2 px = 1.0 / uRes;
      vec3 rgbNW = texture2D(tDiffuse, vUv + vec2(-1.0, -1.0) * px).rgb;
      vec3 rgbNE = texture2D(tDiffuse, vUv + vec2(1.0, -1.0) * px).rgb;
      vec3 rgbSW = texture2D(tDiffuse, vUv + vec2(-1.0, 1.0) * px).rgb;
      vec3 rgbSE = texture2D(tDiffuse, vUv + vec2(1.0, 1.0) * px).rgb;
      vec3 rgbM = texture2D(tDiffuse, vUv).rgb;
      float lNW = lum(rgbNW), lNE = lum(rgbNE), lSW = lum(rgbSW), lSE = lum(rgbSE), lM = lum(rgbM);
      float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
      float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
      vec2 dir = vec2(-((lNW + lNE) - (lSW + lSE)), ((lNW + lSW) - (lNE + lSE)));
      float red = max((lNW + lNE + lSW + lSE) * 0.03125, 1.0 / 128.0);
      float rcp = 1.0 / (min(abs(dir.x), abs(dir.y)) + red);
      dir = clamp(dir * rcp, -8.0, 8.0) * px;
      vec3 A = 0.5 * (texture2D(tDiffuse, vUv + dir * (1.0 / 3.0 - 0.5)).rgb + texture2D(tDiffuse, vUv + dir * (2.0 / 3.0 - 0.5)).rgb);
      vec3 B = A * 0.5 + 0.25 * (texture2D(tDiffuse, vUv - dir * 0.5).rgb + texture2D(tDiffuse, vUv + dir * 0.5).rgb);
      float lB = lum(B);
      vec3 col = (lB < lMin || lB > lMax) ? A : B;
      // grading leggero: ombre appena fredde, luci appena calde, un filo di contrasto (curva a S)
      vec3 g = col;
      float l = lum(g);
      g += (vec3(-0.012, 0.0, 0.016) * (1.0 - smoothstep(0.0, 0.45, l)) + vec3(0.014, 0.006, -0.012) * smoothstep(0.55, 1.0, l));
      g = mix(g, g * g * (3.0 - 2.0 * g), 0.22);
      gl_FragColor = vec4(mix(col, g, uGrade), 1.0);
    }`
};

export function createPost(renderer, scene, camera) {
  const size = renderer.getDrawingBufferSize(new THREE.Vector2());
  const rt = new THREE.WebGLRenderTarget(size.x, size.y, { type: THREE.HalfFloatType, depthBuffer: true, stencilBuffer: true });
  const composer = new EffectComposer(renderer, rt);
  composer.addPass(new RenderPass(scene, camera));
  const bloom = new UnrealBloomPass(new THREE.Vector2(size.x / 2, size.y / 2), 0.5, 0.45, 1.6);
  composer.addPass(bloom);
  const dream = new ShaderPass(DreamShader);
  composer.addPass(dream);
  composer.addPass(new OutputPass());
  const fxaa = new ShaderPass(FXAAShader);
  composer.addPass(fxaa);
  let ao = null;
  return {
    composer, bloom, fxaa, uniforms: dream.uniforms,
    // occlusione ambientale: ombre di contatto negli angoli (solo qualità alta, caricata a richiesta)
    async setAO(on) {
      if (on && !ao) {
        const { GTAOPass } = await import('three/addons/postprocessing/GTAOPass.js');
        const s2 = renderer.getDrawingBufferSize(new THREE.Vector2());
        ao = new GTAOPass(scene, camera, s2.x, s2.y);
        ao.updateGtaoMaterial({ radius: 0.6, distanceExponent: 1.5, thickness: 1.5, scale: 1.2, samples: 12 });
        ao.blendIntensity = 0.85;
        composer.insertPass(ao, 1);
      }
      if (ao) ao.enabled = !!on;
    },
    setSize(w, h, pr) { composer.setPixelRatio(pr); composer.setSize(w, h); dream.uniforms.uRes.value.set(w * pr, h * pr); fxaa.uniforms.uRes.value.set(w * pr, h * pr); },
    render(dt) { composer.render(dt); }
  };
}
