// Oggetti che passano di mano: tazzina, bicchiere, trancio, cornetto, giornale, gratta e vinci, bustina, pastiglia.
import * as THREE from 'three';

const M = (color, extra = {}) => new THREE.MeshStandardMaterial(Object.assign({ color, roughness: 0.5 }, extra));

export const PROP_FOR = {
  caffe: 'tazzina', cappuccino: 'tazza', cornetto: 'cornetto', acqua: 'bottiglietta', trancio: 'trancio', panino: 'panino', focaccia: 'trancio',
  ambra: 'bicchiere', fumo: 'canna', kokka: 'bustina', lyn: 'sciroppo', francobollo: 'francobollo', giornale: 'giornale', gratta: 'gratta',
  aspirina: 'pastiglia', tisana: 'tazza'
};
export const GESTURE_FOR = {
  tazzina: 'drink', tazza: 'drink', bicchiere: 'drink', bottiglietta: 'drink', sciroppo: 'drink',
  cornetto: 'eat', trancio: 'eat', panino: 'eat', giornale: 'read', gratta: 'look', canna: 'smoke', bustina: 'sniff', francobollo: 'eat', pastiglia: 'eat'
};

export function makeProp(kind) {
  const g = new THREE.Group();
  const add = (geo, mat, x = 0, y = 0, z = 0, rx = 0, rz = 0) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.rotation.set(rx, 0, rz); g.add(m); return m; };
  switch (kind) {
    case 'tazzina': add(new THREE.CylinderGeometry(0.03, 0.024, 0.05, 14), M(0xf4f1ea, { roughness: 0.2 })); add(new THREE.CylinderGeometry(0.026, 0.026, 0.004, 14), M(0x3a1f12), 0, 0.022); add(new THREE.CylinderGeometry(0.05, 0.05, 0.006, 16), M(0xf4f1ea, { roughness: 0.2 }), 0, -0.026); break;
    case 'tazza': add(new THREE.CylinderGeometry(0.042, 0.034, 0.08, 14), M(0xf4f1ea, { roughness: 0.2 })); add(new THREE.CylinderGeometry(0.038, 0.038, 0.004, 14), M(0xd9b98a), 0, 0.037); break;
    case 'bicchiere': add(new THREE.CylinderGeometry(0.035, 0.03, 0.11, 14), M(0xffffff, { transparent: true, opacity: 0.35, roughness: 0.05 })); add(new THREE.CylinderGeometry(0.031, 0.028, 0.07, 14), M(0xc77a1e, { roughness: 0.1, emissive: 0x3a1a00 }), 0, -0.015); break;
    case 'bottiglietta': add(new THREE.CylinderGeometry(0.028, 0.03, 0.2, 12), M(0xbfe3f2, { transparent: true, opacity: 0.6, roughness: 0.1 })); add(new THREE.CylinderGeometry(0.014, 0.014, 0.025, 8), M(0x1f5aa8), 0, 0.11); break;
    case 'sciroppo': add(new THREE.CylinderGeometry(0.04, 0.035, 0.12, 12), M(0xffffff, { transparent: true, opacity: 0.4 })); add(new THREE.CylinderGeometry(0.036, 0.032, 0.08, 12), M(0x7a2a9a, { emissive: 0x2a0a3a }), 0, -0.015); break;
    case 'cornetto': add(new THREE.TorusGeometry(0.05, 0.022, 8, 12, Math.PI * 1.2), M(0xd9a35a), 0, 0, 0, Math.PI / 2); break;
    case 'trancio': { const s = new THREE.Shape(); s.moveTo(0, 0); s.lineTo(0.09, 0.2); s.lineTo(-0.09, 0.2); s.closePath();
      add(new THREE.ExtrudeGeometry(s, { depth: 0.015, bevelEnabled: false }), M(0xe8b04a), 0, -0.08, 0); add(new THREE.BoxGeometry(0.19, 0.03, 0.02), M(0xc98a3a), 0, 0.12, 0.004); break; }
    case 'panino': add(new THREE.SphereGeometry(0.06, 10, 6), M(0xd9a35a), 0, 0, 0); g.children[0].scale.set(1.4, 0.7, 1); break;
    case 'giornale': { const c = document.createElement('canvas'); c.width = 256; c.height = 192; const x = c.getContext('2d');
      x.fillStyle = '#efe8dc'; x.fillRect(0, 0, 256, 192); x.fillStyle = '#222'; x.font = '700 22px Georgia, serif'; x.fillText('La Gazzetta', 20, 32);
      for (let i = 0; i < 9; i++) x.fillRect(20, 50 + i * 14, 100 + (i * 37) % 110, 6);
      const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
      add(new THREE.PlaneGeometry(0.34, 0.26), new THREE.MeshStandardMaterial({ map: t, side: THREE.DoubleSide, roughness: 0.9 }), 0, 0.08, 0.05); break; }
    case 'gratta': add(new THREE.BoxGeometry(0.1, 0.14, 0.002), M(0xf2c84b, { roughness: 0.3, metalness: 0.4 }), 0, 0.05, 0.02); break;
    case 'canna': add(new THREE.CylinderGeometry(0.004, 0.006, 0.08, 6), M(0xf2efe8), 0, 0, 0.02, 0, Math.PI / 2); add(new THREE.SphereGeometry(0.006, 6, 4), M(0xff6a2a, { emissive: 0xff4a10, emissiveIntensity: 3 }), 0.04, 0, 0.02); break;
    case 'bustina': add(new THREE.BoxGeometry(0.04, 0.05, 0.004), M(0xffffff, { transparent: true, opacity: 0.7, roughness: 0.1 }), 0, 0.02, 0.02); break;
    case 'francobollo': add(new THREE.PlaneGeometry(0.025, 0.03), M(0xf2b8c6, { side: THREE.DoubleSide, emissive: 0x4a1a2a }), 0, 0.02, 0.03); break;
    case 'pastiglia': add(new THREE.CylinderGeometry(0.008, 0.008, 0.004, 10), M(0xffffff), 0, 0.01, 0.02, Math.PI / 2); break;
    default: add(new THREE.BoxGeometry(0.06, 0.06, 0.06), M(0x888888));
  }
  g.traverse((m) => { if (m.isMesh) m.castShadow = true; });
  return g;
}
