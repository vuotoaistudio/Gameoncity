// Pioggia: segmenti che cadono attorno al giocatore, quantità dalla precipitazione reale.
import * as THREE from 'three';

export function createRain(max = 5000) {
  const pos = new Float32Array(max * 6);
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const mat = new THREE.LineBasicMaterial({ color: 0xaab4bf, transparent: true, opacity: 0.35, depthWrite: false });
  const lines = new THREE.LineSegments(g, mat);
  lines.frustumCulled = false;
  const drops = new Float32Array(max * 3);
  for (let i = 0; i < max; i++) { drops[i * 3] = (Math.random() - 0.5) * 60; drops[i * 3 + 1] = Math.random() * 25; drops[i * 3 + 2] = (Math.random() - 0.5) * 60; }
  let active = 0;
  return {
    lines,
    update(dt, center, intensity, wind, snow = false) {
      mat.color.setHex(snow ? 0xf4f6f8 : 0xaab4bf); mat.opacity = snow ? 0.8 : 0.35;
      const fall = snow ? 1.4 : 11, streak = snow ? 0.06 : 0.45;
      active = Math.min(max, Math.floor(intensity * max));
      g.setDrawRange(0, active * 2);
      lines.visible = active > 0;
      const wx = wind[0], wz = wind[1];
      for (let i = 0; i < active; i++) {
        let x = drops[i * 3], y = drops[i * 3 + 1], z = drops[i * 3 + 2];
        y -= dt * fall; x += (wx + (snow ? Math.sin(y * 1.7 + i) * 0.6 : 0)) * dt; z += wz * dt;
        if (y < 0) { y += 25; x = (Math.random() - 0.5) * 60; z = (Math.random() - 0.5) * 60; }
        if (x > 30) x -= 60; if (x < -30) x += 60; if (z > 30) z -= 60; if (z < -30) z += 60;
        drops[i * 3] = x; drops[i * 3 + 1] = y; drops[i * 3 + 2] = z;
        const o = i * 6, X = center.x + x, Z = center.z + z;
        pos[o] = X; pos[o + 1] = y; pos[o + 2] = Z;
        pos[o + 3] = X + wx * 0.04 + (snow ? 0.05 : 0); pos[o + 4] = y + streak; pos[o + 5] = Z + wz * 0.04;
      }
      g.attributes.position.needsUpdate = true;
    }
  };
}
