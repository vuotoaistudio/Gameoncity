// Cielo fisico: diffusione atmosferica (Rayleigh + Mie, modello di Preetham) dal sole reale,
// nuvole volumetriche illuminate dal sole secondo la copertura reale, stelle e luna di notte.
import * as THREE from 'three';

export function createSky() {
  const uniforms = {
    uSunDir: { value: new THREE.Vector3(0, 1, 0) },
    uZenith: { value: new THREE.Color() }, uHorizon: { value: new THREE.Color() },
    uSunColor: { value: new THREE.Color() }, uCloud: { value: 0.3 }, uNight: { value: 0 },
    uTime: { value: 0 }, uDream: { value: 0 }, uFog: { value: 0 }, uFogColor: { value: new THREE.Color() },
    uOvercast: { value: 0 }, uWind: { value: new THREE.Vector2(0.004, 0.002) },
    uMoonDir: { value: new THREE.Vector3(0, 0.5, -1).normalize() }, uMoonPhase: { value: 0.5 },
    uTurbidity: { value: 2.6 }, uEnvPass: { value: 0 }, uRayleigh: { value: 1.6 }, uMieCoef: { value: 0.0035 }, uMieG: { value: 0.78 }
  };
  const mat = new THREE.ShaderMaterial({
    uniforms, side: THREE.BackSide, depthWrite: false,
    vertexShader: /* glsl */`
      varying vec3 vDir;
      void main(){ vDir = normalize(position); vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position = p.xyww; }`,
    fragmentShader: /* glsl */`
      uniform vec3 uSunDir, uZenith, uHorizon, uSunColor, uFogColor, uMoonDir;
      uniform float uCloud, uNight, uTime, uDream, uFog, uOvercast, uTurbidity, uRayleigh, uMieCoef, uMieG, uMoonPhase, uEnvPass;
      uniform vec2 uWind;
      varying vec3 vDir;
      const float PI = 3.141592653589793;
      const vec3 UP = vec3(0.0, 1.0, 0.0);
      // costanti fisiche dell'atmosfera (lunghezze d'onda di R, G, B)
      const vec3 totalRayleigh = vec3(5.804542996261093E-6, 1.3562911419845635E-5, 3.0265902468824876E-5);
      const vec3 MieConst = vec3(1.8399918514433978E14, 2.7798023919660528E14, 4.0790479543861094E14);
      const float rayleighZenithLength = 8.4E3, mieZenithLength = 1.25E3;
      float hash(vec3 p){ p = fract(p*0.3183099+.1); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
      float noise(vec3 x){ vec3 i=floor(x), f=fract(x); f=f*f*(3.-2.*f);
        return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),
                   mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z); }
      float fbm(vec3 p){ float a=0.5, s=0.; for(int i=0;i<6;i++){ s+=a*noise(p); p=p*2.02+vec3(0.13,0.71,0.37); a*=0.5; } return s; }
      vec3 totalMie(float T){ float c = (0.2 * T) * 10E-18; return 0.434 * c * MieConst; }
      float rayleighPhase(float c){ return (3.0 / (16.0 * PI)) * (1.0 + c * c); }
      float hgPhase(float c, float g){ float g2 = g * g; return (1.0 / (4.0 * PI)) * ((1.0 - g2) / pow(1.0 - 2.0 * g * c + g2, 1.5)); }

      vec3 scatter(vec3 d, vec3 sunDir, float sunE){
        float sunfade = 1.0 - clamp(1.0 - exp(sunDir.y / 0.45), 0.0, 1.0);
        float rc = uRayleigh - (1.0 * (1.0 - sunfade));
        vec3 bR = totalRayleigh * rc;
        vec3 bM = totalMie(uTurbidity) * uMieCoef;
        float zen = acos(max(0.0, dot(UP, d)));
        float inv = 1.0 / (cos(zen) + 0.15 * pow(93.885 - ((zen * 180.0) / PI), -1.253));
        float sR = rayleighZenithLength * inv, sM = mieZenithLength * inv;
        vec3 Fex = exp(-(bR * sR + bM * sM));
        float ct = dot(d, sunDir);
        vec3 betaR = bR * rayleighPhase(ct * 0.5 + 0.5);
        vec3 betaM = bM * hgPhase(ct, uMieG);
        vec3 Lin = pow(sunE * ((betaR + betaM) / (bR + bM)) * (1.0 - Fex), vec3(1.5));
        Lin *= mix(vec3(1.0), pow(sunE * ((betaR + betaM) / (bR + bM)) * Fex, vec3(0.5)), clamp(pow(1.0 - dot(UP, sunDir), 5.0), 0.0, 1.0));
        vec3 L0 = vec3(0.1) * Fex;
        float sunDisk = smoothstep(0.99995, 0.99998, ct);
        L0 += sunE * 19000.0 * Fex * sunDisk * (1.0 - uEnvPass);
        return (Lin + L0) * 0.04 + vec3(0.0, 0.0003, 0.00075);
      }

      void main(){
        vec3 d = normalize(vDir);
        float h = d.y;
        vec3 sd = normalize(uSunDir);
        // energia del sole che arriva in alto (si spegne sotto l'orizzonte)
        float zenAng = dot(sd, UP);
        float sunE = 1000.0 * max(0.0, 1.0 - pow(2.718281828, -((1.6110731556870734 - acos(zenAng)) / 1.5)));
        vec3 phys = scatter(normalize(vec3(d.x, max(d.y, 0.002), d.z)), sd, sunE);
        // l'atmosfera fisica va in scala con l'esposizione del gioco
        phys *= 0.75;
        // niente veli bianchi: il cielo resta entro una luminanza credibile, il disco solare a parte
        float dl = dot(phys, vec3(0.3, 0.59, 0.11));
        phys *= min(1.0, 1.6 / max(dl, 1e-4)) + smoothstep(0.99995, 0.99998, dot(d, sd)) * 20.0;
        // coperto: la volta diventa un grigio piatto, più chiaro verso il sole
        float sdot = max(dot(d, sd), 0.0);
        vec3 grey = mix(uHorizon, uZenith, pow(max(h, 0.0), 0.6)) * (0.9 + 0.25 * pow(sdot, 4.0));
        vec3 col = mix(phys, grey, clamp(uOvercast * 1.1, 0.0, 1.0));
        // notte: blu profondo con bagliore arancio della città all'orizzonte
        vec3 night = mix(vec3(0.05, 0.045, 0.06), vec3(0.006, 0.009, 0.024), pow(max(h, 0.0), 0.35));
        night += vec3(0.09, 0.05, 0.025) * exp(-max(h, 0.0) * 9.0) * (0.6 + uOvercast);
        col = mix(col, night, uNight);
        // sotto l'orizzonte: il colore della nebbia lontana
        col = mix(col, uFogColor * 0.9, smoothstep(0.0, -0.08, h));

        // stelle (scintillano, spariscono con le nuvole e con la luce)
        if (uNight > 0.01 && h > 0.0) {
          // stelle puntiformi: poche, perché in città la luce dei lampioni le spegne
          vec3 q = d * 420.0;
          vec3 g = floor(q);
          float r = hash(g);
          float dist = length(fract(q) - 0.5);
          float s = step(0.9984, r) * smoothstep(0.22, 0.0, dist) * uNight * (1.0 - uCloud) * smoothstep(0.05, 0.4, h);
          col += vec3(0.9, 0.95, 1.0) * s * (0.55 + 0.45 * sin(uTime * 3.0 + r * 60.0)) * (0.5 + 1.2 * fract(r * 13.0));
        }
        // luna con la sua fase
        if (uNight > 0.01) {
          vec3 md = normalize(uMoonDir);
          float mc = dot(d, md);
          float disk = smoothstep(0.99955, 0.9997, mc);
          if (disk > 0.0) {
            vec3 tx = normalize(cross(md, UP)); vec3 ty = cross(tx, md);
            vec2 q = vec2(dot(d - md, tx), dot(d - md, ty)) / 0.024;
            float lit = smoothstep(-0.1, 0.1, q.x * cos(uMoonPhase * 6.2832) + sqrt(max(0.0, 1.0 - dot(q, q))) * sin(uMoonPhase * 6.2832 - 1.5708) * -1.0);
            float maria = 0.85 + 0.15 * noise(vec3(q * 6.0, 1.0));
            col += vec3(1.0, 0.97, 0.9) * disk * (0.08 + 0.9 * lit) * maria * uNight * (1.0 - uCloud * 0.85);
          }
          col += vec3(0.6, 0.65, 0.8) * pow(max(mc, 0.0), 300.0) * 0.12 * uNight * (1.0 - uCloud * 0.6);
        }

        // nuvole: due strati proiettati su una cupola, densità dalla copertura reale, illuminate dal sole
        if (h > 0.0) {
          vec2 uv = d.xz / (h + 0.12);
          vec3 p = vec3(uv * 1.1 + uWind * uTime * 60.0, uTime * 0.004);
          float base = fbm(p);
          float detail = fbm(p * 3.1 + vec3(uTime * 0.01));
          float n = base * 0.75 + detail * 0.35;
          float cov = clamp(uCloud, 0.0, 1.0);
          float dens = smoothstep(1.02 - cov * 0.62, 1.25 - cov * 0.5, n);
          // illuminazione: il lato verso il sole è più chiaro (passo verso il sole)
          float toward = fbm(p + vec3(sd.xz * 0.12, 0.0)) * 0.75 + detail * 0.35;
          float shade = clamp(1.0 - (toward - n) * 3.5, 0.35, 1.25);
          vec3 sunLit = mix(vec3(1.0), vec3(1.0, 0.6, 0.38), smoothstep(0.35, 0.02, sd.y)) * (0.25 + 0.95 * clamp(sd.y * 4.0 + 0.2, 0.0, 1.0));
          vec3 cloudCol = mix(uZenith * 0.65 + vec3(0.06), sunLit, 0.55) * shade;
          cloudCol += uSunColor * pow(sdot, 8.0) * 0.6 * (1.0 - dens * 0.5);
          cloudCol = mix(cloudCol, grey * 0.85, uOvercast * 0.6);
          cloudCol = mix(cloudCol, vec3(0.03, 0.032, 0.045) + vec3(0.06, 0.035, 0.02) * (1.0 - h), uNight);
          col = mix(col, cloudCol, dens * smoothstep(0.0, 0.12, h) * (1.0 - uOvercast * 0.35));
        }
        col = mix(col, uFogColor, uFog * (1.0 - smoothstep(0.0, 0.35, h)) + uFog * 0.25);
        col = mix(col, col * vec3(1.05, 0.92, 1.08), uDream * 0.5);
        // per i riflessi: niente disco solare e niente valori estremi (li gestisce già la luce del sole)
        if (uEnvPass > 0.5) {
          // in città il "cielo" che illumina le ombre è fatto anche di facciate e selciato: luce di rimbalzo calda
          float lc = dot(col, vec3(0.3, 0.59, 0.11));
          vec3 sunK = vec3(1.0, 0.92, 0.8) * (0.12 + 0.88 * clamp(sd.y * 3.0, 0.0, 1.0)) * (1.0 - uOvercast * 0.5);
          vec3 facades = vec3(0.42, 0.37, 0.3) * sunK * (1.0 - uNight) + vec3(0.05, 0.035, 0.02) * uNight;
          col = mix(col, vec3(lc) * vec3(1.04, 0.99, 0.92), 0.3);
          col = mix(col, facades, smoothstep(0.32, 0.0, h) * 0.6);
          col = mix(col, facades * 0.75, smoothstep(0.0, -0.12, h));
          col = min(col, vec3(1.5));
        }
        gl_FragColor = vec4(col, 1.0);
      }`
  });
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(1500, 48, 24), mat);
  mesh.frustumCulled = false;
  mesh.renderOrder = -10;
  return { mesh, uniforms };
}
