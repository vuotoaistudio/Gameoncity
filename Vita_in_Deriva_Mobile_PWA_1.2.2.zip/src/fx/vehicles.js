// Geometrie dei veicoli: utilitaria a due volumi e tram "Ventotto" milanese/fiorentino.
// Il davanti è verso +z; le misure sono in metri.
import * as THREE from 'three';

function extrudeProfile(points, width, bevel) {
  const s = new THREE.Shape();
  points.forEach(([z, y], i) => (i ? s.lineTo(z, y) : s.moveTo(z, y)));
  s.closePath();
  const g = new THREE.ExtrudeGeometry(s, { depth: width - bevel * 2, bevelEnabled: true, bevelThickness: bevel, bevelSize: bevel, bevelSegments: 3, curveSegments: 6 });
  // estruso lungo z: lo ruotiamo perché la sagoma stia nel piano zy e la larghezza lungo x
  g.translate(0, 0, -(width - bevel * 2) / 2);
  g.rotateY(Math.PI / 2);
  g.computeVertexNormals();
  return g;
}

function box(w, h, d, x, y, z) { const g = new THREE.BoxGeometry(w, h, d); g.translate(x, y, z); return g; }

export function mergeAll(geos) {
  let n = 0;
  for (const g of geos) n += (g.index ? g.index.count : g.attributes.position.count);
  const pos = new Float32Array(n * 3), nor = new Float32Array(n * 3);
  let o = 0;
  for (const g0 of geos) {
    const g = g0.index ? g0.toNonIndexed() : g0;
    pos.set(g.attributes.position.array, o * 3); nor.set(g.attributes.normal.array, o * 3);
    o += g.attributes.position.count;
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  out.computeBoundingSphere();
  return out;
}

// utilitaria: carrozzeria, vetri, ruote, fari (davanti bianchi, dietro rossi)
export function carGeometries() {
  const body = extrudeProfile([[-1.98, 0.3], [1.98, 0.3], [2.04, 0.5], [1.96, 0.76], [1.2, 0.93], [0.42, 1.0], [-1.5, 1.02], [-1.95, 0.9], [-2.02, 0.62]], 1.74, 0.08);
  const cabin = extrudeProfile([[-1.62, 0.96], [0.62, 0.96], [-0.05, 1.42], [-1.48, 1.45], [-1.72, 1.02]], 1.56, 0.06);
  const roof = extrudeProfile([[-1.47, 1.43], [-0.07, 1.41], [-0.15, 1.47], [-1.42, 1.49]], 1.42, 0.03);
  const wheel = new THREE.CylinderGeometry(0.31, 0.31, 0.22, 16); wheel.rotateZ(Math.PI / 2);
  const hub = new THREE.CylinderGeometry(0.17, 0.17, 0.235, 10); hub.rotateZ(Math.PI / 2);
  const wheels = [], hubs = [];
  for (const [x, z] of [[-0.8, 1.3], [0.8, 1.3], [-0.8, -1.32], [0.8, -1.32]]) { wheels.push(wheel.clone().translate(x, 0.31, z)); hubs.push(hub.clone().translate(x * 1.01, 0.31, z)); }
  const front = mergeAll([box(0.36, 0.12, 0.05, -0.6, 0.66, 2.0), box(0.36, 0.12, 0.05, 0.6, 0.66, 2.0)]);
  const rear = mergeAll([box(0.32, 0.14, 0.05, -0.64, 0.74, -2.0), box(0.32, 0.14, 0.05, 0.64, 0.74, -2.0)]);
  const trim = mergeAll([box(1.7, 0.16, 0.08, 0, 0.4, 2.0), box(1.7, 0.16, 0.08, 0, 0.42, -2.0), box(1.2, 0.12, 0.04, 0, 0.53, -2.04)]);
  return { body: mergeAll([body, roof]), glass: cabin, wheels: mergeAll(wheels), hubs: mergeAll(hubs), front, rear, trim, half: [0.92, 2.1] };
}

// tram a carrelli con tetto arrotondato, fascia dei finestrini, pantografo
export function tramGeometries() {
  const L = 13.6, W = 2.35;
  const lower = box(W, 1.15, L, 0, 0.95, 0);
  const upperFront = box(W, 0.35, L, 0, 2.55, 0);
  const pillars = [];
  for (let z = -L / 2 + 0.15; z <= L / 2 - 0.1; z += 1.05) { pillars.push(box(0.08, 1.05, 0.12, -W / 2 + 0.02, 1.98, z), box(0.08, 1.05, 0.12, W / 2 - 0.02, 1.98, z)); }
  const roof = new THREE.CylinderGeometry(1.45, 1.45, L - 0.2, 20, 1, false, -0.9, 1.8); roof.rotateX(Math.PI / 2); roof.rotateZ(Math.PI / 2); roof.scale(1, 0.32, 1); roof.translate(0, 2.55, 0);
  const glass = mergeAll([box(W - 0.06, 1.05, L - 0.3, 0, 1.98, 0), box(W - 0.4, 0.9, 0.05, 0, 1.95, L / 2 + 0.01), box(W - 0.4, 0.9, 0.05, 0, 1.95, -L / 2 - 0.01)]);
  const under = mergeAll([box(W - 0.3, 0.45, 2.4, 0, 0.32, L / 2 - 2.6), box(W - 0.3, 0.45, 2.4, 0, 0.32, -L / 2 + 2.6), box(W - 0.2, 0.1, L - 0.6, 0, 0.36, 0)]);
  const panto = mergeAll([box(0.9, 0.08, 0.9, 0, 3.0, 1.0), box(0.05, 1.4, 0.05, 0, 3.6, 1.2), box(1.2, 0.05, 0.05, 0, 4.25, 1.4)]);
  const lights = mergeAll([box(0.25, 0.18, 0.05, -0.8, 1.05, L / 2 + 0.02), box(0.25, 0.18, 0.05, 0.8, 1.05, L / 2 + 0.02)]);
  const tail = mergeAll([box(0.2, 0.15, 0.05, -0.85, 1.05, -L / 2 - 0.02), box(0.2, 0.15, 0.05, 0.85, 1.05, -L / 2 - 0.02)]);
  return { lower: mergeAll([lower]), upper: mergeAll([upperFront, roof, ...pillars]), glass, under, panto, lights, tail, half: [W / 2 + 0.1, L / 2 + 0.2], length: L };
}

// scooter alla Vespa: scocca posteriore tondeggiante, pedana, scudo, manubrio, due ruote piccole
export function scooterGeometries() {
  const shell = new THREE.SphereGeometry(0.34, 18, 12); shell.scale(0.82, 0.72, 1.35); shell.translate(0, 0.5, -0.42);
  const floor = box(0.32, 0.08, 0.62, 0, 0.3, 0.12);
  const shield = new THREE.CylinderGeometry(0.26, 0.24, 0.78, 16, 1, true, -1.1, 2.2); shield.translate(0, 0.66, 0.36);
  const fender = new THREE.SphereGeometry(0.2, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.5); fender.scale(0.75, 0.7, 1.1); fender.translate(0, 0.26, 0.62);
  const stem = new THREE.CylinderGeometry(0.035, 0.035, 0.6, 8); stem.rotateX(-0.3); stem.translate(0, 0.86, 0.55);
  const bar = new THREE.CylinderGeometry(0.02, 0.02, 0.62, 8); bar.rotateZ(Math.PI / 2); bar.translate(0, 1.14, 0.48);
  const head = new THREE.CylinderGeometry(0.09, 0.09, 0.06, 14); head.rotateX(Math.PI / 2); head.translate(0, 1.12, 0.56);
  const seat = new THREE.SphereGeometry(0.2, 14, 8); seat.scale(0.75, 0.32, 1.6); seat.translate(0, 0.78, -0.3);
  const wheel = new THREE.CylinderGeometry(0.21, 0.21, 0.1, 16); wheel.rotateZ(Math.PI / 2);
  const wheels = mergeAll([wheel.clone().translate(0, 0.21, 0.62), wheel.clone().translate(0, 0.21, -0.58)]);
  const lamp = box(0.12, 0.08, 0.04, 0, 1.12, 0.6);
  const tail = box(0.14, 0.06, 0.04, 0, 0.62, -0.88);
  return { paint: mergeAll([shell, shield, fender]), dark: mergeAll([floor, stem, bar, seat]), chrome: mergeAll([head]), wheels, lamp, tail, half: [0.38, 0.95] };
}
