// Vita in Deriva: avvio, ciclo di gioco e collegamento dei sistemi.
import * as THREE from 'three';
import { parseOSM, addressOf } from './world/osm.js';
import { buildCity, createEnvUniforms } from './world/cityMesh.js';
import { DriftSystem, ANOMALIES } from './world/drift.js';
import { DreamManager } from './world/dream.js';
import { sunPosition, sunDirection, localTimeString, moonPhase } from './world/sun.js';
import { fetchWeather, describeWeather, simulateWeather, presetWeather } from './world/weather.js';
import { computeAtmosphere } from './world/atmosphere.js';
import { createSky } from './fx/sky.js';
import { createRain } from './fx/rain.js';
import { createPost } from './fx/post.js';
import { createMirror } from './fx/mirror.js';
import { Player, Collision } from './player/controller.js';
import { Avatar, OPTIONS, defaultAppearance, sanitizeAppearance } from './player/avatar.js';
import { Substances } from './systems/substances.js';
import { AudioEngine } from './systems/audio.js';
import { NetClient } from './net/client.js';
import { Voice } from './net/voice.js';
import { buildShops } from './world/shops.js';
import { Crowd } from './world/npc.js';
import { Story, NORA_RICORDI } from './systems/story.js';
import { Wallet, euro } from './systems/economy.js';
import { LifeUI } from './ui/life.js';
import { RICORDI } from './world/dream.js';
import { Avatars } from './net/avatars.js';
import { Combat } from './systems/combat.js';
import { Traffic } from './world/traffic.js';
import { Driving } from './systems/driving.js';
import { RealEstate } from './systems/realestate.js';
import { Jobs } from './systems/jobs.js';
import { MiniMap } from './ui/minimap.js';
import { setCity, watchDom } from './systems/locale.js';

const $ = (id) => document.getElementById(id);
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* spazio pieno o bloccato */ } }
};

// ---------- impostazioni ----------
const settings = Object.assign({ substances: true, violence: false, safe: false, time: 'real', sens: 1, quality: 'auto', name: '', volume: 0.8, view: 'third', look: null },
  store.get('vid-settings', {}));
if (typeof settings.quality === 'number') settings.quality = 'auto';
function saveSettings() { store.set('vid-settings', settings); }
const QUALITY = {
  mobile: { pr: 0.7, shadow: 0, bloom: false, far: 650, lite: true, minFog: 0.0042 },
  low: { pr: 0.85, shadow: 1024, bloom: false, far: 1200, lite: true, minFog: 0.003 },
  mid: { pr: 1.2, shadow: 2048, bloom: true, far: 2500, lite: false, minFog: 0 },
  high: { pr: 1.75, shadow: 2048, bloom: true, far: 2500, lite: false, minFog: 0 },
  auto: { pr: 1.25, shadow: 2048, bloom: true, far: 2500, lite: false, minFog: 0 }
};
// il telefono riceve da solo un profilo leggero
const isMobile = matchMedia('(pointer: coarse)').matches || /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
const profileName = () => (settings.quality === 'auto' && isMobile ? 'mobile' : settings.quality);
const PROFILE = () => QUALITY[profileName()];

// ---------- rendering ----------
const canvas = $('game');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance', stencil: true });
let pixelRatio = Math.min(devicePixelRatio || 1, PROFILE().pr);
renderer.setPixelRatio(pixelRatio);
renderer.setSize(innerWidth, innerHeight, false);
renderer.shadowMap.enabled = PROFILE().shadow > 0;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.outputColorSpace = THREE.SRGBColorSpace;
const scene = new THREE.Scene();
scene.fog = new THREE.FogExp2(0xb0b8c0, 0.002);
const camera = new THREE.PerspectiveCamera(65, innerWidth / innerHeight, 0.1, PROFILE().far);
const env = createEnvUniforms();
env.uInterior.value = settings.interiors === false || PROFILE().lite ? 0 : 1;
const sky = createSky();
scene.add(sky.mesh);
const rain = createRain();
scene.add(rain.lines);
const hemi = new THREE.HemisphereLight(0xc8d4e8, 0x3a332c, 0.9);
const sun = new THREE.DirectionalLight(0xffffff, 2);
sun.castShadow = PROFILE().shadow > 0;
sun.shadow.mapSize.set(PROFILE().shadow || 512, PROFILE().shadow || 512);
Object.assign(sun.shadow.camera, { left: -55, right: 55, top: 55, bottom: -55, near: 1, far: 400 });
sun.shadow.bias = -0.0006; sun.shadow.normalBias = 0.08;
scene.add(hemi, sun, sun.target);
// luci puntiformi riusate: i lampioni più vicini di notte, le plafoniere nel sogno
const pool = Array.from({ length: 6 }, () => { const l = new THREE.PointLight(0xffb36b, 0, 22, 2); scene.add(l); return l; });
const post = createPost(renderer, scene, camera);
// riflessi dei palazzi nell'acqua dei canali (si spengono sulle qualità leggere)
const mirror = createMirror(renderer, -1.7);
post.bloom.enabled = PROFILE().bloom !== false;
post.setAO(profileName() === 'high').catch(() => {});
// riflessi del cielo su vetri, acqua e asfalto bagnato
const pmrem = new THREE.PMREMGenerator(renderer);
const skyScene = new THREE.Scene();
skyScene.add(new THREE.Mesh(sky.mesh.geometry, sky.mesh.material));
let envRT = null, envAt = -1e9;
function updateEnvMap() {
  const old = envRT;
  sky.uniforms.uEnvPass.value = 1;
  envRT = pmrem.fromScene(skyScene, 0.02, 0.1, 3000);
  sky.uniforms.uEnvPass.value = 0;
  scene.environment = envRT.texture;
  if (old) old.dispose();
}

function wantReflections() { return settings.reflections !== false && !PROFILE().lite && !(settings.quality === 'auto' && state.autoLite); }
function resize() {
  renderer.setPixelRatio(pixelRatio);
  renderer.setSize(innerWidth, innerHeight, false);
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  post.setSize(innerWidth, innerHeight, pixelRatio);
  mirror.setScale(profileName() === 'high' ? 0.6 : 0.45);
  mirror.setSize(innerWidth * pixelRatio, innerHeight * pixelRatio);
}
addEventListener('resize', resize);
resize();

function applyQualityProfile() {
  pixelRatio = Math.min(devicePixelRatio || 1, PROFILE().pr);
  renderer.shadowMap.enabled = PROFILE().shadow > 0;
  sun.castShadow = PROFILE().shadow > 0;
  sun.shadow.mapSize.set(PROFILE().shadow || 512, PROFILE().shadow || 512);
  camera.far = PROFILE().far;
  camera.updateProjectionMatrix();
  env.uInterior.value = settings.interiors === false || PROFILE().lite ? 0 : 1;
  post.bloom.enabled = PROFILE().bloom !== false;
  post.setAO(profileName() === 'high').catch(() => {});
  resize();
}

// ---------- stato ----------
const state = {
  mode: 'menu', // menu | creator | play | pause | card
  cityInfo: null, features: null, city: null, drift: null, player: null, collision: null, dream: null,
  weather: simulateWeather(new Date()), weatherAt: 0, synthetic: false, online: false,
  viewfinder: false, flash: 0, capture: null, album: [], ricordi: [], streetName: '',
  sampleT: 0, streetT: 0, saveT: 20, wetness: 0, nearWater: 0,
  transition: null, white: 0, inside: null, insideFrom: null, threshold: null, nearBar: null,
  stats: { photos: 0, anomalies: 0, drinks: 0, blackouts: 0, ricordi: 0, spent: 0 },
  night: 0, clock: '', dreamBias: 1, tiredWarned: false, pocket: {},
  perf: { acc: 0, n: 0, t: 0, debugAt: 0, debugFrames: 0 }, showPerf: false
};
const subs = new Substances();
const net = new NetClient();
const avatars = new Avatars(scene);
const audio = new AudioEngine();
audio.setVolume(settings.volume);
let avatar = null;

// ---------- caricamento città ----------
function setLoadingStatus(message, mode = 'loading') {
  const line = $('loadLine');
  if (!line) return;
  line.hidden = false;
  line.classList.toggle('ready', mode === 'ready');
  line.classList.toggle('error', mode === 'error');
  $('loadText').textContent = message;
}
const yieldToBrowser = () => new Promise((resolve) => requestAnimationFrame(() => resolve()));

async function loadCity() {
  setLoadingStatus('Carico l’elenco delle città…');
  const index = await (await fetch('./data/cities/index.json')).json();
  state.cities = index.cities;
  const info = index.cities.find((c) => c.id === settings.city) || index.cities[0];
  renderCityPicker();
  state.cityInfo = info;
  setLoadingStatus(`Preparo ${info.city}: strade, quartieri e luci…`);
  setCity(info.id);
  watchDom(document.body);
  let data;
  try {
    const r = await fetch('./data/cities/' + info.file);
    if (!r.ok) throw new Error('mancante');
    data = await r.json();
  } catch {
    data = await (await fetch('./data/fixtures/' + info.fixture)).json();
    state.synthetic = true;
  }
  setLoadingStatus(`Disegno la mappa di ${info.city}…`);
  await yieldToBrowser();
  const center = (data.meta && data.meta.center) || info.center;
  const features = parseOSM(data, center);
  state.features = features;
  setLoadingStatus('Costruisco edifici, acqua e illuminazione…');
  await yieldToBrowser();
  const city = buildCity(features, env, { lite: PROFILE().lite, reflect: mirror.uniforms, palette: info.palette, tileCaps: info.tileCaps, stoneParapets: info.stoneParapets });
  setLoadingStatus('Popolo la città con passanti, traffico e luoghi da scoprire…');
  await yieldToBrowser();
  scene.add(city.group);
  state.city = city;
  state.drift = new DriftSystem(city);
  state.collision = new Collision(city.segs, city.bridges, city.waterRings, city.buildingRings);
  state.player = new Player(camera, canvas, state.collision);
  state.player.sensitivity = settings.sens;
  state.player.view = settings.view;
  state.dream = new DreamManager(scene, state.collision);
  avatar = new Avatar(settings.look || defaultAppearance());
  scene.add(avatar.root);
  state.player.avatar = avatar;
  state.player.onStep = (v, surface) => audio.step(v, state.inside ? state.inside.surface : surface, state.inside ? 1 : 0);
  state.player.onLand = (v) => audio.land(v);
  const spawn = findSpawn(features, state.collision, info);
  state.spawn = spawn;
  state.player.teleport(spawn[0], spawn[1], spawn[2]);
  const save = store.get('vid-save-' + info.id, null);
  shops = buildShops(features, state.collision);
  scene.add(shops.group);
  crowd = new Crowd(scene, features, state.collision, shops.shops, { count: isMobile ? 12 : 30 });
  traffic = new Traffic(scene, features, { cars: isMobile ? 8 : 22, trams: isMobile ? 2 : 3 });
  traffic.honk = (x, z) => { const d = Math.hypot(x - state.player.pos.x, z - state.player.pos.z); audio.honk(ui.g.panFor(x, z), Math.max(0.02, 0.14 * (1 - d / 40))); };
  estate = new RealEstate(features, state.collision, scene, { perM2: info.perM2 || 38 });
  driving = new Driving({
    scene, camera, audio, settings, toast: (h, d) => toast(h, d), save: () => saveGame(),
    collision: () => state.collision, traffic: () => traffic, crowd: () => crowd, player: () => state.player, avatar: () => avatar,
    combat: () => combat, city: () => ({ features: state.features, parked: state.city.parked }), pan: (x, z) => ui.g.panFor(x, z),
    onEnter: (v) => {
      toggleViewfinder(false); $('crosshair').hidden = true; $('hudSpeed').hidden = false;
      if (!settings.driveTold) { settings.driveTold = true; saveSettings(); toast(isMobile ? 'Joystick a sinistra per guidare, <em>Usa</em> per scendere.' : '<em>W S</em> gas e freno, <em>A D</em> sterzo, <em>Spazio</em> freno a mano, <em>G</em> clacson, <em>E</em> scendi.', true); }
    },
    onExit: () => { $('hudSpeed').hidden = true; $('crosshair').hidden = !state.player.firstPerson; saveGame(); }
  });
  combat.g.policeCarDist = () => (driving && Number.isFinite(driving.copDist) ? driving.copDist : Infinity);
  combat.g.driving = () => !!(driving && driving.current);
  jobs = new Jobs({
    features, shops: () => shops, crowd: () => crowd, collision: () => state.collision, driving: () => driving, wallet: () => wallet,
    toast: (h, d) => toast(h, d), audio, combat: () => combat, player: () => state.player, night: () => state.night, save: () => saveGame(),
    avatar: () => avatar, parked: () => state.city.parked
  });
  traffic.bell = (x, z) => { const d = Math.hypot(x - state.player.pos.x, z - state.player.pos.z); audio.tramBell(ui.g.panFor(x, z), Math.max(0.02, 0.12 * (1 - d / 60))); };
  story = new Story(save && save.story);
  wallet = new Wallet(save && save.wallet);
  if (save && save.dreamBias) state.dreamBias = save.dreamBias;
  story.on((ev, data) => {
    if (ev === 'message') { audio.buzz(); toast(`Nuovo messaggio da <em>${escapeHtml(data.from)}</em>. Premi P per leggerlo.`, true); refreshHud(); }
    if (ev === 'chapter') { toast(`<em>${escapeHtml(data.title)}</em> · ${escapeHtml(objectiveText())}`, true); refreshHud(); saveGame(); }
  });
  if (save && save.ending === undefined && story.ending === 'torna') spawnNoraBack();
  if (story.ending === 'torna') spawnNoraBack();
  crowd.onHitPlayer = (n) => combat.onNpcHit(n);
  crowd.onCatch = () => combat.onCaught();
  crowd.onSay = (n, text, tone) => {
    const d = Math.hypot(n.x - state.player.pos.x, n.z - state.player.pos.z);
    audio.babble(text, n.voice || 1, ui.g.panFor(n.x, n.z), Math.max(0, 0.11 * (1 - d / 16)), tone);
  };
  // il campanile per l'ultima porta
  state.campanile = features.buildings.find((b) => /campanile/i.test(b.tags.name || '')) || features.buildings.filter((b) => b.tags.building === 'church').sort((a, b) => b.height - a.height)[0] || null;
  estate.load(save && save.estate);
  driving.load(save && save.vehicles);
  jobs.load(save && save.jobs);
  if (save) {
    state.drift.anchor(save.anchors || [], false);
    state.album = save.album || [];
    state.ricordi = save.ricordi || [];
    state.pocket = save.pocket || {};
    Object.assign(state.stats, save.stats || {});
  }
  minimap = new MiniMap($('miniMap'), features, city.extent);
  $('hudCityName').textContent = info.city;
  const meta = data.meta || {};
  const where = state.synthetic ? `${meta.city || 'Quartiere immaginario'} · ${meta.area || 'dati sintetici'}` : `${info.city} · ${info.area}`;
  $('menuWhere').textContent = where;
  $('hudArea').textContent = where;
  if (state.synthetic) {
    $('hudBanner').textContent = 'Quartiere immaginario ispirato ai Navigli. La Milano vera arriva quando i dati di OpenStreetMap saranno scaricati.';
    $('hudBanner').hidden = false;
    setTimeout(() => { $('hudBanner').hidden = true; }, 15000);
  }
  $('btnSolo').disabled = false;
  state.online = await NetClient.probe();
  $('btnCreate').disabled = $('btnJoinShow').disabled = !state.online;
  if (!state.online) $('btnCreate').querySelector('small').textContent = 'Avvia il server incluso per attivare il multiplayer';
  else { net.city = info.short || info.id; net.watchLobby(renderRooms); }
  refreshWeather();
  setLoadingStatus('Città pronta · scegli una modalità e parti', 'ready');
}

function findSpawn(features, col, info) {
  // il posto più bello per cominciare: l'alzaia a Milano, il Lungarno davanti al Ponte Vecchio a Firenze
  const target = info && info.spawn ? features.proj.toXZ(info.spawn.lat, info.spawn.lon) : [-60, 0];
  const re = new RegExp((info && info.spawnStreet) || 'alzaia|ripa', 'i');
  let best = null;
  for (const r of features.roads) {
    if (r.bridge || r.width < 2.5) continue;
    const bonus = re.test(r.name || '') ? -120 : 0;
    for (let i = 0; i < r.pts.length - 1; i++) {
      const p = r.pts[i];
      const d = Math.hypot(p[0] - target[0], p[1] - target[1]) + bonus;
      if ((!best || d < best.d) && col.isFree(p[0], p[1])) best = { d, p, q: r.pts[i + 1] };
    }
  }
  if (!best) return [0, 0, 0];
  const yaw = Math.atan2(-(best.q[0] - best.p[0]), -(best.q[1] - best.p[1]));
  return [best.p[0], best.p[1], yaw];
}

function renderCityPicker() {
  const box = $('cityPick'); if (!box || !state.cities) return;
  box.innerHTML = '';
  const cur = (state.cities.find((c) => c.id === settings.city) || state.cities[0]).id;
  for (const c of state.cities) {
    const b = document.createElement('button');
    b.type = 'button'; b.textContent = c.city; b.title = c.area;
    b.setAttribute('aria-pressed', String(c.id === cur));
    b.onclick = () => { if (c.id === cur) return; settings.city = c.id; saveSettings(); saveGame(); location.reload(); };
    box.appendChild(b);
  }
}

async function refreshWeather() {
  if (!state.cityInfo) return;
  state.weather = presetWeather(settings.weather) || await fetchWeather(state.cityInfo.center);
  state.weatherAt = performance.now();
}

// ---------- tempo e sole ----------
function findSunCrossing(lat, lon, rising) {
  const base = new Date(); base.setUTCHours(0, 0, 0, 0);
  let prev = sunPosition(base, lat, lon).altitude;
  for (let m = 10; m <= 1440; m += 10) {
    const d = new Date(base.getTime() + m * 60000), a = sunPosition(d, lat, lon).altitude;
    if (rising ? (prev < 0 && a >= 0) : (prev >= 0 && a < 0)) return new Date(d.getTime() + (rising ? 10 : -15) * 60000);
    prev = a;
  }
  return base;
}
function gameDate() {
  const c = state.cityInfo.center;
  if (settings.time === 'real') return new Date();
  if (settings.time === 'dawn') return findSunCrossing(c.lat, c.lon, true);
  if (settings.time === 'dusk') return findSunCrossing(c.lat, c.lon, false);
  const d = new Date(); d.setUTCHours(settings.time === 'day' ? 11 : 22, 0, 0, 0);
  return d;
}

// ---------- foto ----------
function toggleViewfinder(on) {
  if (state.inside && on !== false) { toast('Qui dentro la macchina non funziona. Si vede solo nebbia.'); return; }
  state.viewfinder = on ?? !state.viewfinder;
  state.player.forceFirst = state.viewfinder;
  $('viewfinder').hidden = !state.viewfinder;
  $('crosshair').hidden = !state.viewfinder && !state.player.firstPerson;
}

function takePhoto() {
  const d = state.drift;
  if (subs.mods(settings.safe).cantFocus) { audio.shutter(); toast('La macchina non mette a fuoco. Niente resta fermo.', true); return; }
  d.sample(renderer, camera);
  audio.shutter();
  const framed = d.framed(30).slice(0, 14);
  const anomalies = [];
  for (const f of framed) if (!d.anchored[f.bid] && d.isAnomalyVisible(f.bid)) anomalies.push({ bid: f.bid, type: d.type[f.bid], drift: d.drift[f.bid] });
  const bids = framed.map((f) => f.bid).filter((b) => !d.anchored[b]);
  const first = anomalies[0];
  const b = first ? state.features.buildings[first.bid] : framed[0] && state.features.buildings[framed[0].bid];
  const where = (b && addressOf(b)) || state.streetName || 'un angolo senza nome';
  const caption = first ? ANOMALIES[first.type] : (framed.length ? 'com\'è davvero' : 'il cielo');
  state.capture = { where, caption, anomaly: !!first, anomalies: anomalies.length, bids, firstType: first ? first.type : null, drift: first ? first.drift : 0,
    time: localTimeString(gameDate(), state.cityInfo.timezone), date: new Date().toISOString() };
}

function applyPhoto(c) {
  state.drift.anchor(c.bids, true);
  state.flash = 1;
  if (c.bids.length) net.send({ t: 'anchor', bids: c.bids });
  state.stats.photos++;
  if (c.anomaly) {
    state.stats.anomalies += c.anomalies;
    toast(`Anomalia registrata: <em>${c.caption}</em> · ${escapeHtml(c.where)}. Ora resta reale.`, true);
  } else if (c.bids.length) {
    toast(`${c.bids.length === 1 ? 'Un luogo fissato' : c.bids.length + ' luoghi fissati'}: non cambieranno più.`);
  } else {
    toast('Niente di nuovo da fissare in questa inquadratura.');
  }
}

function finishCapture() {
  const c = state.capture;
  state.capture = null;
  const t = document.createElement('canvas'); t.width = 384; t.height = 216;
  const g = t.getContext('2d');
  const sw = canvas.width, sh = canvas.height, ar = 16 / 9;
  let w = sw, h = sw / ar; if (h > sh) { h = sh; w = sh * ar; }
  g.drawImage(canvas, (sw - w) / 2, (sh - h) / 2, w, h, 0, 0, 384, 216);
  c.img = t.toDataURL('image/jpeg', 0.72);
  const record = Object.assign({}, c);
  applyPhoto(c);
  state.album.unshift(record);
  if (state.album.length > 40) state.album.length = 40;
  saveGame();
}

let albumTab = 'photos';
function renderAlbum() {
  $('tabPhotos').setAttribute('aria-selected', String(albumTab === 'photos'));
  $('tabMems').setAttribute('aria-selected', String(albumTab === 'mems'));
  $('albumGrid').hidden = albumTab !== 'photos';
  $('memGrid').hidden = albumTab !== 'mems';
  $('albumStats').textContent = `${state.stats.photos} foto · ${state.stats.anomalies} anomalie · ${state.drift.anchoredList().length} luoghi fissati · ${state.ricordi.length} ricordi`;
  const grid = $('albumGrid');
  grid.innerHTML = '';
  if (!state.album.length) grid.innerHTML = '<p class="empty">Ancora nessuna foto. Alza la macchina con F e scatta: ciò che inquadri torna reale.</p>';
  state.album.forEach((p, i) => {
    const el = document.createElement('figure');
    el.className = 'photo' + (p.ruined ? ' ruined' : '');
    el.style.setProperty('--r', ((i * 37) % 7 - 3) * 0.4 + 'deg');
    el.style.margin = '0';
    el.innerHTML = '<img alt=""><figcaption class="cap"><b></b><div></div><span></span></figcaption>';
    el.querySelector('img').src = p.img || '';
    el.querySelector('b').textContent = p.ruined ? 'Non ricordi' : p.where;
    el.querySelector('div').textContent = p.ruined ? 'La foto è rovinata, il luogo ha ripreso a cambiare.' : (p.anomaly ? 'Anomalia: ' + p.caption : p.caption);
    el.querySelector('span').textContent = p.time;
    grid.appendChild(el);
  });
  const mg = $('memGrid');
  mg.innerHTML = '';
  if (!state.ricordi.length) mg.innerHTML = '<p class="empty">Nessun ricordo. Quando su un palazzo compare una porta che prima non c\'era, entra.</p>';
  for (const r of state.ricordi) {
    const a = document.createElement('article');
    a.innerHTML = '<span></span><h3></h3><p></p>';
    a.querySelector('span').textContent = r.where;
    a.querySelector('h3').textContent = r.title;
    a.querySelector('p').textContent = r.text;
    mg.appendChild(a);
  }
}

// ---------- sogno: soglie, ricordi, uscita ----------
function startTransition(mid) {
  if (state.transition) return;
  audio.whoosh(true);
  state.transition = { t: 0, mid, did: false };
}

function enterDream(th) {
  startTransition(() => {
    const s = state.dream.enter(th.bid, th.special);
    s.noraRicordo = th.special ? null : story.nextRicordo();
    if (s.nora && !crowd.find('nora')) crowd._static('passante', s.nora[0], s.nora[1], 0, { story: 'nora', name: 'Nora', look: { top: '#c2405a', hair: '#3b2618', coat: false } });
    state.inside = s; state.insideFrom = th;
    toggleViewfinder(false);
    state.player.teleport(s.spawn[0], s.spawn[1], s.spawn[2], 0);
    net.sendState(performance.now(), state.player.pos, state.player.facing, 0, 32, true);
    const n = $('dreamName'); n.textContent = s.name; n.classList.add('show');
    setTimeout(() => n.classList.remove('show'), 3500);
  });
}

function exitDream() {
  startTransition(() => {
    const th = state.insideFrom;
    state.dream.leave();
    state.inside = null;
    if (th) {
      // il palazzo torna com'era, e resta così
      state.drift.anchor([th.bid], true);
      net.send({ t: 'anchor', bids: [th.bid] });
      const spot = state.collision.nearestFree(th.x + th.nx * 2.2, th.z + th.nz * 2.2) || state.spawn;
      state.player.teleport(spot[0], spot[1], Math.atan2(th.nx, th.nz) + Math.PI, 0);
      net.sendState(performance.now(), state.player.pos, state.player.facing, 0, 0, true);
    }
    toast('Sei di nuovo fuori. Il palazzo è tornato com\'era.');
  });
}

function showMemory(r, where) {
  state.mode = 'card';
  state.player.enabled = false;
  if (document.pointerLockElement) document.exitPointerLock();
  $('memTitle').textContent = r[0];
  $('memText').textContent = r[1];
  $('memKicker').textContent = 'Ricordo trovato · ' + where;
  $('memoryCard').hidden = false;
  setTimeout(() => $('btnMemClose').focus(), 50);
}
$('btnMemClose').onclick = () => { $('memoryCard').hidden = true; startPlay(); toast('Da qualche parte si è aperta una porta per tornare.', true); refreshHud(); };

// ---------- interazione (E) ----------
function interact() {
  if (state.transition) return;
  const pos = state.player.pos;
  if (state.inside) {
    const s = state.inside;
    if (!s.nora && !s.taken && Math.hypot(pos.x - s.ricordo[0], pos.z - s.ricordo[2]) < 2.6) {
      let r = state.dream.takeRicordo();
      const nora = s.noraRicordo;
      if (nora) r = nora.r;
      audio.chime();
      state.ricordi.unshift({ title: r[0], text: r[1], where: nora ? 'Ricordo di Nora · ' + s.name : s.name, nora: !!nora, date: new Date().toISOString() });
      state.stats.ricordi++;
      showMemory(r, nora ? `ricordo di Nora ${story.noraFound + 1}/7` : s.name);
      story.foundRicordo(!!nora);
      s.noraRicordo = null;
      saveGame();
      return;
    }
    if (s.nora && !s.taken) { const n = crowd.find('nora'); if (n && Math.hypot(pos.x - n.x, pos.z - n.z) < 3) { ui.talk(n); return; } }
    if (s.taken && Math.hypot(pos.x - s.exit.x, pos.z - s.exit.z) < 2.6) exitDream();
    return;
  }
  if (driving && driving.current) { driving.exit(); return; }
  const th = state.threshold;
  if (th && Math.hypot(pos.x - th.x, pos.z - th.z) < 3) { enterDream(th); return; }
  if (state.nearNpc) { if (state.nearNpc.ko > 0) combat.rob(state.nearNpc); else ui.talk(state.nearNpc); return; }
  if (state.nearShop) { ui.openShop(state.nearShop); return; }
  if (state.nearHouse) { openHouse(state.nearHouse); return; }
  const nv = state.nearVehicle;
  if (nv) {
    // per rubare serve una seconda conferma: niente furti per sbaglio
    if (nv.type !== 'mine' && !(state.stealArm && state.stealArm.key === vehKey(nv) && performance.now() - state.stealArm.t < 2500)) {
      state.stealArm = { key: vehKey(nv), t: performance.now() };
      toast(nv.type === 'traffic' ? 'Davvero? Premi di nuovo <em>E</em> per tirare giù l\'autista.' : 'Premi di nuovo <em>E</em> per forzare la portiera. È un furto.');
      return;
    }
    state.stealArm = null;
    driving.enter(nv);
  }
}
const vehKey = (nv) => nv.type + ':' + (nv.i ?? (nv.v && nv.v.id) ?? (nv.t && nv.t.vmax));

// ---------- case ----------
function openHouse(L) {
  ui.g.pause();
  const owned = estate.owned[L.id];
  $('houseWhere').textContent = owned ? 'Casa tua' : 'Agenzia Immobiliare Arno · in vendita';
  $('houseTitle').textContent = `${L.kind} · ${L.address}`;
  $('houseText').textContent = L.kind === 'Palazzina intera'
    ? `Tutto il palazzo, ${L.levels} piani. ${L.size} m² da sistemare a tuo gusto.`
    : `${L.size} m² al ${L.floor === 0 ? 'piano terra' : L.floor + '° piano'}${L.top ? ', con terrazzo sui tetti' : ''}. Finestre sulla via, cucina abitabile, bagno rifatto da poco.`;
  $('houseStats').innerHTML = `<span>Prezzo: ${euro(L.price)}</span><span>Se lo affitti: ${euro(L.rent)} al minuto</span>${owned ? `<span>Uso: ${owned.mode === 'casa' ? 'ci abiti' : 'affittato'}</span>` : ''}`;
  const box = $('houseBtns'); box.innerHTML = '';
  const btn = (label, small, fn, primary, dis) => { const b = document.createElement('button'); b.type = 'button'; b.className = 'btn compact' + (primary ? ' primary' : ''); b.innerHTML = label + (small ? `<small>${small}</small>` : ''); b.disabled = !!dis; b.onclick = fn; box.appendChild(b); return b; };
  if (!owned) {
    btn(`Compra · ${euro(L.price)}`, wallet.canPay(L.price) ? 'Firma dal notaio, paghi subito' : `Ti mancano ${euro(L.price - wallet.money)}`, () => {
      if (!estate.buy(L, wallet)) return;
      audio.cash(); state.stats.spent = (state.stats.spent || 0) + L.price;
      toast(`Hai comprato ${escapeHtml(L.kind.toLowerCase())} in ${escapeHtml(L.address)}. ${estate.owned[L.id].mode === 'casa' ? 'È la tua casa: qui dormi e ti risvegli.' : 'È in affitto: rende mentre giochi.'}`, true);
      saveGame(); openHouse(L);
    }, true, !wallet.canPay(L.price));
  } else {
    if (owned.mode === 'casa') btn('Dormi', 'Energia e salute al massimo, partita salvata', () => {
      wallet.eat(100); combat.health = 100; state.flash = 0.6; audio.chime(); saveGame();
      toast('Dormi qualche ora. Ti svegli riposato, con la luce che entra dalle persiane.', true); closeHouse();
    }, true);
    btn(owned.mode === 'casa' ? 'Mettila in affitto' : 'Vacci ad abitare', owned.mode === 'casa' ? `${euro(L.rent)} al minuto` : 'Diventa la tua casa', () => { estate.setMode(L, owned.mode === 'casa' ? 'affitto' : 'casa'); saveGame(); openHouse(L); });
    btn(`Vendi · ${euro(Math.round(L.price * 0.85))}`, 'L\'agenzia trattiene il 15%', () => { const v = estate.sell(L, wallet); audio.cash(); toast(`Venduta per ${euro(v)}.`); saveGame(); openHouse(L); });
  }
  $('houseMoney').textContent = 'Hai ' + euro(wallet.money);
  $('housePanel').hidden = false;
}
function closeHouse() { $('housePanel').hidden = true; ui.g.resume(); }
$('btnHouseClose').onclick = closeHouse;

// ---------- vita: obiettivi, finale, Nora ----------
function objectiveText() {
  if (!story) return '';
  let t = story.objective();
  if (crowd && crowd.storyBar) t = t.replace('Bar Ringhiera', crowd.storyBar);
  return t;
}
function objectiveTarget() {
  if (jobs && jobs.active) return jobs.target();
  if (state.nav) return state.nav;
  const c = story.current.id;
  const npcPos = (id, label) => { const n = crowd.find(id); return n ? { x: n.x, z: n.z, label } : null; };
  if (c === 'messaggio') return npcPos('marta', 'Marta');
  if (c === 'archivio') { const a = shops.shops.find((s) => s.type === 'archivio'); return a ? { x: a.x, z: a.z, label: 'L\'Archivio' } : null; }
  if (c === 'chiricorda') {
    const P = state.player.pos; let best = null, bd = Infinity;
    for (const [id, label] of [['aldo', 'Aldo'], ['teo', 'Teo'], ['biondo', 'Il Biondo']]) {
      if (story.met[id]) continue;
      const t = npcPos(id, label); if (!t) continue;
      const d = Math.hypot(t.x - P.x, t.z - P.z); if (d < bd) { bd = d; best = t; }
    }
    return best;
  }
  if (c === 'ultima' && state.campanile) { const b = state.campanile; let x = 0, z = 0; for (const p of b.outer) { x += p[0]; z += p[1]; } return { x: x / b.outer.length, z: z / b.outer.length, label: 'Campanile' }; }
  if ((c === 'porte' || c === 'sette') && state.threshold) return { x: state.threshold.x, z: state.threshold.z, label: 'Porta' };
  return null;
}
function refreshHud() {
  if (!story) return;
  $('hudObj').hidden = !(state.mode === 'play' || state.mode === 'ui');
  const job = jobs && jobs.active;
  $('hudChapter').textContent = job ? `Lavoro · ${job.title}${job.legal ? '' : ' · illecito'}` : state.nav ? 'Navigatore' : story.current.title + (story.messages.some((m) => !m.read) ? ' · nuovo messaggio (P)' : '');
  const t = objectiveTarget(), P = state.player && state.player.pos;
  $('hudObjText').textContent = job ? jobs.objective() : state.nav ? `Vai a ${state.nav.label}` : objectiveText();
  if (state.nav && P && Math.hypot(state.nav.x - P.x, state.nav.z - P.z) < 8) state.nav = null;
  $('hudObjDist').textContent = t && P ? `${t.label} · ${Math.round(Math.hypot(t.x - P.x, t.z - P.z))} m` : '';
  $('hudArrow').style.display = t ? '' : 'none';
  state.objTarget = t;
}
function spawnNoraBack() {
  const m = crowd.find('marta');
  if (m && !crowd.npcs.some((n) => n.story === 'nora-back')) crowd._static('passante', m.x + 1.2, m.z + 0.4, m.facing, { story: 'nora-back', name: 'Nora', look: { top: '#c2405a', hair: '#3b2618' } });
}
function ending(kind) {
  story.finish(kind);
  if (kind === 'torna') {
    state.flash = 1; audio.shutter();
    // la Darsena torna reale e resta così
    const c = objectiveTarget() || state.player.pos;
    const near = state.city.buildings.meta.filter((m) => Math.hypot(m.cx - (state.campanile ? state.campanile.outer[0][0] : c.x), m.cz - (state.campanile ? state.campanile.outer[0][1] : c.z)) < 140).map((m) => m.bid);
    state.drift.anchor(near, true);
    spawnNoraBack();
    toast('Nora è tornata. La trovi al bar, con le mani fredde.', true);
  } else {
    state.dreamBias = 1.6;
    toast('Nora resta nel sogno. Da stanotte le porte si aprono più spesso.', true);
  }
  const n = crowd.find('nora'); if (n) n.root.visible = false, n.x = n.z = 1e6;
  state.dream.openExit();
  saveGame();
}

// ---------- interfaccia della vita ----------
let shops = null, crowd = null, story = null, wallet = null, traffic = null, minimap = null, driving = null, estate = null, jobs = null;
const voice = new Voice(net, audio);
const ui = new LifeUI({
  get state() { return state; }, get wallet() { return wallet; }, get story() { return story; }, get crowd() { return crowd; }, get shops() { return shops; },
  subs, audio, settings, avatars, toast: (h, d) => toast(h, d), save: () => saveGame(),
  pause: () => { if (state.mode === 'play') { state.mode = 'ui'; state.player.enabled = false; if (document.pointerLockElement) document.exitPointerLock(); } },
  resume: () => { if (state.mode === 'ui') startPlay(); },
  openCreator: () => openCreator(() => startPlay(), true), objectiveText, objectiveTarget, refreshHud: () => refreshHud(), ending,
  get avatar() { return avatar; },
  get combat() { return combat; },
  get jobs() { return jobs; }, get estate() { return estate; }, get driving() { return driving; },
  setNav: (t) => { state.nav = t; refreshHud(); },
  faceTo: (n) => { const P = state.player; P.facing = Math.atan2(n.x - P.pos.x, n.z - P.pos.z); P.yaw = P.lookYaw = P.facing - Math.PI; },
  clerk: () => state.clerk,
  panFor: (x, z) => { const dx = x - camera.position.x, dz = z - camera.position.z, yaw = camera.rotation.y; return Math.max(-1, Math.min(1, (dx * Math.cos(yaw) - dz * Math.sin(yaw)) / Math.max(2, Math.hypot(dx, dz)))); },
  enterShop: (shop) => {
    // il giocatore si mette davanti alla porta, la telecamera si avvicina, qualcuno si affaccia
    const P = state.player;
    if (shop.type === 'pusher') {
      const n = state.nearNpc || crowd.npcs.find((q) => q.role === 'pusher' && q.root.visible);
      state.clerk = n || null;
      if (n) state.shopCam = { x: n.x, z: n.z, nx: Math.sin(n.facing), nz: Math.cos(n.facing) };
    } else {
      P.teleport(shop.x + shop.nx * 0.4, shop.z + shop.nz * 0.4, Math.atan2(shop.nx, shop.nz));
      const story = crowd.find('marta');
      const isMarta = story && Math.hypot(story.x - shop.x, story.z - shop.z) < 3;
      state.clerk = isMarta ? story : crowd.clerk(shop.doorX + shop.nx * 0.25, shop.doorZ + shop.nz * 0.25, Math.atan2(shop.nx, shop.nz),
        shop.type === 'farmacia' ? { top: '#f2f2f2', bottom: '#2a3a5a' } : shop.type === 'coffeeshop' ? { top: '#1f3a2a', hood: false } : undefined);
      state.shopCam = { x: shop.doorX, z: shop.doorZ, nx: shop.nx, nz: shop.nz };
    }
    P.facing = Math.atan2(-(state.shopCam ? state.shopCam.nx : 0), -(state.shopCam ? state.shopCam.nz : 1));
    if (state.clerk) crowd.talkTo(state.clerk, 60);
    state.shopCamT = 0;
  },
  leaveShop: () => { if (state.clerk) crowd.talkTo(state.clerk, 0.5); if (state.clerk && state.clerk === crowd.clerkNpc) crowd.hideClerk(); state.clerk = null; state.shopCam = null; }
});

// ---------- violenza (opzionale) ----------
function safeSpotNear(x, z) { return state.collision.nearestFree(x, z) || state.spawn; }
const combat = new Combat({
  settings, audio, toast: (h, d) => toast(h, d), save: () => saveGame(),
  crowd: () => crowd, player: () => state.player, avatar: () => avatar, wallet: () => wallet,
  mods: () => (settings.substances ? subs.mods(settings.safe) : {}),
  pan: (x, z) => ui.g.panFor(x, z),
  // Pronto Soccorso: davanti alla farmacia più vicina, altrimenti al punto di partenza
  hospital: () => {
    if (driving && driving.current) driving.exit(true);
    const P = state.player.pos;
    const f = shops.shops.filter((s) => s.type === 'farmacia').sort((a, b) => Math.hypot(a.x - P.x, a.z - P.z) - Math.hypot(b.x - P.x, b.z - P.z))[0];
    const sp = f ? safeSpotNear(f.x + f.nx * 2, f.z + f.nz * 2) : state.spawn;
    state.player.teleport(sp[0], sp[1], f ? Math.atan2(f.nx, f.nz) : sp[2] || 0);
    net.sendState(performance.now(), state.player.pos, state.player.facing, 0, 0, true);
  },
  jail: () => { if (driving && driving.current) driving.exit(true); const H = estate && estate.home; const sp = H ? [H.door.x, H.door.z, Math.atan2(-H.door.nx, -H.door.nz)] : state.spawn; state.player.teleport(sp[0], sp[1], sp[2]); net.sendState(performance.now(), state.player.pos, state.player.facing, 0, 0, true); }
});
function applyViolenceUI() {
  const on = !!settings.violence;
  $('tHit').hidden = !on; $('hintHit').hidden = !on;
  $('hudHealthLbl').hidden = $('hudHealthBar').hidden = !on;
  if (!on) $('hudHeat').hidden = true;
}
applyViolenceUI();

// ---------- blackout dell'Ambra ----------
subs.on('blackout', (kind) => {
  state.stats.blackouts++;
  if (kind === 'collasso') {
    const lost = Math.round(wallet.money * 0.3 * 100) / 100;
    wallet.pay(lost);
    setTimeout(() => toast(`Ti hanno trovato su una panchina, il respiro lentissimo. Qualcuno ha chiamato aiuto. Mancano ${euro(lost)} dal portafoglio.`, true), 400);
  }
  const from = state.inside && state.insideFrom ? { x: state.insideFrom.x, z: state.insideFrom.z } : { x: state.player.pos.x, z: state.player.pos.z };
  if (state.inside) { state.dream.leave(); state.inside = null; }
  const lost = state.album.filter((p) => !p.ruined).slice(0, 2);
  const freed = [];
  for (const p of lost) { p.ruined = true; freed.push(...p.bids); }
  state.drift.release(freed);
  if (freed.length) net.send({ t: 'unanchor', bids: freed });
  for (let k = 0; k < 60; k++) {
    const a = Math.random() * Math.PI * 2, r = 25 + Math.random() * 40;
    const x = from.x + Math.cos(a) * r, z = from.z + Math.sin(a) * r;
    if (state.collision.isFree(x, z)) { state.player.teleport(x, z, Math.random() * Math.PI * 2); net.sendState(performance.now(), state.player.pos, state.player.facing, 0, 0, true); break; }
  }
  toast(lost.length ? `Non ricordi come sei arrivato qui. ${lost.length === 1 ? 'Una foto è rovinata' : 'Due foto sono rovinate'}.` : 'Non ricordi come sei arrivato qui.', true);
  saveGame();
});
subs.on('hangover', () => toast('L\'effetto è passato. Ora la luce fa male e non riesci a correre. In farmacia c\'è l\'aspirina.'));
subs.on('crash', () => toast('La Kokka se ne va tutta insieme: gambe pesanti, ansia, il cuore che non rallenta.', true));
subs.on('trip', (bad) => toast(bad ? 'Il Francobollo arriva, ma arriva storto. Le facciate ti guardano.' : 'Il Francobollo arriva. La città comincia a respirare, e le porte si mostrano.', true));
subs.on('paranoia', () => audio.whisper());

// ---------- interfaccia ----------
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function toast(html, dream) {
  const el = document.createElement('div');
  el.className = 'toast' + (dream ? ' dream' : '');
  el.innerHTML = html;
  $('toasts').appendChild(el);
  setTimeout(() => el.remove(), 6500);
  while ($('toasts').children.length > 4) $('toasts').firstChild.remove();
}
function showPanel(id, on) { $(id).hidden = !on; }

function startPlay() {
  audio.start();
  state.mode = 'play';
  for (const id of ['menu', 'pause', 'albumPanel', 'settingsPanel', 'keysPanel', 'creator', 'memoryCard']) showPanel(id, false);
  for (const id of ['hudPlace', 'hudHint', 'hudTop', 'hudMap']) $(id).hidden = false;
  // i comandi si vedono all'inizio, poi lasciano spazio alla città (H li richiama)
  $('hudHint').classList.remove('faded');
  clearTimeout(state.hintT); state.hintT = setTimeout(() => $('hudHint').classList.add('faded'), 12000);
  $('crosshair').hidden = !state.player.firstPerson;
  $('touchbar').hidden = false;
  state.player.enabled = true;
  state.player.requestLock();
  hintSubstances();
  tutorial();
}
// primi minuti: pochi suggerimenti, uno alla volta, solo la prima volta
function tutorial() {
  if (settings.tutorialDone) return;
  settings.tutorialDone = true; saveSettings();
  const touch = isMobile;
  const steps = [
    [1500, touch ? 'Ti è arrivato un messaggio. Tocca <em>Telefono</em> per leggerlo.' : 'Ti è arrivato un messaggio. Premi <em>P</em> per aprire il telefono.'],
    [9000, 'In alto a sinistra c\'è sempre il tuo obiettivo, con la distanza in metri. La mappa è nel telefono.'],
    [18000, touch ? 'Avvicinati alle persone e tocca <em>Usa</em> per parlare. Non tutte sono gentili.' : 'Avvicinati alle persone e premi <em>E</em> per parlare. Non tutte sono gentili.'],
    [28000, 'Ciò che non guardi cambia. Con <em>F</em> alzi la macchina fotografica: quello che inquadri torna reale.'],
    [40000, 'L\'energia cala camminando. Nei bar, nei forni e in pizzeria si mangia; l\'Archivio compra le foto strane.']
  ];
  for (const [ms, html] of steps) setTimeout(() => { if (state.mode === 'play') toast(html, true); }, ms);
}
function hintSubstances() {
  if (settings.hintSubs || !settings.substances) return;
  settings.hintSubs = true; saveSettings();
  setTimeout(() => { if (state.mode === 'play') toast('Ambra nei bar, Fumo nei coffee shop (verdi sulla mappa), il resto dai tipi col cappuccio nei vicoli (viola). Di giorno vendono meno.', true); }, settings.tutorialDone ? 4000 : 52000);
}

function pauseGame() {
  if (state.mode !== 'play') return;
  state.mode = 'pause';
  state.player.enabled = false;
  toggleViewfinder(false);
  $('pauseStats').textContent = `${state.stats.photos} foto · ${state.stats.anomalies} anomalie · ${state.drift.anchoredList().length} luoghi fissati · ${state.ricordi.length} ricordi`;
  showPanel('pause', true);
  if (document.pointerLockElement) document.exitPointerLock();
}

function renderRoom() {
  $('hintChat').hidden = !net.code;
  if (!net.code) { $('hudRoom').hidden = true; return; }
  $('hudRoom').hidden = false;
  $('roomCode').textContent = net.code;
  const box = $('roomPlayers'); box.innerHTML = '';
  for (const p of state.roomPlayers || []) {
    const c = document.createElement('span'); c.className = 'chip';
    c.innerHTML = `<i class="dot" style="background:${p.color}"></i>`;
    c.append(p.name + (p.id === net.you ? ' (tu)' : '') + (p.id === net.host ? ' · ospita' : ''));
    box.appendChild(c);
  }
}

function playerName() { const n = ($('playerName').value || settings.name || '').trim() || 'Viandante'; settings.name = n; saveSettings(); return n; }

// ---------- creazione del personaggio ----------
let look = sanitizeAppearance(settings.look || defaultAppearance());
let afterCreator = null;
function swatches(id, list, keyName) {
  const box = $(id); box.innerHTML = '';
  for (const c of list) {
    const b = document.createElement('button');
    b.type = 'button'; b.style.background = c; b.setAttribute('aria-label', c);
    b.setAttribute('aria-pressed', String(look[keyName] === c));
    b.onclick = () => { look[keyName] = c; refreshCreator(); };
    box.appendChild(b);
  }
}
function segments(id, list, keyName) {
  const box = $(id); box.innerHTML = '';
  for (const [v, label] of list) {
    const b = document.createElement('button');
    b.type = 'button'; b.textContent = label; b.setAttribute('aria-pressed', String(look[keyName] === v));
    b.onclick = () => { look[keyName] = v; refreshCreator(); };
    box.appendChild(b);
  }
}
function refreshCreator() {
  segments('oBody', OPTIONS.body, 'body'); swatches('oSkin', OPTIONS.skin, 'skin');
  segments('oHair', OPTIONS.hair, 'hair'); swatches('oHairColor', OPTIONS.hairColor, 'hairColor');
  segments('oTop', OPTIONS.top, 'top'); swatches('oTopColor', OPTIONS.topColor, 'topColor');
  swatches('oBottomColor', OPTIONS.bottomColor, 'bottomColor'); segments('oHat', OPTIONS.hat, 'hat');
  $('oHeight').value = look.height;
  if (avatar) avatar.build(look);
}
$('oHeight').oninput = (e) => { look.height = +e.target.value; if (avatar) avatar.build(look); };
$('btnRandomLook').onclick = () => {
  const r = (l) => { const x = l[Math.floor(Math.random() * l.length)]; return Array.isArray(x) ? x[0] : x; };
  look = { body: r(OPTIONS.body), height: 0.93 + Math.random() * 0.14, skin: r(OPTIONS.skin), hair: r(OPTIONS.hair), hairColor: r(OPTIONS.hairColor),
    top: r(OPTIONS.top), topColor: r(OPTIONS.topColor), bottomColor: r(OPTIONS.bottomColor), hat: Math.random() < 0.7 ? 'nessuno' : r(OPTIONS.hat) };
  refreshCreator();
};
function openCreator(then) {
  afterCreator = then || null;
  if (document.pointerLockElement) document.exitPointerLock();
  if (state.player) state.player.enabled = false;
  state.mode = 'creator';
  showPanel('menu', false); showPanel('pause', false);
  for (const id of ['hudObj', 'hudTop', 'hudMap', 'hudVitals', 'hudPlace', 'hudHint']) $(id).hidden = true;
  $('playerName').value = settings.name || '';
  refreshCreator();
  showPanel('creator', true);
  audio.start();
}
$('btnLookDone').onclick = () => {
  settings.look = look; playerName(); saveSettings();
  net.send({ t: 'look', look });
  net.send({ t: 'rename', name: settings.name });
  showPanel('creator', false);
  const next = afterCreator; afterCreator = null;
  if (next) next(); else { state.mode = 'menu'; showPanel('menu', true); }
};

// ---------- menu ----------
const ensureLook = (then) => (settings.look ? then() : openCreator(then));
$('btnSolo').onclick = () => ensureLook(() => { net.leave(); state.roomPlayers = []; renderRoom(); startPlay(); });
$('btnCreate').onclick = () => ensureLook(async () => {
  $('menuErr').textContent = '';
  try {
    const m = await net.create(playerName(), state.cityInfo.id, settings.look);
    onJoined(m);
    const mine = state.drift.anchoredList();
    for (let i = 0; i < mine.length; i += 64) net.send({ t: 'anchor', bids: mine.slice(i, i + 64) });
    startPlay();
    toast(`Stanza creata. Dai il codice <em>${m.code}</em> ai tuoi amici: entrano con «Entra con un codice».`);
  } catch (e) { state.mode = 'menu'; showPanel('menu', true); $('menuErr').textContent = e.message; }
});
$('btnJoinShow').onclick = () => { $('joinRow').hidden = false; $('joinCode').focus(); };
$('joinCode').addEventListener('input', (e) => { e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); });
$('joinCode').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('btnJoin').click(); });
$('btnJoin').onclick = () => {
  $('menuErr').textContent = '';
  const code = $('joinCode').value.trim();
  if (code.length !== 5) { $('menuErr').textContent = 'Il codice ha 5 caratteri.'; return; }
  ensureLook(async () => {
    try { const m = await net.join(code, playerName(), settings.look); onJoined(m); startPlay(); toast('Sei nella stanza ' + m.code + '.'); }
    catch (e) { state.mode = 'menu'; showPanel('menu', true); $('menuErr').textContent = e.message; }
  });
};
$('btnLook').onclick = () => openCreator();
$('copyCode').onclick = () => {
  navigator.clipboard?.writeText(net.code).then(() => toast('Codice copiato.'), () => toast('Codice: ' + net.code));
};
$('btnResume').onclick = startPlay;
$('btnLeave').onclick = () => { voice.leave(); net.leave(); avatars.clear(); state.roomPlayers = []; renderRoom(); saveGame(); state.mode = 'menu'; showPanel('pause', false); showPanel('menu', true); };
const openAlbum = () => { renderAlbum(); showPanel('albumPanel', true); if (state.mode === 'play') { state.mode = 'pause'; state.player.enabled = false; if (document.pointerLockElement) document.exitPointerLock(); } };
$('tabPhotos').onclick = () => { albumTab = 'photos'; renderAlbum(); };
$('tabMems').onclick = () => { albumTab = 'mems'; renderAlbum(); };
$('btnAlbum2').onclick = () => { showPanel('pause', false); openAlbum(); };
$('btnAlbumClose').onclick = () => { showPanel('albumPanel', false); if (state.mode !== 'menu') startPlay(); };
const openSettings = () => { syncSettingsUI(); showPanel('settingsPanel', true); };
$('btnSettings').onclick = openSettings;
$('btnSettings2').onclick = openSettings;
$('btnSettingsClose').onclick = () => { showPanel('settingsPanel', false); };
$('btnKeys').onclick = () => showPanel('keysPanel', true);
$('btnKeysClose').onclick = () => showPanel('keysPanel', false);
$('tPhoto').onclick = () => { if (state.viewfinder) takePhoto(); else toggleViewfinder(true); };
$('tUse').onclick = () => interact();
$('tJump').onclick = () => state.player.jump();
$('tPhone').onclick = () => ui.togglePhone();
$('tTalk').onpointerdown = () => voice.press(true);
$('tTalk').onpointerup = $('tTalk').onpointercancel = () => voice.press(false);
$('tMenu').onclick = pauseGame;
$('tHit').onclick = () => combat.attack();

function syncSettingsUI() {
  $('sSubst').checked = settings.substances; $('sSafe').checked = settings.safe; $('sTime').value = settings.time;
  $('sSens').value = settings.sens; $('sQuality').value = settings.quality; $('sViolence').checked = !!settings.violence;
  $('sWeather').value = settings.weather || 'real'; $('sTraffic').checked = settings.traffic !== false; $('sRefl').checked = settings.reflections !== false; $('sInt').checked = settings.interiors !== false;
  $('sVol').value = settings.volume; $('sView').value = state.player ? state.player.view : settings.view; $('sMic').value = voice.mode;
}
$('sSubst').onchange = (e) => { settings.substances = e.target.checked; saveSettings(); };
$('sSafe').onchange = (e) => { settings.safe = e.target.checked; saveSettings(); };
$('sWeather').onchange = (e) => { settings.weather = e.target.value; saveSettings(); refreshWeather(); };
$('sTraffic').onchange = (e) => { settings.traffic = e.target.checked; saveSettings(); };
$('sRefl').onchange = (e) => { settings.reflections = e.target.checked; saveSettings(); };
$('sInt').onchange = (e) => { settings.interiors = e.target.checked; env.uInterior.value = e.target.checked ? 1 : 0; saveSettings(); };
function setViolence(on) {
  settings.violence = on; $('sViolence').checked = on; saveSettings(); applyViolenceUI();
  toast(settings.violence ? (isMobile ? 'Violenza attiva: tasto <em>Colpisci</em>. Chi è a terra si fruga con <em>Usa</em>.' : 'Violenza attiva: <em>Q</em> o clic per colpire. Chi è a terra si fruga con <em>E</em>.') : 'Violenza spenta.');
}
$('sViolence').onchange = (e) => {
  if (!e.target.checked) { setViolence(false); return; }
  e.target.checked = false;
  showPanel('violenceAsk', true); $('vaNo').focus();
};
$('vaYes').onclick = () => { showPanel('violenceAsk', false); setViolence(true); };
$('vaNo').onclick = () => showPanel('violenceAsk', false);
$('sTime').onchange = (e) => { settings.time = e.target.value; envAt = -1e9; saveSettings(); };
$('sSens').oninput = (e) => { settings.sens = +e.target.value; if (state.player) state.player.sensitivity = settings.sens; saveSettings(); };
$('sVol').oninput = (e) => { settings.volume = +e.target.value; audio.setVolume(settings.volume); saveSettings(); };
$('sMic').onchange = async (e) => {
  try { await voice.setMode(e.target.value); settings.mic = e.target.value; saveSettings(); toast(e.target.value === 'off' ? 'Microfono spento.' : e.target.value === 'ptt' ? 'Microfono pronto: tieni premuto T (o «Parla») per parlare.' : 'Microfono sempre acceso.'); }
  catch (err) { e.target.value = 'off'; toast(escapeHtml(err.message)); }
};
voice.onState = (mode, on) => { const m = $('hudMic'); m.hidden = mode === 'off' || !net.code; m.textContent = on ? 'Stai parlando' : mode === 'ptt' ? 'Microfono: tieni premuto T' : 'Microfono acceso'; m.style.borderColor = on ? 'var(--acqua)' : ''; };
$('sView').onchange = (e) => { settings.view = e.target.value; if (state.player) state.player.view = settings.view; saveSettings(); };
$('sQuality').onchange = (e) => {
  settings.quality = e.target.value; state.autoLite = false; saveSettings();
  applyQualityProfile();
  toast(`Qualità grafica: <em>${({auto:'Automatica',mobile:'Telefono',low:'Leggera',mid:'Media',high:'Alta'})[settings.quality] || 'Automatica'}</em>.`);
};

canvas.addEventListener('wheel', (e) => { if (state.mode === 'creator') state.creatorZoom = Math.min(3.2, Math.max(1.2, (state.creatorZoom ?? 3.0) + e.deltaY * 0.002)); }, { passive: true });
canvas.addEventListener('click', () => {
  if (state.mode !== 'play') return;
  audio.start();
  if (!state.player.locked) { state.player.requestLock(); return; }
  if (state.viewfinder) takePhoto();
  else if (settings.violence) combat.attack();
});
document.addEventListener('pointerlockchange', () => {
  if (!document.pointerLockElement && state.mode === 'play' && !ui.dialogNpc && !matchMedia('(pointer: coarse)').matches) pauseGame();
});
addEventListener('keydown', (e) => {
  if (e.target.tagName === 'INPUT') return;
  if (e.code === 'F3') { e.preventDefault(); state.showPerf = !state.showPerf; $('perfPanel').hidden = !state.showPerf; state.perf.debugAt = performance.now(); state.perf.debugFrames = 0; return; }
  if (state.mode === 'play' && driving && driving.current && /^(KeyF|KeyV|KeyQ|KeyT)$/.test(e.code)) return;
  if (state.mode === 'play' && e.code === 'KeyG' && driving && driving.current) { const v = driving.current; audio.honk(0, 0.16); for (const n of crowd.npcs) if (!crowd.busy(n) && Math.hypot(n.x - v.x, n.z - v.z) < 10 && !n.story) crowd.lookAround(n); return; }
  if (state.mode === 'play') {
    if (e.code === 'KeyF') toggleViewfinder();
    else if (e.code === 'Space') { e.preventDefault(); if (state.viewfinder) takePhoto(); else state.player.jump(); }
    else if (e.code === 'KeyE') interact();
    else if (e.code === 'KeyV') { state.player.toggleView(); settings.view = state.player.view; saveSettings(); $('crosshair').hidden = !state.player.firstPerson; }
    else if (e.code === 'Tab') { e.preventDefault(); openAlbum(); }
    else if (e.code === 'KeyP') ui.togglePhone(true);
    else if (e.code === 'KeyT' && !e.repeat) voice.press(true);
    else if (e.code === 'KeyQ' && !e.repeat) combat.attack();
    else if (e.code === 'KeyI') { ui.phoneApp = 'pocket'; ui.togglePhone(true); }
    else if (e.code === 'Escape') pauseGame();
    else if (e.code === 'KeyH') { $('hudHint').classList.toggle('faded'); }
    else if ((e.code === 'Enter' || e.code === 'NumpadEnter') && net.code) { e.preventDefault(); openChat(); }
  } else if ((e.code === 'KeyP' || e.code === 'KeyI') && !$('phone').hidden) ui.togglePhone(false);
  else if (e.code === 'Escape' && state.mode === 'ui') { if (!$('phone').hidden) ui.togglePhone(false); else if (!$('shopPanel').hidden) ui.closeShop(); }
  else if (e.code === 'Escape' && ui.dialogNpc) ui.closeDialog();
  if (ui.dialogNpc && /^Digit[1-4]$/.test(e.code)) { const b = document.querySelectorAll('#dlgChoices button')[+e.code.slice(5) - 1]; if (b) b.click(); }
});
addEventListener('keyup', (e) => { if (e.code === 'KeyT') voice.press(false); });
addEventListener('keydown', (e) => { if (state.mode !== 'play' && e.code === 'Tab' && !$('albumPanel').hidden) { e.preventDefault(); $('btnAlbumClose').click(); } });


// ---------- chat e stanze aperte ----------
function openChat() {
  const box = $('chatBox'), inp = $('chatInput');
  box.hidden = false; inp.value = '';
  state.player.enabled = false;
  if (document.pointerLockElement) document.exitPointerLock();
  setTimeout(() => inp.focus(), 10);
}
function closeChat() { $('chatBox').hidden = true; if (state.mode === 'play') { state.player.enabled = true; state.player.requestLock(); } }
$('chatInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    const t = e.target.value.trim();
    if (t) { net.send({ t: 'chat', text: t }); toast(`<em>${escapeHtml(settings.name || 'Tu')}</em>: ${escapeHtml(t)}`); }
    closeChat();
  } else if (e.key === 'Escape') closeChat();
  e.stopPropagation();
});
function renderRooms(rooms) {
  const box = $('roomList');
  const mine = rooms.filter((r) => r.city === net.city && r.code !== net.code);
  box.hidden = !mine.length;
  box.innerHTML = '';
  for (const r of mine.slice(0, 5)) {
    const b = document.createElement('button');
    b.type = 'button';
    const who = document.createElement('span'); who.textContent = `Gioca con ${r.names.slice(0, 3).join(', ')}${r.names.length > 3 ? '…' : ''}`;
    const code = document.createElement('b'); code.textContent = r.code;
    b.append(who, code);
    b.onclick = () => { $('joinCode').value = r.code; $('btnJoin').click(); };
    box.appendChild(b);
  }
}

// ---------- rete ----------
function onJoined(m) {
  if (m.players.length > 1 && !state.offsetDone) {
    const p = state.player.pos;
    for (let k = 0; k < 30; k++) {
      const a = Math.random() * Math.PI * 2, r = 2.5 + Math.random() * 3;
      if (state.collision.isFree(p.x + Math.cos(a) * r, p.z + Math.sin(a) * r)) { state.player.teleport(p.x + Math.cos(a) * r, p.z + Math.sin(a) * r, state.player.yaw); break; }
    }
    state.offsetDone = true;
  }
  state.roomPlayers = m.players;
  for (const b of m.anchors) state.drift.anchored[b] = 1;
  avatars.clear();
  for (const p of m.players) if (p.id !== net.you) avatars.ensure(p.id, p.name, p.color, sanitizeAppearance(p.look));
  renderRoom();
  audio.start();
  voice.joinRoom(m.players);
  voice._notify();
}
net.on('peer', (m) => {
  if (m.ev === 'join') { state.roomPlayers = (state.roomPlayers || []).filter((p) => p.id !== m.id).concat([{ id: m.id, name: m.name, color: m.color, look: m.look }]); avatars.ensure(m.id, m.name, m.color, sanitizeAppearance(m.look)); toast(`${escapeHtml(m.name)} è arrivato in città.`); }
  if (m.ev === 'leave') { const p = (state.roomPlayers || []).find((q) => q.id === m.id); state.roomPlayers = (state.roomPlayers || []).filter((q) => q.id !== m.id); avatars.remove(m.id); if (p) toast(`${escapeHtml(p.name)} si è allontanato.`); }
  if (m.ev === 'rename') { const p = (state.roomPlayers || []).find((q) => q.id === m.id); if (p) p.name = m.name; avatars.ensure(m.id, m.name); }
  if (m.ev === 'look') { const p = (state.roomPlayers || []).find((q) => q.id === m.id); if (p) p.look = m.look; avatars.ensure(m.id, null, null, sanitizeAppearance(m.look)); }
  if (m.host) net.host = m.host;
  renderRoom();
});
net.on('snap', (m) => {
  const now = performance.now();
  for (const s of m.ps) {
    if (s.id === net.you) continue;
    const info = (state.roomPlayers || []).find((p) => p.id === s.id);
    avatars.ensure(s.id, info && info.name, info && info.color, info && sanitizeAppearance(info.look));
    avatars.push(s.id, s, now);
  }
});
net.on('anchor', (m) => {
  state.drift.anchor(m.bids, true);
  const p = (state.roomPlayers || []).find((q) => q.id === m.by);
  if (p) toast(`${escapeHtml(p.name)} ha fissato ${m.bids.length === 1 ? 'un luogo' : m.bids.length + ' luoghi'}.`);
});
net.on('unanchor', (m) => state.drift.release(m.bids));
net.on('chat', (m) => toast(`<em>${escapeHtml(m.name)}</em>: ${escapeHtml(m.text)}`));
net.on('status', (m) => {
  if (m.state === 'reconnecting') toast('Connessione persa, mi ricollego…');
  if (m.state === 'reconnected') { onJoined(m.m); toast('Di nuovo nella stanza.'); }
  if (m.state === 'lost') toast('Non riesco a ricollegarmi. Continui da solo: le tue foto restano salvate.');
});

// ---------- salvataggio ----------
function saveGame() {
  if (!state.cityInfo || !state.drift) return;
  store.set('vid-save-' + state.cityInfo.id, { anchors: state.drift.anchoredList(), album: state.album, ricordi: state.ricordi, stats: state.stats,
    story: story && story.toJSON(), wallet: wallet && wallet.toJSON(), dreamBias: state.dreamBias, pocket: state.pocket,
    estate: estate && estate.toJSON(), vehicles: driving && driving.saveList(), jobs: jobs && jobs.toJSON() });
}
addEventListener('beforeunload', saveGame);

// ---------- ciclo ----------
function nearestStreet(x, z) {
  let best = null, bd = 30;
  for (const r of state.features.roads) {
    if (!r.name) continue;
    for (let i = 0; i < r.pts.length - 1; i++) {
      const a = r.pts[i], b = r.pts[i + 1];
      const dx = b[0] - a[0], dz = b[1] - a[1], l2 = dx * dx + dz * dz || 1;
      const t = Math.max(0, Math.min(1, ((x - a[0]) * dx + (z - a[1]) * dz) / l2));
      const d = Math.hypot(x - a[0] - dx * t, z - a[1] - dz * t);
      if (d < bd) { bd = d; best = r.name; }
    }
  }
  return best;
}
function busker() {
  const n = crowd && crowd.find('teo');
  if (!n || state.inside) return 0;
  const d = Math.hypot(n.x - state.player.pos.x, n.z - state.player.pos.z);
  return Math.max(0, 1 - d / 40);
}
function waterDistance(x, z) {
  // distanza dalla riva più vicina (ai tratti, non solo ai vertici: gli argini dell'Arno sono lunghi e dritti)
  let bd = 999;
  for (const ring of state.city.waterRings) for (let i = 0; i < ring.length; i++) {
    const a = ring[i], b = ring[(i + 1) % ring.length];
    const dx = b[0] - a[0], dz = b[1] - a[1], l2 = dx * dx + dz * dz || 1;
    const t = Math.max(0, Math.min(1, ((x - a[0]) * dx + (z - a[1]) * dz) / l2));
    bd = Math.min(bd, Math.hypot(x - a[0] - dx * t, z - a[1] - dz * t));
  }
  return bd;
}
function assignLights(points, color, intensity, from) {
  const sorted = points.map((p) => [p, (p[0] - from.x) ** 2 + (p[2] - from.z) ** 2]).sort((a, b) => a[1] - b[1]);
  pool.forEach((l, i) => {
    const p = sorted[i];
    if (!p || intensity <= 0.01) { l.intensity = 0; return; }
    l.position.set(p[0][0], p[0][1], p[0][2]); l.color.setHex(color); l.intensity = intensity;
  });
}
const hourFmt = new Intl.DateTimeFormat('it-IT', { timeZone: 'Europe/Rome', hour: 'numeric', minute: 'numeric', hourCycle: 'h23' });

// icone meteo (tratto sottile, colore ambra dalla CSS)
const WX_ICON = {
  sun: '<circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2.4M12 19.1v2.4M2.5 12h2.4M19.1 12h2.4M5.3 5.3l1.7 1.7M17 17l1.7 1.7M5.3 18.7 7 17M17 7l1.7-1.7"/>',
  moon: '<path d="M19.5 14.5A8 8 0 0 1 9.5 4.5a8 8 0 1 0 10 10z"/>',
  cloud: '<path d="M7 18.5h10.5a4 4 0 0 0 .4-8 6 6 0 0 0-11.5 1.6A3.3 3.3 0 0 0 7 18.5z"/>',
  part: '<path d="M8.5 6.5a3.6 3.6 0 0 1 6.4 1.4"/><path d="M5.5 3.8 6.6 5M3.5 9.5H5M11.5 2.5v1.6"/><path d="M7.5 19.5h9.5a3.6 3.6 0 0 0 .4-7.2 5.4 5.4 0 0 0-10.4 1.5 2.9 2.9 0 0 0 .5 5.7z"/>',
  rain: '<path d="M7 15.5h10.5a4 4 0 0 0 .4-8 6 6 0 0 0-11.5 1.6A3.3 3.3 0 0 0 7 15.5z"/><path d="M8.5 18.5l-1 2.5M12.5 18.5l-1 2.5M16.5 18.5l-1 2.5"/>',
  storm: '<path d="M7 14.5h10.5a4 4 0 0 0 .4-8 6 6 0 0 0-11.5 1.6A3.3 3.3 0 0 0 7 14.5z"/><path d="M12.5 15.5l-2 3.5h3l-2 3.5"/>',
  fog: '<path d="M4 9.5h16M6 13h12M4 16.5h16M7 20h10"/>',
  snow: '<path d="M7 14.5h10.5a4 4 0 0 0 .4-8 6 6 0 0 0-11.5 1.6A3.3 3.3 0 0 0 7 14.5z"/><path d="M9 18.5v.1M12.5 20v.1M16 18.5v.1"/>'
};
function wxIcon(w, night) {
  const c = w.weatherCode;
  if (c >= 95) return WX_ICON.storm;
  if (c >= 71 && c <= 86 && !(c >= 80 && c <= 82)) return WX_ICON.snow;
  if (c >= 51) return WX_ICON.rain;
  if (c === 45 || c === 48) return WX_ICON.fog;
  if (c === 3 || w.cloudCover > 80) return WX_ICON.cloud;
  if (c === 2 || w.cloudCover > 40) return night > 0.5 ? WX_ICON.cloud : WX_ICON.part;
  return night > 0.5 ? WX_ICON.moon : WX_ICON.sun;
}
const _fw = new THREE.Vector3();
function cameraHeading() { camera.getWorldDirection(_fw); return Math.atan2(_fw.x, -_fw.z); }

let last = performance.now();
let lightsT = 0;
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  if (!state.city) { renderer.clear(); return; }
  const t = now / 1000;
  env.uTime.value = t; sky.uniforms.uTime.value = t;
  const P = state.player, inside = state.inside;
  const simActive = state.mode === 'play' || state.mode === 'ui';

  // sole e meteo
  if (now - state.weatherAt > 10 * 60_000) { state.weatherAt = now; refreshWeather(); }
  const date = gameDate();
  const c = state.cityInfo.center;
  const sp = sunPosition(date, c.lat, c.lon);
  const w = state.weather;
  const raining = w.precipitation > 0.05;
  state.wetness += ((raining ? Math.min(1, 0.45 + w.precipitation * 0.25) : 0) - state.wetness) * Math.min(1, dt * (raining ? 0.2 : 0.01));
  env.uWet.value = inside ? 0 : state.wetness;
  const atm = computeAtmosphere(env, sky.uniforms, sunDirection(sp), sp.altitude, w, state.drift.avg, moonPhase(date));
  if (now - envAt > (isMobile ? 60000 : 20000)) { envAt = now; updateEnvMap(); }
  state.drift.visibleRange = atm.visibleRange;
  sky.mesh.position.copy(camera.position);
  sky.mesh.visible = !inside;
  lightsT -= dt;
  const relight = lightsT <= 0;
  if (relight) lightsT = 0.4;
  if (inside) {
    scene.fog.color.setRGB(...inside.fog); scene.fog.density = inside.fogDensity;
    sun.intensity = 0; sun.castShadow = false;
    hemi.intensity = inside.kind === 'corridoio' ? 0.35 : 0.6; hemi.color.setRGB(...inside.fog); hemi.groundColor.setRGB(0.25, 0.22, 0.25);
    scene.environmentIntensity = 0.3;
    renderer.toneMappingExposure = 1.05;
    if (relight) assignLights(inside.lights, inside.lightColor, inside.lightPower || 12, P.pos);
  } else {
    scene.fog.color.copy(atm.fogColor); scene.fog.density = Math.max(atm.fogDensity, PROFILE().minFog);
    sun.color.copy(atm.sunColor); sun.intensity = atm.sunIntensity;
    sun.target.position.set(P.pos.x, 0, P.pos.z);
    sun.position.copy(sun.target.position).addScaledVector(env.uSunDir.value, 150);
    // di notte la luce direzionale diventa la luna: fredda, debole, con ombre vere; più forte quando è piena
    const moonDir = sky.uniforms.uMoonDir.value;
    if (atm.night > 0.5 && moonDir.y > 0.05) {
      const full = 1 - Math.abs(sky.uniforms.uMoonPhase.value - 0.5) * 2;
      const k = (atm.night - 0.5) * 2 * Math.min(1, moonDir.y * 4) * (0.15 + 0.85 * full) * (1 - atm.overcast * 0.85);
      sun.color.setRGB(0.62, 0.7, 0.95); sun.intensity = 0.42 * k;
      sun.position.copy(sun.target.position).addScaledVector(moonDir, 150);
    }
    sun.castShadow = sun.intensity > 0.05 && PROFILE().shadow > 0;
    hemi.color.copy(atm.hemiSky); hemi.groundColor.copy(atm.hemiGround); hemi.intensity = atm.hemiIntensity;
    scene.environmentIntensity = atm.envIntensity;
    renderer.toneMappingExposure = atm.exposure;
    state.city.lamps.lanternMat.emissiveIntensity = atm.night * 3.2;
    if (relight) assignLights(state.city.lamps.heads, 0xffb36b, atm.night * 30, P.pos);
  }
  if (simActive) state.dream.update(dt, t);
  state.night = atm.night;

  // temporale: lampi che illuminano tutto, il tuono arriva dopo
  if (!inside && w.weatherCode >= 95) {
    state.boltT = (state.boltT ?? 4) - dt;
    if (state.boltT <= 0) {
      state.boltT = 5 + Math.random() * 14;
      state.bolt = settings.safe ? 0.25 : 1;
      const delay = 400 + Math.random() * 2600;
      setTimeout(() => audio.thunder(1 - delay / 3500), delay);
    }
  }
  state.bolt = Math.max(0, (state.bolt || 0) - dt * 2.8);
  if (state.bolt > 0) { hemi.intensity += state.bolt * 2.5 * (0.6 + 0.4 * Math.sin(t * 60)); renderer.toneMappingExposure += state.bolt * 0.5; }

  // giocatore e sostanze
  if (simActive) subs.update(dt);
  const mods = settings.substances ? subs.mods(settings.safe) : { speed: 1, lag: 0, sway: 0, noSprint: false, driftMul: 1, drunk: 0, hangover: 0, doorEase: 0, muffle: 0 };
  const tired = wallet && wallet.energy < 15;
  if (tired) mods.noSprint = true;
  const dres = simActive && driving ? driving.update(dt, { night: state.night }) : null;
  const step = dres ? { speed: 0, run: false, kmh: dres.kmh } : P.update(dt, mods);
  if (dres) $('hudKmh').textContent = dres.kmh;
  if (wallet && state.mode === 'play') wallet.update(dt, step.speed, step.run);
  if (simActive && estate && wallet) estate.update(dt, wallet, (v) => toast(`Affitti incassati: <em>+${euro(v)}</em>`));
  if (simActive && jobs) jobs.update(dt);
  if (tired && !state.tiredWarned) { state.tiredWarned = true; toast('Sei stanco morto. Mangia qualcosa: un trancio, un cornetto, un panino.'); }
  if (!tired) state.tiredWarned = false;
  // la gente
  if (crowd && simActive) {
    crowd.update(dt, { player: P.pos, night: state.night, drift: inside ? 0 : state.drift.avg, trip: mods.trip || 0 });
    if (!dres) crowd.pushOut(P.pos, step.speed, { drift: state.drift.avg, trip: mods.trip || 0, violence: !!settings.violence && !inside });
    combat.update(dt, () => state.mode === 'play');
  }
  if (shops && simActive) shops.update(state.night, t);
  // traffico: auto e tram attorno al giocatore
  if (traffic && simActive) {
    traffic.update(dt, P.pos, atm.night, !inside && settings.traffic !== false);
    if (!dres) traffic.pushOut(P.pos);
    state.carNearT = (state.carNearT || 0) - dt;
    if (state.carNearT <= 0) {
      state.carNearT = 0.25;
      let near = 0;
      for (const v of traffic.positions()) near = Math.max(near, 1 - Math.hypot(v.x - P.pos.x, v.z - P.pos.z) / 30);
      audio.engines(inside ? 0 : near);
    }
  }
  // al banco: inquadratura sopra la spalla, verso la porta
  if (state.shopCam && state.mode === 'ui') {
    const c = state.shopCam;
    state.shopCamT = Math.min(1, (state.shopCamT || 0) + dt * 2.5);
    const k = state.shopCamT * state.shopCamT * (3 - 2 * state.shopCamT);
    const rx = c.nz, rz = -c.nx;
    if (!c.cam) {
      // cerca un punto libero dietro e di lato al giocatore (sull'alzaia ci sono platani e lampioni)
      c.cam = [P.pos.x + c.nx * 1.3, P.pos.z + c.nz * 1.3];
      outer: for (const back of [2.2, 1.8, 1.4]) for (const side of [0.8, -0.8, 0.3]) {
        const x = P.pos.x + c.nx * back + rx * side, z = P.pos.z + c.nz * back + rz * side;
        if (state.collision.isFree(x, z)) { c.cam = [x, z]; break outer; }
      }
    }
    const target = new THREE.Vector3(c.cam[0], P.y + 1.75, c.cam[1]);
    camera.position.lerp(target, k);
    camera.lookAt(c.x, P.y + 1.45, c.z);
    avatar.root.visible = true;
  }
  if (state.mode === 'creator' && avatar) {
    // nella creazione del personaggio lo guardiamo di fronte, leggermente spostato a sinistra del pannello
    const f = P.facing, ax = P.pos.x, az = P.pos.z;
    const fx = Math.sin(f), fz = Math.cos(f), rx = Math.cos(f), rz = -Math.sin(f);
    // rotella: avvicina la telecamera fino al viso
    const zd = state.creatorZoom ?? 3.0, zk = (3.0 - zd) / 1.8, side = 0.9 * (zd / 3.0);
    camera.position.set(ax + fx * zd - rx * side, P.y + 1.35 + zk * 0.32, az + fz * zd - rz * side);
    camera.lookAt(ax - rx * side, P.y + 1.0 + zk * 0.72, az - rz * side);
    avatar.root.visible = true;
  }
  camera.fov += ((state.viewfinder ? 48 : 65) - camera.fov) * Math.min(1, dt * 8);
  camera.updateProjectionMatrix();
  const wr = (w.windDirection || 0) * Math.PI / 180, ws = Math.min(8, (w.windSpeed || 0) / 3.6);
  const snowing = (w.weatherCode >= 71 && w.weatherCode <= 77) || w.weatherCode === 85 || w.weatherCode === 86;
  rain.update(dt, camera.position, raining && !inside ? Math.min(1, 0.15 + w.precipitation * 0.3) : 0, [-Math.sin(wr) * ws, Math.cos(wr) * ws], snowing);

  // deriva (solo in città)
  if (!inside && simActive) {
    state.sampleT -= dt;
    if (state.sampleT <= 0) { state.sampleT = 0.25; state.drift.sampleAsync(renderer, camera); }
    const rateMul = (w.visibility < 1500 ? 1.8 : 1) * (raining ? 1.4 : 1) * (1 + 0.4 * atm.night) * mods.driftMul * state.dreamBias;
    state.drift.update(dt, rateMul);
    if (story && story.current.id === 'ultima' && atm.night > 0.5 && state.campanile && Math.hypot(state.campanile.outer[0][0] - P.pos.x, state.campanile.outer[0][1] - P.pos.z) < 70) {
      state.threshold = state.dream.forceThreshold(state.campanile, P.pos, 'cortile') || state.threshold;
    } else state.threshold = state.dream.updateThreshold(state.drift, state.features, P.pos, now, mods.doorEase || 0);
  }

  // via, ora, prompt — non fare scansioni stradali mentre il gioco è in pausa o nel menu
  if (simActive) {
  state.streetT -= dt;
  if (state.streetT <= 0) {
    state.streetT = 0.3;
    if (!inside) {
      const s = nearestStreet(P.pos.x, P.pos.z);
      if (s) state.streetName = s;
      state.waterDist = waterDistance(P.pos.x, P.pos.z);
      state.nearWater = Math.max(0, 1 - state.waterDist / 25);
      state.seeWater = state.waterDist < 140;
    }
    $('hudStreet').textContent = inside ? inside.name : (state.streetName || state.cityInfo.city);
    if (inside) { $('hudClock').textContent = '--:--'; $('hudWx').textContent = 'non sai che ora è'; $('hudWxIcon').innerHTML = WX_ICON.moon; }
    else { $('hudClock').textContent = localTimeString(date, state.cityInfo.timezone); $('hudWx').textContent = describeWeather(w) + (w.source === 'open-meteo' ? '' : ' · simulato'); $('hudWxIcon').innerHTML = wxIcon(w, atm.night); }
    state.nearNpc = null; state.nearShop = null; state.nearHouse = null; state.nearVehicle = null;
    let prompt = null;
    if (inside) {
      const nora = inside.nora && !inside.taken ? crowd.find('nora') : null;
      if (nora && Math.hypot(P.pos.x - nora.x, P.pos.z - nora.z) < 3) prompt = 'Parla con Nora';
      else if (!inside.nora && !inside.taken && Math.hypot(P.pos.x - inside.ricordo[0], P.pos.z - inside.ricordo[2]) < 2.6) prompt = 'Prendi il ricordo';
      else if (inside.taken && Math.hypot(P.pos.x - inside.exit.x, P.pos.z - inside.exit.z) < 2.6) prompt = 'Torna fuori';
    } else {
      const th = state.threshold;
      if (th && Math.hypot(P.pos.x - th.x, P.pos.z - th.z) < 3) prompt = th.special ? 'Apri l\'ultima porta' : 'Apri la porta che prima non c\'era';
      else {
        const n = crowd && crowd.nearest(P.pos, 2.6);
        if (n && n.ko > 0) { if (settings.violence) { state.nearNpc = n; prompt = n.robbed ? null : 'Fruga nelle tasche'; } }
        else if (n && crowd.busy(n)) { /* scappa o ti viene addosso: niente chiacchiere */ }
        else if (n && n !== crowd.clerkNpc) { state.nearNpc = n; prompt = 'Parla con ' + (n.name || ({ passante: 'il passante', anziano: 'la persona anziana', rider: 'il rider', turista: 'il turista', studente: 'lo studente', impiegato: 'l\'impiegato', cameriere: 'il cameriere', musicista: 'il musicista', pusher: 'il tipo col cappuccio', senzatetto: 'il senzatetto' }[n.role] || 'qualcuno')); }
        if (!state.nearNpc && !(n && (n.ko > 0 || crowd.busy(n)))) {
          for (const sh of (shops ? shops.shops : [])) if (Math.hypot(sh.x - P.pos.x, sh.z - P.pos.z) < 2.6) { state.nearShop = sh; break; }
          if (state.nearShop) prompt = 'Entra · ' + state.nearShop.name;
          else if (estate && (state.nearHouse = estate.near(P.pos))) { const L = state.nearHouse; prompt = estate.owned[L.id] ? `Casa tua · ${L.address}` : `Vendesi · ${L.kind} ${L.size} m² · ${euro(L.price)}`; }
          else if (driving && (state.nearVehicle = driving.nearest(P.pos))) prompt = state.nearVehicle.label;
        }
      }
    }
    // obiettivo, soldi, energia, telefono
    refreshHud();
    if (wallet) {
      $('hudVitals').hidden = state.mode !== 'play';
      $('hudMoney').textContent = euro(wallet.money);
      $('hudEnergy').style.width = Math.round(wallet.energy) + '%';
      $('hudEnergyBar').classList.toggle('low', wallet.energy < 25);
      $('hudHealth').style.width = Math.round(combat.health) + '%';
      const stars = combat.stars(), hh = $('hudHeat');
      hh.hidden = !stars || state.mode !== 'play';
      if (stars) { hh.innerHTML = `Ricercato <b>${'★'.repeat(stars)}${'☆'.repeat(3 - stars)}</b>`; hh.classList.toggle('blink', crowd.police.some((n) => n.chase) || !!(driving && driving.cops.length)); }
    }
    state.clock = localTimeString(date, state.cityInfo.timezone);
    if (!$('phone').hidden && ui.phoneApp === 'map') ui.drawMap();
    if (state.dialogNpc !== ui.dialogNpc) state.dialogNpc = ui.dialogNpc;
    if (ui.dialogNpc && Math.hypot(ui.dialogNpc.x - P.pos.x, ui.dialogNpc.z - P.pos.z) > 5) ui.closeDialog();
    const pr = $('hudPrompt');
    if (driving && driving.current) prompt = 'Scendi';
    else if (driving && driving.lock) prompt = 'Forzi la serratura…';
    if (prompt && state.mode === 'play' && !state.transition && !ui.dialogNpc) { pr.hidden = false; pr.innerHTML = `<kbd>E</kbd>${escapeHtml(prompt)}`; }
    else pr.hidden = true;
    const st = settings.substances ? subs.describe() : null;
    $('hudStatus').hidden = !st || state.mode !== 'play'; $('hudStatus').textContent = st || '';
    state.saveT -= 0.3;
    if (state.saveT <= 0) { state.saveT = 20; saveGame(); }
    // campane: ora locale della città
    const parts = hourFmt.formatToParts(date);
    state.localH = +parts.find((p) => p.type === 'hour').value;
    state.localM = +parts.find((p) => p.type === 'minute').value;
  }
  }

  // passaggio verso il sogno e ritorno: bianco che sale e scende
  if (state.transition) {
    const tr = state.transition;
    tr.t += dt;
    if (!tr.did && tr.t >= 1.2) { tr.did = true; tr.mid(); }
    state.white = tr.t < 1.2 ? tr.t / 1.2 : Math.max(0, 1 - (tr.t - 1.2) / 1.6);
    if (tr.t > 2.8) { state.transition = null; state.white = 0; }
  }

  audio.update({ night: atm.night, day: atm.day, rain: raining ? w.precipitation : 0, wind: w.windSpeed || 0, nearWater: inside ? 0 : state.nearWater,
    drift: inside ? 0 : state.drift.avg, drunk: mods.muffle ?? mods.drunk, inside: inside ? 1 : 0, localHour: state.localH, localMinute: state.localM,
    heart: mods.heart || 0, busker: busker() });
  voice.update(camera, avatars, now);

  // rete
  const flags = (state.viewfinder ? 1 : 0) | (Math.round(mods.drunk * 7) << 1) | (P.grounded ? 0 : 16) | (inside ? 32 : 0) | (avatar && avatar.gest && avatar.gest.kind === 'punch' ? 64 : 0) | ((driving ? driving.netKind : 0) << 7);
  if (simActive) net.sendState(now, P.pos, P.facing, P.pitch, flags);
  if (simActive) avatars.update(now, dt, camera.position);
  // joystick sotto il pollice sinistro
  const tm = P.touch.move, js = $('joy');
  if (tm) { js.hidden = false; js.style.left = tm.x + 'px'; js.style.top = tm.y + 'px'; $('joyKnob').style.transform = `translate(${P.touch.mx * 34}px, ${P.touch.mz * 34}px)`; }
  else if (!js.hidden) js.hidden = true;

  // bussola dell'obiettivo e minimappa
  if (state.mode === 'play' || state.mode === 'ui') {
    const heading = cameraHeading();
    const T = state.objTarget;
    if (T) $('hudArrow').style.transform = `rotate(${Math.atan2(T.x - P.pos.x, -(T.z - P.pos.z)) - heading}rad)`;
    if (minimap && !inside) {
      const peers = [];
      for (const [id, a] of avatars.list) { const info = (state.roomPlayers || []).find((q) => q.id === id); peers.push({ x: a.group.position.x, z: a.group.position.z, color: (info && info.color) || '#f2b8c6' }); }
      minimap.draw(now, P.pos, heading, { target: T, peers, vehicles: traffic ? traffic.positions() : [] });
    }
  }

  // immagine
  state.flash = Math.max(0, state.flash - dt * 3);
  const pu = post.uniforms;
  pu.uTime.value = t; pu.uDream.value = inside ? 0 : state.drift.avg; pu.uDrunk.value = mods.drunk;
  pu.uHangover.value = mods.hangover * (0.4 + 0.6 * atm.day);
  pu.uBlack.value = Math.max(subs.black, combat.black);
  $('hudHurt').style.opacity = settings.violence ? Math.min(1, combat.flash * 0.8 + Math.max(0, (40 - combat.health) / 40) * 0.6) : 0; pu.uFlash.value = state.flash * 0.6; pu.uSafe.value = settings.safe ? 1 : 0;
  pu.uInside.value = inside ? 1 : 0; pu.uWhite.value = state.white * (settings.safe ? 0.6 : 1);
  pu.uStim.value = mods.stim || 0; pu.uOpi.value = mods.opi || 0; pu.uWeed.value = mods.weed || 0; pu.uTrip.value = mods.trip || 0;
  pu.uBad.value = mods.badTrip || 0; pu.uNod.value = mods.nod || 0; pu.uTired.value = wallet ? Math.max(0, (20 - wallet.energy) / 20) : 0;
  post.bloom.strength = inside ? 0.8 : 0.22 + atm.night * 0.5;
  post.bloom.threshold = inside ? 0.9 : 1.6 - atm.night * 0.9;
  // riflesso nell'acqua: solo quando il canale è vicino e la qualità lo permette
  if (simActive && !inside && wantReflections() && state.city.waterMesh && state.seeWater) mirror.render(scene, camera, [state.city.waterMesh, rain.lines]);
  else mirror.off();
  post.render(dt);
  if (state.capture) finishCapture();

  if (state.showPerf) {
    state.perf.debugFrames++;
    if (now - state.perf.debugAt >= 500) {
      const fps = Math.round(state.perf.debugFrames * 1000 / Math.max(1, now - state.perf.debugAt));
      const calls = renderer.info.render.calls || 0;
      const tris = Math.round((renderer.info.render.triangles || 0) / 1000);
      const players = (state.roomPlayers || []).length;
      const netState = net.connected ? `ONLINE · ${players} giocatori` : 'OFFLINE';
      $('perfText').textContent = `${fps} FPS · ${calls} draw calls · ${tris}k triangoli · ${netState} · DPR ${pixelRatio.toFixed(2)}`;
      state.perf.debugAt = now; state.perf.debugFrames = 0;
    }
  }

  // qualità automatica: abbassa la risoluzione se il computer fatica
  if ((settings.quality === 'auto') && state.mode === 'play') {
    const pf = state.perf;
    pf.acc += dt; pf.n++; pf.t += dt;
    if (pf.t > 2.5) {
      const avg = pf.acc / pf.n * 1000;
      const maxPr = Math.min(devicePixelRatio || 1, isMobile ? 1 : 1.5), minPr = isMobile ? 0.5 : 0.7;
      // prima si scende fino a una risoluzione piena, poi si tolgono i riflessi, solo alla fine si sgrana l'immagine
      if (avg > 24) {
        if (pixelRatio > 1.0) { pixelRatio = Math.max(1.0, pixelRatio - 0.15); resize(); }
        else if (!state.autoLite) { state.autoLite = true; }
        else if (pixelRatio > minPr) { pixelRatio = Math.max(minPr, pixelRatio - 0.1); resize(); }
      } else if (avg < 13) {
        if (pixelRatio < 1.0) { pixelRatio = Math.min(1.0, pixelRatio + 0.1); resize(); }
        else if (state.autoLite && avg < 11) state.autoLite = false;
        else if (pixelRatio < maxPr) { pixelRatio = Math.min(maxPr, pixelRatio + 0.1); resize(); }
      }
      pf.acc = 0; pf.n = 0; pf.t = 0;
    }
  }
}

loadCity().catch((err) => {
  console.error(err);
  $('menuWhere').textContent = 'Caricamento non riuscito';
  setLoadingStatus('Errore: ' + (err && err.message ? err.message : 'impossibile caricare i dati'), 'error');
});
requestAnimationFrame(frame);

// per i test automatici
window.__vid = { env, sky, scene, camera, combat, renderer, sun, post, state, settings, subs, net, takePhoto, toggleViewfinder, startPlay, interact, enterDream, exitDream, audio, ui, voice, crowd: () => crowd, traffic: () => traffic, shops: () => shops, story: () => story, wallet: () => wallet, get pixelRatio() { return pixelRatio; } };
