// Gli altri giocatori: il loro avatar, animato, con il nome sopra la testa.
import * as THREE from 'three';
import { Avatar } from '../player/avatar.js';
import { Vehicle } from '../systems/driving.js';

function label(text, color) {
  const c = document.createElement('canvas'); c.width = 256; c.height = 64;
  const g = c.getContext('2d');
  g.font = '600 30px "Karla", system-ui, sans-serif';
  const w = Math.min(240, g.measureText(text).width + 28);
  g.fillStyle = 'rgba(12,14,20,0.72)';
  g.beginPath(); g.roundRect((256 - w) / 2, 10, w, 44, 22); g.fill();
  g.fillStyle = color; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text, 128, 33);
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), depthTest: false, transparent: true }));
  s.scale.set(1.8, 0.45, 1);
  s.renderOrder = 10;
  return s;
}

export class Avatars {
  constructor(scene) { this.scene = scene; this.list = new Map(); }

  ensure(id, name, color, look) {
    let a = this.list.get(id);
    if (a) {
      if (name && a.name !== name) { a.group.remove(a.label); a.label = label(name, a.color); a.label.position.y = 2.15; a.group.add(a.label); a.name = name; }
      if (look && JSON.stringify(look) !== JSON.stringify(a.avatar.app)) a.avatar.build(look);
      return a;
    }
    const group = new THREE.Group();
    const avatar = new Avatar(look);
    const lab = label(name || 'Viandante', color || '#f2b8c6'); lab.position.y = 2.15;
    group.add(avatar.root, lab);
    this.scene.add(group);
    a = { group, avatar, label: lab, name, color: color || '#f2b8c6', buf: [], last: null };
    this.list.set(id, a);
    return a;
  }

  push(id, s, at) {
    const a = this.list.get(id);
    if (!a) return;
    a.buf.push({ at, p: s.p, r: s.r, f: s.f });
    if (a.buf.length > 20) a.buf.shift();
  }

  remove(id) { const a = this.list.get(id); if (a) { this.scene.remove(a.group); if (a.veh) this.scene.remove(a.veh.group); this.list.delete(id); } }
  clear() { for (const id of [...this.list.keys()]) this.remove(id); }

  // interpolazione con 150 ms di ritardo per un movimento fluido
  update(now, dt, camPos) {
    const t = now - 150;
    for (const a of this.list.values()) {
      const b = a.buf;
      if (!b.length) { a.group.visible = false; continue; }
      a.group.visible = true;
      let i = b.length - 1;
      while (i > 0 && b[i - 1].at > t) i--;
      const p1 = b[Math.max(0, i - 1)], p2 = b[i];
      const span = p2.at - p1.at;
      const k = span > 0 ? Math.min(1, Math.max(0, (t - p1.at) / span)) : 1;
      const x = p1.p[0] + (p2.p[0] - p1.p[0]) * k, y = p1.p[1] + (p2.p[1] - p1.p[1]) * k, z = p1.p[2] + (p2.p[2] - p1.p[2]) * k;
      const speed = span > 0 ? Math.hypot(p2.p[0] - p1.p[0], p2.p[2] - p1.p[2]) / (span / 1000) : 0;
      a.group.position.set(x, y, z);
      let dy = p2.r[0] - p1.r[0];
      if (dy > Math.PI) dy -= 2 * Math.PI; if (dy < -Math.PI) dy += 2 * Math.PI;
      a.avatar.root.rotation.y = p1.r[0] + dy * k;
      const drunk = ((p2.f >> 1) & 7) / 7, air = !!(p2.f & 16);
      // alla guida: si vede il mezzo; in auto il guidatore sparisce, in scooter resta in sella
      const vk = (p2.f >> 7) & 3;
      if (vk !== (a.vehKind || 0)) {
        if (a.veh) { this.scene.remove(a.veh.group); a.veh = null; }
        a.vehKind = vk;
        if (vk) { a.veh = new Vehicle(vk === 2 ? 'scooter' : 'auto', a.color || '#8fa3b8', x, z, 0); a.veh.driven = true; this.scene.add(a.veh.group); }
      }
      if (a.veh) {
        a.veh.x = x; a.veh.z = z; a.veh.y = y; a.veh.yaw = a.avatar.root.rotation.y; a.veh.speed = Math.min(25, speed);
        a.veh.pose(dt, 0, false, now / 1000);
        if (vk === 1) { a.avatar.root.visible = false; a.label.position.y = 2.0; continue; }
        const ry = a.avatar.root.rotation.y; a.avatar.root.visible = true;
        a.avatar.root.position.set(-Math.sin(ry) * 0.22, -0.12, -Math.cos(ry) * 0.22);
        a.avatar.animate(dt, 0, false, 0); a.avatar.sit(0);
        continue;
      }
      a.avatar.root.visible = true; a.avatar.root.position.set(0, 0, 0); a.label.position.y = 2.15;
      if ((p2.f & 64) && !(a.avatar.gest && a.avatar.gest.kind === 'punch')) a.avatar.gesture('punch', 0.42);
      a.avatar.animate(dt, Math.min(9, speed), air, drunk);
      if (camPos && Math.hypot(x - camPos.x, z - camPos.z) < 0.6) a.group.visible = false;
    }
  }
}
