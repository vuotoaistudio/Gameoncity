// Connessione alla stanza senza server: usa le stanze di Claude (presenza condivisa fra chi ha la pagina aperta).
// Espone gli stessi eventi del vecchio server (joined, peer, snap, anchor, chat, voice, rtc, status),
// così il resto del gioco non cambia. La sala d'attesa (lobby) mostra le stanze aperte.

const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const COLORS = ['#f2b8c6', '#8fd3c7', '#f2b36b', '#b9a7f2', '#9fd38f', '#f28f8f', '#8fb8f2', '#e6d38f'];
const MAX_ANCHORS = 260;

function colorFor(id) { let h = 0; for (const c of String(id)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return COLORS[h % COLORS.length]; }
// via i caratteri di controllo e invisibili (le stanze li rifiutano)
const badChar = (c) => c < 32 || (c > 126 && c < 160) || (c >= 0x200b && c <= 0x200f) || (c >= 0x2028 && c <= 0x202e) || (c >= 0x2060 && c <= 0x206f) || c === 0xfeff;
const clean = (s, n) => [...String(s || '')].filter((ch) => !badChar(ch.codePointAt(0))).join('').slice(0, n);

let roomApi;
function getRoom() {
  if (roomApi === undefined) {
    roomApi = (async () => {
      try { return window.claude && window.claude.use ? await window.claude.use('room') : null; } catch { return null; }
    })();
  }
  return roomApi;
}

export class NetClient {
  constructor() {
    this.room = null; this.socket = null; this.backend = null; this.code = null; this.you = null; this.host = null;
    this.handlers = {}; this.lastState = 0; this.name = ''; this.look = null;
    this.mine = new Set(); this.known = new Map(); this.unsub = []; this.lobbyRooms = new Map();
    this.voiceOK = true; this.city = 'fi'; this._joinMode = 'join'; this._intentionalClose = false; this._lobbyTimer = null;
  }
  on(t, fn) { (this.handlers[t] ||= []).push(fn); }
  emit(t, m) { for (const f of this.handlers[t] || []) f(m); }
  get connected() { return !!this.code && ((this.backend === 'claude' && !!this.room) || (this.backend === 'ws' && this.socket && this.socket.readyState === WebSocket.OPEN)); }

  // Rileva sia l'ambiente Claude sia il server multiplayer autonomo incluso nel progetto.
  static async probe() {
    if (await getRoom()) return true;
    try { const r = await fetch(new URL('./api/health', location.href), { cache: 'no-store' }); return r.ok && (await r.json()).multiplayer === true; } catch { return false; }
  }

  // sala d'attesa: chi è in una stanza la annuncia qui, così gli altri la vedono nel menu
  async watchLobby(onChange) {
    const lobby = await getRoom();
    if (!lobby) {
      if (this._lobbyTimer) clearInterval(this._lobbyTimer);
      const poll = async () => {
        try { const u = new URL('./api/rooms', location.href); u.searchParams.set('city', this.city); const r = await fetch(u, { cache: 'no-store' }); if (!r.ok) return; const data = await r.json(); this.lobbyRooms = new Map((data.rooms || []).map((x) => [x.code, x])); onChange && onChange(data.rooms || []); } catch {}
      };
      poll(); this._lobbyTimer = setInterval(poll, 5000); return;
    }
    this.lobby = lobby;
    lobby.onPeers((ch) => {
      const rooms = new Map();
      for (const p of ch.peers) {
        const o = p.presence && p.presence.open;
        if (p.sameTab || !o || typeof o.code !== 'string' || !/^[A-Z2-9]{5}$/.test(o.code)) continue;
        const city = typeof o.c === 'string' ? o.c.slice(0, 20) : '';
        const r = rooms.get(o.code) || { code: o.code, city, names: [], at: 0 };
        r.names.push(clean(o.n, 20) || 'Viandante');
        rooms.set(o.code, r);
      }
      this.lobbyRooms = rooms;
      onChange && onChange([...rooms.values()]);
    }, () => {});
  }

  _announce() {
    if (!this.lobby) return;
    this.lobby.presence({ open: this.code ? { code: this.code, c: this.city, n: clean(this.name, 20) } : null }).catch(() => {});
  }

  async _enter(code) {
    const api = await getRoom();
    if (!api) return this._enterStandalone(code, this._joinMode);
    if (this.room || this.socket) await this.leave(true);
    let room;
    try { room = await api.join(('vid-' + String(this.city).replace(/[^a-z0-9]/g, '') + '-' + code).toLowerCase().slice(0, 48)); }
    catch (e) { throw new Error(e && e.code === 'limit_reached' ? 'Troppe stanze aperte: riprova fra poco.' : 'Non riesco a entrare nella stanza (' + ((e && e.code) || 'errore') + ').'); }
    this.room = room; this.backend = 'claude'; this.code = code; this.known.clear();
    await room.presence({ v: 1, n: clean(this.name, 20), l: this.look || null, fx: [...this.mine].slice(-MAX_ANCHORS), at: Date.now() }).catch(() => {});
    // aspetta la prima fotografia della stanza (gli altri rispondono entro un attimo)
    const first = await new Promise((resolve) => {
      let done = false, timer = null;
      const off = room.onPeers((ch) => {
        if (!this.you) { const me = ch.peers.find((p) => p.sameTab); if (me) this.you = me.peer; }
        if (done) { this._apply(ch); return; }
        clearTimeout(timer);
        timer = setTimeout(() => { done = true; resolve(ch.peers); }, 900);
      }, () => resolve([]));
      this.unsub.push(off);
      setTimeout(() => { if (!done) { done = true; resolve(room.peers()); } }, 3500);
    });
    if (!this.you) { const me = first.find((p) => p.sameTab); this.you = me ? me.peer : 'me-' + Math.random().toString(36).slice(2, 8); }
    this.unsub.push(room.on('rtc', (m) => {
      if (m.sameTab || !m.data || m.data.to !== this.you) return;
      this.emit('rtc', { from: m.peer, data: m.data.d });
    }, () => {}));
    this.unsub.push(room.onConnection((ok) => {
      if (!ok) { this._lostT = setTimeout(() => this.emit('status', { state: 'reconnecting' }), 2500); }
      else if (this._lostT) { clearTimeout(this._lostT); this._lostT = null; }
    }, () => this.emit('status', { state: 'lost' })));
    const players = [], anchors = new Set();
    for (const p of first) {
      const info = this._info(p);
      if (!p.sameTab && !info.n) continue;
      players.push({ id: p.peer, name: p.sameTab ? clean(this.name, 20) : info.n, color: colorFor(p.peer), look: p.sameTab ? this.look : info.l });
      if (!p.sameTab) { this.known.set(p.peer, info); for (const b of info.fx) anchors.add(b); }
    }
    if (!players.some((p) => p.id === this.you)) players.push({ id: this.you, name: clean(this.name, 20), color: colorFor(this.you), look: this.look });
    this._host(first);
    this._announce();
    return { code, you: this.you, host: this.host, players, anchors: [...anchors] };
  }

  async _enterStandalone(code, mode) {
    if (this.room || this.socket) await this.leave(true);
    const url = new URL('./ws', location.href);
    url.protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
    this._intentionalClose = false;
    return new Promise((resolve, reject) => {
      let settled = false;
      const sock = new WebSocket(url);
      this.socket = sock;
      const timeout = setTimeout(() => {
        if (!settled) { settled = true; this._joinResolve = null; try { sock.close(); } catch {} reject(new Error('Il server multiplayer non risponde. Riprova fra poco.')); }
      }, 7000);
      this._joinResolve = (m) => {
        if (settled) return;
        settled = true; clearTimeout(timeout); this._joinResolve = null; this._joinReject = null; resolve(m);
      };
      this._joinReject = (e) => {
        if (settled) return;
        settled = true; clearTimeout(timeout); this._joinResolve = null; this._joinReject = null; reject(e);
      };
      sock.addEventListener('open', () => {
        sock.send(JSON.stringify({ t: 'hello', mode, code, city: this.city, name: this.name, look: this.look, anchors: [...this.mine].slice(-MAX_ANCHORS) }));
      });
      sock.addEventListener('message', (event) => {
        let m;
        try { m = JSON.parse(event.data); } catch { return; }
        if (m.t === 'joined') {
          this.backend = 'ws'; this.code = m.code; this.you = m.you; this.host = m.host; this.known.clear();
          this._joinResolve && this._joinResolve({ code: m.code, you: m.you, host: m.host, players: m.players || [], anchors: m.anchors || [] });
          return;
        }
        if (m.t === 'error' && !settled) { this._joinReject && this._joinReject(new Error(m.message || 'Impossibile entrare nella stanza.')); try { sock.close(); } catch {} return; }
        this._handleStandaloneMessage(m);
      });
      sock.addEventListener('error', () => {
        if (!settled) this._joinReject && this._joinReject(new Error('Connessione al server multiplayer non riuscita.'));
      });
      sock.addEventListener('close', () => {
        if (!settled) this._joinReject && this._joinReject(new Error('Connessione chiusa prima di entrare nella stanza.'));
        if (this.socket === sock) {
          const wasConnected = !!this.code && !this._intentionalClose;
          this.socket = null; this.backend = null; this.code = null;
          if (wasConnected) this.emit('status', { state: 'lost' });
        }
      });
    });
  }

  _handleStandaloneMessage(m) {
    if (!m || typeof m.t !== 'string') return;
    if (m.t === 'peer') {
      if (m.host) this.host = m.host;
      if (m.ev === 'join') this.known.set(m.id, { n: m.name, l: m.look });
      if (m.ev === 'leave') this.known.delete(m.id);
      this.emit('peer', m);
    } else if (m.t === 'snap') this.emit('snap', m);
    else if (m.t === 'anchor') this.emit('anchor', m);
    else if (m.t === 'unanchor') this.emit('unanchor', m);
    else if (m.t === 'chat') this.emit('chat', m);
    else if (m.t === 'rtc') this.emit('rtc', m);
    else if (m.t === 'voice') this.emit('voice', m);
    else if (m.t === 'status') this.emit('status', m);
    else if (m.t === 'error') this.emit('status', { state: 'error', message: m.message });
  }

  _info(p) {
    const s = p.presence || {};
    return {
      n: clean(s.n, 20), l: s.l && typeof s.l === 'object' ? s.l : null,
      p: Array.isArray(s.p) && s.p.length === 3 && s.p.every(Number.isFinite) ? s.p : null,
      r: Array.isArray(s.r) && s.r.length === 2 && s.r.every(Number.isFinite) ? s.r : [0, 0],
      f: Number.isInteger(s.f) ? s.f : 0,
      fx: Array.isArray(s.fx) ? s.fx.filter((b) => Number.isInteger(b) && b >= 0 && b < 1e6).slice(0, MAX_ANCHORS) : [],
      say: s.say && typeof s.say.m === 'string' && Number.isFinite(s.say.t) ? { t: s.say.t, m: clean(s.say.m, 140) } : null,
      tk: !!s.tk
    };
  }

  // traduce i cambiamenti della stanza negli eventi che il gioco già conosce
  _apply(ch) {
    for (const p of ch.left) {
      if (p.sameTab || !this.known.has(p.peer)) continue;
      this.known.delete(p.peer);
      this.emit('peer', { ev: 'leave', id: p.peer, host: this._host(ch.peers) });
    }
    const ps = [];
    for (const p of [...ch.joined, ...ch.updated]) {
      if (p.sameTab) continue;
      const info = this._info(p), old = this.known.get(p.peer);
      if (!info.n) continue;
      if (!old) {
        this.known.set(p.peer, info);
        this.emit('peer', { ev: 'join', id: p.peer, name: info.n, color: colorFor(p.peer), look: info.l, host: this._host(ch.peers) });
        if (info.fx.length) this.emit('anchor', { bids: info.fx, by: p.peer });
      } else {
        this.known.set(p.peer, info);
        if (old.n !== info.n) this.emit('peer', { ev: 'rename', id: p.peer, name: info.n });
        if (JSON.stringify(old.l) !== JSON.stringify(info.l)) this.emit('peer', { ev: 'look', id: p.peer, look: info.l });
        const had = new Set(old.fx), added = info.fx.filter((b) => !had.has(b));
        if (added.length) this.emit('anchor', { bids: added, by: p.peer });
        if (info.say && (!old.say || old.say.t !== info.say.t)) this.emit('chat', { id: p.peer, name: info.n, text: info.say.m });
        if (old.tk !== info.tk) this.emit('voice', { id: p.peer, on: info.tk });
      }
      if (info.p) ps.push({ id: p.peer, p: info.p, r: info.r, f: info.f });
    }
    if (ps.length) this.emit('snap', { ps });
  }

  // ospita chi è nella stanza da più tempo (l'ora d'ingresso viaggia nella presenza)
  _host(peers) {
    const list = peers.filter((p) => p.sameTab || this.known.has(p.peer)).map((p) => ({ id: p.peer, at: Number.isFinite(p.presence && p.presence.at) ? p.presence.at : Infinity }));
    list.sort((a, b) => a.at - b.at || (a.id < b.id ? -1 : 1));
    this.host = list.length ? list[0].id : this.you;
    return this.host;
  }

  newCode() { let c = ''; for (let i = 0; i < 5; i++) c += ALPHA[Math.floor(Math.random() * ALPHA.length)]; return c; }
  create(name, city, look) { this.name = name; this.look = look; this._joinMode = 'create'; return this._enter(this.newCode()); }
  join(code, name, look) {
    code = String(code).toUpperCase();
    if (!/^[A-Z0-9]{5}$/.test(code)) return Promise.reject(new Error('Il codice ha 5 lettere o numeri.'));
    this.name = name; this.look = look; this._joinMode = 'join';
    return this._enter(code);
  }
  async leave(keepLobby) {
    for (const off of this.unsub.splice(0)) { try { off(); } catch {} }
    const r = this.room, sock = this.socket;
    this.room = null; this.socket = null; this.backend = null; this.code = null; this.you = null; this.host = null; this.known.clear();
    if (sock) { this._intentionalClose = true; try { if (sock.readyState === WebSocket.OPEN) sock.send(JSON.stringify({ t: 'leave' })); sock.close(); } catch {} this._intentionalClose = false; }
    if (r) await r.leave().catch(() => {});
    if (!keepLobby) this._announce();
  }

  // stessi messaggi del vecchio server, tradotti in presenza o in eventi
  send(m) {
    if (this.backend === 'ws' && this.socket && this.socket.readyState === WebSocket.OPEN) {
      if (m.t === 'anchor') for (const b of m.bids || []) { this.mine.delete(b); this.mine.add(b); }
      if (m.t === 'unanchor') for (const b of m.bids || []) this.mine.delete(b);
      try { this.socket.send(JSON.stringify(m)); } catch {}
      return;
    }
    if (!this.room) { if (m.t === 'anchor') for (const b of m.bids) this.mine.add(b); return; }
    const pr = (patch) => this.room.presence(patch).catch(() => {});
    if (m.t === 'anchor') { for (const b of m.bids) { this.mine.delete(b); this.mine.add(b); } pr({ fx: [...this.mine].slice(-MAX_ANCHORS) }); }
    else if (m.t === 'unanchor') { for (const b of m.bids) this.mine.delete(b); pr({ fx: [...this.mine].slice(-MAX_ANCHORS) }); }
    else if (m.t === 'look') { this.look = m.look; pr({ l: m.look }); }
    else if (m.t === 'rename') { this.name = m.name; pr({ n: clean(m.name, 20) }); this._announce(); }
    else if (m.t === 'chat') pr({ say: { t: Date.now(), m: clean(m.text, 140) } });
    else if (m.t === 'voice') pr({ tk: !!m.on });
    else if (m.t === 'rtc') {
      this.room.emit('rtc', { to: m.to, d: m.data }).catch((e) => {
        if (e && e.code === 'not_permitted' && this.voiceOK) { this.voiceOK = false; this.emit('novoice', {}); }
      });
    }
  }
  sendState(now, pos, yaw, pitch, flags, teleport) {
    if (!this.connected || (now - this.lastState < 66 && !teleport)) return;
    this.lastState = now;
    const p = [+pos.x.toFixed(2), +pos.y.toFixed(2), +pos.z.toFixed(2)], r = [+yaw.toFixed(3), +pitch.toFixed(3)];
    if (this.backend === 'ws') { try { this.socket.send(JSON.stringify({ t: 'state', p, r, f: flags | 0, teleport: !!teleport })); } catch {} return; }
    this.room.presence({ p, r, f: flags | 0 }).catch(() => {});
  }
}
