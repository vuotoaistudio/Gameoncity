// Chat vocale di prossimità: WebRTC fra i giocatori della stanza, audio spaziale.
// Il server inoltra solo i messaggi di collegamento; l'audio va diretto da giocatore a giocatore.

const ICE = [{ urls: 'stun:stun.l.google.com:19302' }];

export class Voice {
  constructor(net, audio) {
    this.net = net; this.audio = audio;
    this.peers = new Map();
    this.track = null; this.stream = null;
    this.mode = 'off';          // off | ptt (tieni premuto) | open (sempre acceso)
    this.pressed = false;
    this.talking = false; this.lastTalkSent = 0;
    this.remoteTalking = new Map();
    this.onState = null;
    net.on('rtc', (m) => this._signal(m.from, m.data));
    net.on('voice', (m) => { this.remoteTalking.set(m.id, !!m.on); });
    net.on('peer', (m) => {
      if (m.ev === 'join') this._maybeOffer(m.id);
      if (m.ev === 'leave') this._drop(m.id);
    });
  }

  get supported() { return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.RTCPeerConnection); }

  // collega tutti i presenti (anche senza microfono: per sentire gli altri)
  joinRoom(players) { for (const p of players) if (p.id !== this.net.you) this._maybeOffer(p.id); }

  async setMode(mode) {
    this.mode = mode;
    if (mode === 'off') { if (this.track) this.track.enabled = false; this._notify(); return true; }
    if (!this.track) {
      if (!this.supported) throw new Error('Questo browser non permette il microfono.');
      if (!window.isSecureContext) throw new Error('Il microfono funziona solo su https o su localhost. Per giocare in rete usa un indirizzo https.');
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
      this.track = this.stream.getAudioTracks()[0];
      for (const p of this.peers.values()) p.tr.sender.replaceTrack(this.track);
      // misuratore per sapere quando si sta parlando
      const ctx = this.audio.ctx;
      if (ctx) {
        const src = ctx.createMediaStreamSource(this.stream);
        this.analyser = ctx.createAnalyser(); this.analyser.fftSize = 512;
        src.connect(this.analyser);
        this.buf = new Uint8Array(this.analyser.fftSize);
      }
    }
    this.track.enabled = mode === 'open' || (mode === 'ptt' && this.pressed);
    this._notify();
    return true;
  }

  press(on) {
    this.pressed = on;
    if (this.track && this.mode === 'ptt') this.track.enabled = on;
    this._notify();
  }

  _notify() { if (this.onState) this.onState(this.mode, this.track ? this.track.enabled : false); }

  _maybeOffer(id) {
    if (!this.net.you || this.peers.has(id)) return;
    const p = this._peer(id);
    // per ogni coppia offre chi ha l'identificativo minore
    if (this.net.you < id) this._offer(id, p);
  }

  _peer(id) {
    if (this.peers.has(id)) return this.peers.get(id);
    const pc = new RTCPeerConnection({ iceServers: ICE });
    const tr = pc.addTransceiver('audio', { direction: 'sendrecv' });
    if (this.track) tr.sender.replaceTrack(this.track);
    const p = { pc, tr, panner: null, gain: null, el: null };
    pc.onicecandidate = (e) => { if (e.candidate) this.net.send({ t: 'rtc', to: id, data: { ice: e.candidate } }); };
    pc.ontrack = (e) => this._attach(p, e.streams[0] || new MediaStream([e.track]));
    pc.onconnectionstatechange = () => { if (pc.connectionState === 'failed') this._drop(id); };
    this.peers.set(id, p);
    return p;
  }

  async _offer(id, p) {
    const offer = await p.pc.createOffer();
    await p.pc.setLocalDescription(offer);
    this.net.send({ t: 'rtc', to: id, data: { sdp: p.pc.localDescription } });
  }

  async _signal(from, data) {
    if (!data) return;
    const p = this._peer(from);
    try {
      if (data.sdp) {
        await p.pc.setRemoteDescription(data.sdp);
        if (data.sdp.type === 'offer') {
          const ans = await p.pc.createAnswer();
          await p.pc.setLocalDescription(ans);
          this.net.send({ t: 'rtc', to: from, data: { sdp: p.pc.localDescription } });
        }
      } else if (data.ice) {
        await p.pc.addIceCandidate(data.ice);
      }
    } catch (e) { console.warn('voce:', e.message); }
  }

  _attach(p, stream) {
    p.stream = stream;               // se il mixer non è ancora acceso, lo colleghiamo appena lo è
    const ctx = this.audio.ctx;
    if (!ctx || p.panner) return;
    // Chrome vuole lo stream collegato a un elemento audio (muto) perché arrivi al mixer
    p.el = new Audio(); p.el.muted = true; p.el.srcObject = stream; p.el.play().catch(() => {});
    const src = ctx.createMediaStreamSource(stream);
    p.panner = ctx.createPanner();
    Object.assign(p.panner, { panningModel: 'HRTF', distanceModel: 'inverse', refDistance: 2, maxDistance: 45, rolloffFactor: 1.3 });
    p.gain = ctx.createGain(); p.gain.gain.value = 1.4;
    src.connect(p.panner); p.panner.connect(p.gain); p.gain.connect(this.audio.lowpass);
  }

  _drop(id) {
    const p = this.peers.get(id); if (!p) return;
    try { p.pc.close(); } catch {}
    if (p.gain) p.gain.disconnect();
    this.peers.delete(id);
  }

  leave() { for (const id of [...this.peers.keys()]) this._drop(id); }

  // posizioni: ascoltatore = telecamera, sorgenti = avatar degli amici
  update(camera, avatars, now) {
    const ctx = this.audio.ctx; if (!ctx) return;
    const L = ctx.listener, p = camera.position;
    const f = { x: -Math.sin(camera.rotation.y), z: -Math.cos(camera.rotation.y) };
    if (L.positionX) {
      L.positionX.value = p.x; L.positionY.value = p.y; L.positionZ.value = p.z;
      L.forwardX.value = f.x; L.forwardY.value = 0; L.forwardZ.value = f.z; L.upX.value = 0; L.upY.value = 1; L.upZ.value = 0;
    } else { L.setPosition(p.x, p.y, p.z); L.setOrientation(f.x, 0, f.z, 0, 1, 0); }
    for (const [id, peer] of this.peers) {
      if (!peer.panner && peer.stream) this._attach(peer, peer.stream);
      const a = avatars.list.get(id);
      if (!peer.panner || !a) continue;
      const g = a.group.position;
      if (peer.panner.positionX) { peer.panner.positionX.value = g.x; peer.panner.positionY.value = g.y + 1.6; peer.panner.positionZ.value = g.z; }
      else peer.panner.setPosition(g.x, g.y + 1.6, g.z);
    }
    // sto parlando? (per l'indicatore sopra il mio nome per gli altri)
    if (this.analyser && this.track && this.track.enabled) {
      this.analyser.getByteTimeDomainData(this.buf);
      let peak = 0; for (const v of this.buf) peak = Math.max(peak, Math.abs(v - 128));
      const talking = peak > 14;
      if (talking !== this.talking && now - this.lastTalkSent > 250) { this.talking = talking; this.lastTalkSent = now; this.net.send({ t: 'voice', on: talking }); }
    } else if (this.talking) { this.talking = false; this.net.send({ t: 'voice', on: false }); }
  }
}
