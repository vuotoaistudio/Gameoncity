// Avatar personalizzabile: corpo umano articolato (human.js) con camminata, corsa, salto e respiro.
import * as THREE from 'three';
import { limbGeo, pelvisGeo, torsoGeo, garmentExtras, coatSkirtGeo, skullGeo, faceParts, hairGeos, hatGeos, handGeo, shoeGeos } from './human.js';

export const OPTIONS = {
  body: [['snella', 'Snella'], ['media', 'Media'], ['robusta', 'Robusta']],
  skin: ['#f1d3bd', '#e3b897', '#c99068', '#a46c47', '#7b4c30', '#4e2f1f'],
  hair: [['corti', 'Corti'], ['lunghi', 'Lunghi'], ['raccolti', 'Raccolti'], ['ricci', 'Ricci'], ['rasati', 'Rasati']],
  hairColor: ['#1c1511', '#3b2618', '#6b4425', '#a8733c', '#d8b679', '#8e8e8e', '#c2405a', '#4a5d8c'],
  top: [['giacca', 'Giacca'], ['felpa', 'Felpa'], ['cappotto', 'Cappotto']],
  topColor: ['#2f3a4a', '#7b2d2d', '#3f5a43', '#c9b48a', '#1f1f22', '#e6e1d6', '#8a5a9c', '#d97a3c'],
  bottomColor: ['#22252b', '#3a4a66', '#5b4636', '#8c8478', '#1a1a1a', '#6b2f3a'],
  hat: [['nessuno', 'Nessuno'], ['berretto', 'Berretto'], ['cuffie', 'Cuffie']]
};

export function defaultAppearance() {
  return { body: 'media', height: 1.0, skin: OPTIONS.skin[1], hair: 'corti', hairColor: OPTIONS.hairColor[1],
    top: 'giacca', topColor: OPTIONS.topColor[0], bottomColor: OPTIONS.bottomColor[0], hat: 'nessuno' };
}

export function sanitizeAppearance(a) {
  const d = defaultAppearance();
  if (!a || typeof a !== 'object') return d;
  const inList = (v, list) => list.some((x) => (Array.isArray(x) ? x[0] : x) === v);
  const out = {};
  out.body = inList(a.body, OPTIONS.body) ? a.body : d.body;
  out.height = Math.min(1.1, Math.max(0.9, Number(a.height) || 1));
  out.skin = inList(a.skin, OPTIONS.skin) ? a.skin : d.skin;
  out.hair = inList(a.hair, OPTIONS.hair) ? a.hair : d.hair;
  out.hairColor = inList(a.hairColor, OPTIONS.hairColor) ? a.hairColor : d.hairColor;
  out.top = inList(a.top, OPTIONS.top) ? a.top : d.top;
  out.topColor = inList(a.topColor, OPTIONS.topColor) ? a.topColor : d.topColor;
  out.bottomColor = inList(a.bottomColor, OPTIONS.bottomColor) ? a.bottomColor : d.bottomColor;
  out.hat = inList(a.hat, OPTIONS.hat) ? a.hat : d.hat;
  return out;
}

// stoffa: il velluto del "sheen" ammorbidisce i bordi come un tessuto vero
function cloth(c, r = 0.88) { const col = new THREE.Color(c); return new THREE.MeshPhysicalMaterial({ color: col, roughness: r, sheen: 1, sheenRoughness: 0.75, sheenColor: col.clone().lerp(new THREE.Color(1, 1, 1), 0.3) }); }
const mat = (c, r = 0.75) => new THREE.MeshStandardMaterial({ color: new THREE.Color(c), roughness: r, metalness: 0 });
function limb(len, r0, r1, m) {
  const g = new THREE.CylinderGeometry(r1, r0, len, 10, 1);
  g.translate(0, -len / 2, 0);
  const mesh = new THREE.Mesh(g, m);
  const cap = new THREE.Mesh(new THREE.SphereGeometry(r0, 10, 8), m);
  const grp = new THREE.Group(); grp.add(mesh, cap);
  return grp;
}

export class Avatar {
  constructor(app) {
    this.root = new THREE.Group();
    this.phase = 0; this.t = 0; this.speedSm = 0;
    this.gest = null; this.prop = null;
    this.build(sanitizeAppearance(app));
  }

  build(app) {
    this.app = app;
    if (this.body) this.root.remove(this.body);
    const body = new THREE.Group();
    this.body = body;
    const w = app.body === 'snella' ? 0.88 : app.body === 'robusta' ? 1.18 : 1;
    const skinC = new THREE.Color(app.skin);
    // pelle: il "sheen" rossastro sui bordi imita la luce che passa sotto la pelle
    const skin = new THREE.MeshPhysicalMaterial({ color: skinC, roughness: 0.5, sheen: 0.55, sheenRoughness: 0.45, sheenColor: new THREE.Color(1, 0.5, 0.4) });
    const top = cloth(app.topColor), bottom = cloth(app.bottomColor, 0.82);
    const hairC = new THREE.Color(app.hairColor);
    const hairM = new THREE.MeshPhysicalMaterial({ color: hairC, roughness: 0.42, sheen: 0.9, sheenRoughness: 0.3, sheenColor: hairC.clone().lerp(new THREE.Color(1, 0.95, 0.85), 0.5) });
    const roles = {
      skin, eye: new THREE.MeshStandardMaterial({ color: 0xf2efe9, roughness: 0.12 }),
      iris: new THREE.MeshStandardMaterial({ color: new THREE.Color().setHSL(0.07 + (app.skin.charCodeAt(2) % 7) * 0.05, 0.45, 0.16), roughness: 0.05 }),
      lips: new THREE.MeshStandardMaterial({ color: skinC.clone().multiply(new THREE.Color(0.86, 0.6, 0.6)), roughness: 0.38 }),
      brow: new THREE.MeshStandardMaterial({ color: hairC, roughness: 0.8 })
    };
    const M = (g, m) => new THREE.Mesh(g, m);

    const hips = new THREE.Group(); hips.position.y = 0.95; body.add(hips);
    this.hips = hips;
    hips.add(M(pelvisGeo(w), bottom));
    if (app.top === 'cappotto') hips.add(M(coatSkirtGeo(w), top));
    const spine = new THREE.Group(); spine.position.y = 0.08; hips.add(spine); this.spine = spine;
    spine.add(M(torsoGeo(w, app.top), top));
    for (const g of garmentExtras(w, app.top)) spine.add(M(g, top));
    // testa
    const head = new THREE.Group(); head.position.y = 0.79; spine.add(head); this.head = head;
    head.add(M(skullGeo(), skin));
    for (const p of faceParts()) head.add(M(p.geo, roles[p.role] || skin));
    for (const g of hairGeos(app.hair)) head.add(M(g, app.hair === 'rasati' ? new THREE.MeshStandardMaterial({ color: skinC.clone().lerp(hairC, 0.55), roughness: 0.85 }) : hairM));
    const hatM = app.hat === 'cuffie' ? new THREE.MeshStandardMaterial({ color: 0xe8e2d6, roughness: 0.35 }) : cloth(app.topColor, 0.95);
    for (const g of hatGeos(app.hat)) head.add(M(g, hatM));
    // braccia: spalla, gomito, polso
    this.arms = [];
    for (const s of [-1, 1]) {
      const sh = new THREE.Group(); sh.position.set(0.205 * w * s, 0.555, 0); spine.add(sh);
      sh.add(M(limbGeo(0.3, 0.056 * Math.sqrt(w), 0.046, 0.16), top));
      const elbow = new THREE.Group(); elbow.position.y = -0.3; sh.add(elbow);
      elbow.add(M(limbGeo(0.265, 0.046, 0.036, 0.12), top));
      const hand = new THREE.Group(); hand.position.y = -0.275; elbow.add(hand);
      for (const g of handGeo()) hand.add(M(g, skin));
      hand.scale.x = s;
      this.arms.push({ sh, elbow, s, hand });
    }
    // gambe: anca, ginocchio, caviglia
    this.legs = [];
    const shoeM = cloth(app.shoe || '#22201e', 0.7), soleM = new THREE.MeshStandardMaterial({ color: 0xe9e5dc, roughness: 0.75 });
    for (const s of [-1, 1]) {
      const hp = new THREE.Group(); hp.position.set(0.095 * w * s, -0.04, 0); hips.add(hp);
      hp.add(M(limbGeo(0.44, 0.086 * Math.sqrt(w), 0.06, 0.1), bottom));
      const knee = new THREE.Group(); knee.position.y = -0.44; hp.add(knee);
      knee.add(M(limbGeo(0.42, 0.06, 0.045, 0.16), bottom));
      const foot = new THREE.Group(); foot.position.y = -0.395; knee.add(foot);
      const sg = shoeGeos();
      for (const g of sg.upper) foot.add(M(g, shoeM));
      for (const g of sg.sole) foot.add(M(g, soleM));
      this.legs.push({ hp, knee, s });
    }
    body.traverse((m) => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
    body.scale.setScalar(app.height);
    this.root.add(body);
  }

  // seduto in sella allo scooter: gambe piegate, mani al manubrio, busto che segue la piega
  sit(lean = 0) {
    this.hips.position.y = 0.95; this.hips.rotation.y = 0;
    this.spine.rotation.set(0.18, 0, lean * 0.6);
    for (const l of this.legs) { l.hp.rotation.set(-1.45, 0, l.s * 0.12); l.knee.rotation.x = 1.55; }
    for (const a of this.arms) { a.sh.rotation.set(-1.05, 0, -a.s * 0.12); a.elbow.rotation.x = -0.55; }
    this.head.rotation.x = -0.12;
  }

  // gesti: pay, take, drink, eat, read, look, smoke, sniff, punch, hurt. Durata in secondi.
  gesture(kind, dur) { this.gest = { kind, t: 0, dur }; }
  hold(obj) {
    this.release();
    this.prop = obj;
    const hand = this.arms[1].hand;
    obj.position.set(0, -0.04, 0.03);
    hand.parent.add(obj);
    obj.position.copy(hand.position).add(new THREE.Vector3(0, -0.03, 0.05));
  }
  release() { if (this.prop && this.prop.parent) this.prop.parent.remove(this.prop); this.prop = null; }

  // speed in m/s, air = in volo, lean = inclinazione laterale (ubriachezza)
  animate(dt, speed, air, lean = 0) {
    this.t += dt;
    this.speedSm += (speed - this.speedSm) * Math.min(1, dt * 8);
    const v = this.speedSm;
    const run = Math.min(1, Math.max(0, (v - 3) / 3));
    const amp = Math.min(1, v / 3.5) * (0.55 + run * 0.35);
    this.phase += dt * (v > 0.15 ? 2.0 + v * 1.25 : 0);
    const p = this.phase;
    const breath = Math.sin(this.t * 1.7) * 0.01;
    this.spine.rotation.x = run * 0.22 + (air ? 0.1 : 0) + breath;
    this.spine.rotation.z = lean * 0.12 * Math.sin(this.t * 0.8);
    this.hips.position.y = 0.95 + Math.abs(Math.sin(p)) * 0.04 * amp - amp * 0.02;
    this.hips.rotation.y = Math.sin(p) * 0.12 * amp;
    this.legs.forEach((l, i) => {
      const ph = p + (i ? Math.PI : 0);
      if (air) { l.hp.rotation.x = -0.6 + i * 0.5; l.knee.rotation.x = 0.9; return; }
      l.hp.rotation.x = Math.sin(ph) * 0.75 * amp;
      l.knee.rotation.x = Math.max(0, Math.sin(ph + 1.3)) * 1.1 * amp + 0.04;
    });
    this.arms.forEach((a, i) => {
      const ph = p + (i ? 0 : Math.PI);
      if (air) { a.sh.rotation.set(-1.4, 0, a.s * 0.4); a.elbow.rotation.x = -0.5; return; }
      a.sh.rotation.set(Math.sin(ph) * 0.65 * amp, 0, a.s * (0.08 + run * 0.05));
      a.elbow.rotation.x = -0.25 - run * 0.9 - amp * 0.2;
    });
    this.head.rotation.x = -this.spine.rotation.x * 0.6;
    // gesto in corso: il braccio destro (e a volte il sinistro) sovrascrive la camminata
    const G = this.gest;
    if (G) {
      G.t += dt;
      const k = Math.min(1, G.t / 0.35, (G.dur - G.t) / 0.35);
      const R = this.arms[1], Lf = this.arms[0];
      const lerp = (o, v) => o + (v - o) * Math.max(0, k);
      if (G.kind === 'punch') {
        // carica breve, braccio teso, ritorno; il sinistro resta in guardia
        const u = G.t / G.dur, ext = u < 0.3 ? u / 0.3 : Math.max(0, 1 - (u - 0.3) / 0.7);
        R.sh.rotation.set(-0.5 - 1.05 * ext, 0, 0.1); R.elbow.rotation.x = -1.7 * (1 - ext);
        Lf.sh.rotation.set(-1.0, 0, -0.25); Lf.elbow.rotation.x = -1.9;
        this.spine.rotation.y = -0.35 * ext; this.spine.rotation.x += 0.12 * ext;
        if (G.t >= G.dur) { this.gest = null; this.spine.rotation.y = 0; }
        return;
      }
      if (G.kind === 'hurt') {
        this.spine.rotation.x -= 0.3 * Math.max(0, k); this.head.rotation.x = -0.35 * Math.max(0, k);
        R.sh.rotation.x = lerp(R.sh.rotation.x, -0.6); Lf.sh.rotation.x = lerp(Lf.sh.rotation.x, -0.6);
        if (G.t >= G.dur) this.gest = null;
        return;
      }
      const pose = {
        pay: [-1.25, -0.25], take: [-1.25, -0.3], give: [-1.2, -0.3],
        drink: [-1.15 + Math.sin(G.t * 1.6) * 0.06, -2.0], eat: [-1.05, -2.1], smoke: [-1.1 + Math.max(0, Math.sin(G.t * 1.3)) * 0.25, -2.0],
        read: [-0.95, -0.9], look: [-0.9, -1.1], sniff: [-1.0, -2.25]
      }[G.kind] || [0, 0];
      R.sh.rotation.x = lerp(R.sh.rotation.x, pose[0]); R.elbow.rotation.x = lerp(R.elbow.rotation.x, pose[1]); R.sh.rotation.z = lerp(R.sh.rotation.z, 0.15);
      if (G.kind === 'read') { Lf.sh.rotation.x = lerp(Lf.sh.rotation.x, -0.95); Lf.elbow.rotation.x = lerp(Lf.elbow.rotation.x, -0.9); Lf.sh.rotation.z = lerp(Lf.sh.rotation.z, -0.15); }
      if (G.kind === 'drink' && G.t > G.dur * 0.4) this.head.rotation.x = lerp(this.head.rotation.x, -0.25);
      if (G.t >= G.dur) this.gest = null;
    }
  }
}
