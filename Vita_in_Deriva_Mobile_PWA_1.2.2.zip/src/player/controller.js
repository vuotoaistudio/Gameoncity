// Giocatore: camminata, corsa, salto, collisioni, visuale in terza o prima persona.
import * as THREE from 'three';
import { pointInRing } from '../world/osm.js';

const CELL = 16;

export class Collision {
  constructor(segs, bridges, waterRings, buildingRings = []) {
    this.segs = [];
    this.off = new Set(); // segmenti spenti (un'auto parcheggiata che è stata portata via)
    this.bridges = bridges;
    this.waterRings = waterRings;
    this.grid = new Map();
    this.add(segs);
    // piante degli edifici per sapere se un punto è DENTRO un palazzo (non solo vicino a un muro)
    this.rings = buildingRings;
    this.ringGrid = new Map();
    buildingRings.forEach((ring, idx) => {
      let x0 = Infinity, x1 = -Infinity, z0 = Infinity, z1 = -Infinity;
      for (const [x, z] of ring) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); z0 = Math.min(z0, z); z1 = Math.max(z1, z); }
      for (let gx = Math.floor(x0 / CELL); gx <= Math.floor(x1 / CELL); gx++) for (let gz = Math.floor(z0 / CELL); gz <= Math.floor(z1 / CELL); gz++) {
        const k = gx + ',' + gz;
        if (!this.ringGrid.has(k)) this.ringGrid.set(k, []);
        this.ringGrid.get(k).push(idx);
      }
    });
  }

  insideBuilding(x, z) {
    const list = this.ringGrid.get(Math.floor(x / CELL) + ',' + Math.floor(z / CELL));
    if (!list) return false;
    for (const i of list) if (pointInRing(x, z, this.rings[i])) return true;
    return false;
  }

  // il punto libero più vicino, cercando a spirale
  nearestFree(x, z, maxR = 40) {
    if (this.isFree(x, z)) return [x, z];
    for (let r = 1; r <= maxR; r += 1) {
      const n = Math.max(8, Math.round(r * 6));
      for (let k = 0; k < n; k++) {
        const a = k / n * Math.PI * 2, px = x + Math.cos(a) * r, pz = z + Math.sin(a) * r;
        if (this.isFree(px, pz)) return [px, pz];
      }
    }
    return null;
  }

  add(segs) {
    for (const s of segs) {
      const idx = this.segs.length;
      this.segs.push(s);
      const [a, b] = s;
      const x0 = Math.floor(Math.min(a[0], b[0]) / CELL), x1 = Math.floor(Math.max(a[0], b[0]) / CELL);
      const z0 = Math.floor(Math.min(a[1], b[1]) / CELL), z1 = Math.floor(Math.max(a[1], b[1]) / CELL);
      for (let x = x0; x <= x1; x++) for (let z = z0; z <= z1; z++) {
        const k = x + ',' + z;
        if (!this.grid.has(k)) this.grid.set(k, []);
        this.grid.get(k).push(idx);
      }
    }
  }

  onBridge(x, z) {
    for (const r of this.bridges) {
      for (let i = 0; i < r.pts.length - 1; i++) {
        if (distToSeg(x, z, r.pts[i], r.pts[i + 1]) < r.width / 2 + 0.2) return true;
      }
    }
    return false;
  }

  inWater(x, z) {
    for (const ring of this.waterRings) if (pointInRing(x, z, ring)) return true;
    return false;
  }

  resolve(x, z, r) {
    const bridge = this.onBridge(x, z);
    for (let iter = 0; iter < 3; iter++) {
      const cx = Math.floor(x / CELL), cz = Math.floor(z / CELL);
      let moved = false;
      for (let gx = cx - 1; gx <= cx + 1; gx++) for (let gz = cz - 1; gz <= cz + 1; gz++) {
        const list = this.grid.get(gx + ',' + gz);
        if (!list) continue;
        for (const idx of list) {
          if (this.off.has(idx)) continue;
          const [a, b, kind] = this.segs[idx];
          if (kind === 'w' && bridge) continue;
          if (kind === 'p' && !bridge) continue;
          const [px, pz] = closest(x, z, a, b);
          const dx = x - px, dz = z - pz, d = Math.hypot(dx, dz);
          if (d < r && d > 1e-6) { x = px + dx / d * r; z = pz + dz / d * r; moved = true; }
        }
      }
      if (!moved) break;
    }
    return [x, z, bridge];
  }

  isFree(x, z) {
    const [rx, rz] = this.resolve(x, z, 0.45);
    return Math.hypot(rx - x, rz - z) < 0.01 && !this.inWater(x, z) && !this.insideBuilding(x, z);
  }

  // primo muro di edificio tra due punti (0..1), per non far passare la telecamera nei muri
  raycast(x0, z0, x1, z1) {
    let best = 1;
    const gx0 = Math.floor(Math.min(x0, x1) / CELL), gx1 = Math.floor(Math.max(x0, x1) / CELL);
    const gz0 = Math.floor(Math.min(z0, z1) / CELL), gz1 = Math.floor(Math.max(z0, z1) / CELL);
    const seen = new Set();
    for (let gx = gx0; gx <= gx1; gx++) for (let gz = gz0; gz <= gz1; gz++) {
      const list = this.grid.get(gx + ',' + gz);
      if (!list) continue;
      for (const idx of list) {
        if (seen.has(idx)) continue; seen.add(idx);
        const [a, b, kind] = this.segs[idx];
        if (kind !== 'b' && kind !== 'd') continue;
        const t = segIntersect(x0, z0, x1, z1, a[0], a[1], b[0], b[1]);
        if (t !== null && t < best) best = t;
      }
    }
    return best;
  }
}

function segIntersect(px, pz, qx, qz, ax, az, bx, bz) {
  const rx = qx - px, rz = qz - pz, sx = bx - ax, sz = bz - az;
  const den = rx * sz - rz * sx;
  if (Math.abs(den) < 1e-9) return null;
  const t = ((ax - px) * sz - (az - pz) * sx) / den, u = ((ax - px) * rz - (az - pz) * rx) / den;
  return t >= 0 && t <= 1 && u >= 0 && u <= 1 ? t : null;
}
function closest(x, z, a, b) {
  const dx = b[0] - a[0], dz = b[1] - a[1], l2 = dx * dx + dz * dz;
  let t = l2 ? ((x - a[0]) * dx + (z - a[1]) * dz) / l2 : 0;
  t = Math.max(0, Math.min(1, t));
  return [a[0] + dx * t, a[1] + dz * t];
}
function distToSeg(x, z, a, b) { const [px, pz] = closest(x, z, a, b); return Math.hypot(x - px, z - pz); }

export class Player {
  constructor(camera, dom, collision) {
    this.camera = camera;
    this.dom = dom;
    this.col = collision;
    this.pos = new THREE.Vector3();
    this.vel = new THREE.Vector2();
    this.vy = 0; this.y = 0; this.grounded = true; this.jumpQueued = false;
    this.facing = 0;                // dove guarda il corpo
    this.yaw = 0; this.pitch = 0.12; // dove guarda la telecamera
    this.lookYaw = 0; this.lookPitch = 0.12;
    this.view = 'third'; this.forceFirst = false;
    this.camDist = 3.6; this.camDistSm = 3.6;
    this.keys = new Set();
    this.locked = false;
    this.enabled = false;
    this.sensitivity = 1;
    this.touch = { move: null, look: null, mx: 0, mz: 0 };
    this.time = 0;
    this.stepPhase = 0;
    this.onStep = null; this.onLand = null;
    this.avatar = null;
    this.surface = 'pietra';
    this._bind();
  }

  _bind() {
    addEventListener('keydown', (e) => { if (!this.enabled) return; this.keys.add(e.code); });
    addEventListener('keyup', (e) => this.keys.delete(e.code));
    addEventListener('blur', () => this.keys.clear());
    document.addEventListener('pointerlockchange', () => { this.locked = document.pointerLockElement === this.dom; });
    document.addEventListener('mousemove', (e) => {
      if (!this.locked || !this.enabled) return;
      // alcuni browser mandano un salto enorme appena il mouse viene catturato: lo ignoriamo
      if (Math.abs(e.movementX) > 250 || Math.abs(e.movementY) > 250) return;
      this.lookYaw -= e.movementX * 0.0022 * this.sensitivity;
      this.lookPitch += e.movementY * 0.0022 * this.sensitivity; // pitch = altezza della telecamera: mouse su = guardi su
      this.lookPitch = Math.max(-1.2, Math.min(1.35, this.lookPitch));
    });
    this.dom.addEventListener('wheel', (e) => {
      if (!this.enabled) return;
      this.camDist = Math.max(1.8, Math.min(8, this.camDist * Math.exp(e.deltaY * 0.0012)));
    }, { passive: true });
    this.dom.addEventListener('touchstart', (e) => {
      if (!this.enabled) return;
      for (const t of e.changedTouches) {
        const left = t.clientX < innerWidth / 2;
        if (left && !this.touch.move) this.touch.move = { id: t.identifier, x: t.clientX, y: t.clientY };
        else if (!left && !this.touch.look) this.touch.look = { id: t.identifier, x: t.clientX, y: t.clientY };
      }
      e.preventDefault();
    }, { passive: false });
    this.dom.addEventListener('touchmove', (e) => {
      for (const t of e.changedTouches) {
        if (this.touch.move && t.identifier === this.touch.move.id) {
          this.touch.mx = Math.max(-1, Math.min(1, (t.clientX - this.touch.move.x) / 50));
          this.touch.mz = Math.max(-1, Math.min(1, (t.clientY - this.touch.move.y) / 50));
        } else if (this.touch.look && t.identifier === this.touch.look.id) {
          this.lookYaw -= (t.clientX - this.touch.look.x) * 0.005 * this.sensitivity;
          this.lookPitch = Math.max(-1.2, Math.min(1.35, this.lookPitch + (t.clientY - this.touch.look.y) * 0.005 * this.sensitivity));
          this.touch.look.x = t.clientX; this.touch.look.y = t.clientY;
        }
      }
      e.preventDefault();
    }, { passive: false });
    const end = (e) => {
      for (const t of e.changedTouches) {
        if (this.touch.move && t.identifier === this.touch.move.id) { this.touch.move = null; this.touch.mx = this.touch.mz = 0; }
        if (this.touch.look && t.identifier === this.touch.look.id) this.touch.look = null;
      }
    };
    this.dom.addEventListener('touchend', end);
    this.dom.addEventListener('touchcancel', end);
  }

  requestLock() {
    if (matchMedia('(pointer: coarse)').matches) return;
    try { const p = this.dom.requestPointerLock(); if (p && p.catch) p.catch(() => {}); } catch (e) { /* non supportato */ }
  }

  jump() { if (this.enabled) this.jumpQueued = true; }
  toggleView() { this.view = this.view === 'third' ? 'first' : 'third'; }
  get firstPerson() { return this.view === 'first' || this.forceFirst; }

  teleport(x, z, yaw, y = 0) {
    this.pos.set(x, y, z); this.y = y; this.vy = 0;
    if (yaw !== undefined) { this.yaw = this.lookYaw = yaw; this.facing = yaw + Math.PI; } // il corpo guarda dove guarda la telecamera
    this.vel.set(0, 0);
  }

  // mods: { speed, lag, sway, noSprint }
  update(dt, mods) {
    this.time += dt;
    const lagK = mods.lag > 0.02 ? Math.min(1, 1 - Math.pow(0.001 + mods.lag * 0.12, dt)) : 1;
    this.yaw += (this.lookYaw - this.yaw) * lagK;
    this.pitch += (this.lookPitch - this.pitch) * lagK;

    let fx = 0, fz = 0;
    if (this.enabled) {
      if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) fz -= 1;
      if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) fz += 1;
      if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) fx -= 1;
      if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) fx += 1;
      fx += this.touch.mx; fz += this.touch.mz;
    }
    const len = Math.hypot(fx, fz);
    if (len > 1) { fx /= len; fz /= len; }
    const run = (this.keys.has('ShiftLeft') || this.keys.has('ShiftRight') || Math.hypot(this.touch.mx, this.touch.mz) > 0.95) && !mods.noSprint;
    const speed = (run ? 7.4 : 4.1) * mods.speed;
    const sin = Math.sin(this.yaw), cos = Math.cos(this.yaw);
    let wx = (fx * cos + fz * sin) * speed, wz = (-fx * sin + fz * cos) * speed;
    const sway = mods.sway * 1.1 * Math.sin(this.time * 0.7) * (len > 0.1 ? 1 : 0.25);
    wx += Math.cos(this.yaw) * sway; wz -= Math.sin(this.yaw) * sway;
    const control = this.grounded ? 1 : 0.35;
    const acc = 1 - Math.pow(0.00002, dt * control);
    this.vel.x += (wx - this.vel.x) * acc;
    this.vel.y += (wz - this.vel.y) * acc;

    // salto e gravità
    if (this.jumpQueued && this.grounded) { this.vy = 5.0; this.grounded = false; }
    this.jumpQueued = false;
    this.vy -= 15 * dt;
    this.y += this.vy * dt;

    const steps = Math.ceil(Math.hypot(this.vel.x, this.vel.y) * dt / 0.25) || 1;
    let onBridge = false;
    for (let s = 0; s < steps; s++) {
      const nx = this.pos.x + this.vel.x * dt / steps, nz = this.pos.z + this.vel.y * dt / steps;
      const [rx, rz, br] = this.col.resolve(nx, nz, 0.38);
      if (!br && this.col.inWater(rx, rz)) { this.vel.set(0, 0); break; }
      this.pos.x = rx; this.pos.z = rz; onBridge = br;
    }
    const groundY = onBridge ? 0.32 : 0;
    if (this.y <= groundY) {
      if (!this.grounded && this.vy < -3 && this.onLand) this.onLand(-this.vy);
      this.y = groundY; this.vy = 0; this.grounded = true;
    }
    this.pos.y = this.y;
    this.surface = onBridge ? 'ferro' : 'pietra';
    // rete di sicurezza: se per qualunque motivo si finisce dentro un palazzo, si esce dal lato più vicino
    this.stuckT = (this.stuckT || 0) - dt;
    if (this.stuckT <= 0) {
      this.stuckT = 0.5;
      if (this.col.insideBuilding(this.pos.x, this.pos.z)) {
        const f = this.col.nearestFree(this.pos.x, this.pos.z);
        if (f) { this.pos.x = f[0]; this.pos.z = f[1]; this.vel.set(0, 0); if (this.onUnstuck) this.onUnstuck(); }
      }
    }

    const v = Math.hypot(this.vel.x, this.vel.y);
    if (v > 0.3) {
      const target = Math.atan2(this.vel.x, this.vel.y);
      let d = target - this.facing;
      while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
      this.facing += d * Math.min(1, dt * 10);
    }
    // passi per l'audio
    if (this.grounded && v > 0.5) {
      const prev = this.stepPhase;
      this.stepPhase += dt * (1.7 + v * 0.42);
      if (Math.floor(prev) !== Math.floor(this.stepPhase) && this.onStep) this.onStep(v, this.surface);
    }
    if (this.avatar) {
      this.avatar.root.position.set(this.pos.x, this.y, this.pos.z);
      this.avatar.root.rotation.y = this.facing;
      this.avatar.animate(dt, this.grounded ? v : 0, !this.grounded, mods.sway);
      this.avatar.root.visible = !this.firstPerson;
    }
    this._camera(dt, mods, v);
    return { speed: v, onBridge, run };
  }

  _camera(dt, mods, v) {
    const roll = mods.sway * 0.06 * Math.sin(this.time * 0.9) + mods.sway * 0.02 * Math.sin(this.time * 2.3);
    const pitch = this.pitch + mods.sway * 0.03 * Math.sin(this.time * 1.3);
    const scale = this.avatar ? this.avatar.app.height : 1;
    if (this.firstPerson) {
      const bob = this.grounded ? Math.sin(this.stepPhase * Math.PI) * 0.03 * Math.min(1, v / 3) : 0;
      this.camera.position.set(this.pos.x, this.y + 1.66 * scale + bob, this.pos.z);
      this.camera.rotation.set(-pitch + 0.0, this.yaw, roll, 'YXZ');
      return;
    }
    // terza persona: braccio dietro le spalle, accorciato se c'è un muro
    const pivot = new THREE.Vector3(this.pos.x, this.y + 1.55 * scale, this.pos.z);
    const right = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    pivot.addScaledVector(right, 0.45);
    const back = new THREE.Vector3(Math.sin(this.yaw) * Math.cos(pitch), Math.sin(pitch), Math.cos(this.yaw) * Math.cos(pitch));
    let dist = this.camDist;
    const end = pivot.clone().addScaledVector(back, dist);
    const t = this.col.raycast(pivot.x, pivot.z, end.x, end.z);
    if (t < 1) dist = Math.max(0.6, dist * t - 0.35);
    this.camDistSm += (dist - this.camDistSm) * Math.min(1, dt * (dist < this.camDistSm ? 20 : 4));
    const cam = pivot.clone().addScaledVector(back, this.camDistSm);
    cam.y = Math.max(cam.y, this.y + 0.35);
    this.camera.position.copy(cam);
    this.camera.lookAt(pivot.x, pivot.y, pivot.z);
    this.camera.rotateZ(roll);
  }
}
