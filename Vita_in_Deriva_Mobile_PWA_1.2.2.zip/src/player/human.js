// Corpo umano procedurale, condiviso da giocatore, amici e passanti.
// Ogni funzione restituisce geometrie già posizionate rispetto al proprio giunto (spalla, anca, centro della testa…).
import * as THREE from 'three';

const ss = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

// profilo [raggio, y] con y crescente; LatheGeometry gira attorno all'asse Y
function lathe(profile, seg = 18) {
  const g = new THREE.LatheGeometry(profile.map(([r, y]) => new THREE.Vector2(Math.max(0.0005, r), y)), seg);
  g.computeVertexNormals();
  return g;
}

function deform(g, fn) {
  const p = g.attributes.position, v = new THREE.Vector3();
  for (let i = 0; i < p.count; i++) { v.fromBufferAttribute(p, i); fn(v); p.setXYZ(i, v.x, v.y, v.z); }
  g.computeVertexNormals();
  return g;
}

// arto dal giunto (y = 0) verso il basso, con calotte arrotondate e un rigonfiamento muscolare
export function limbGeo(len, r0, r1, bulge = 0.12, seg = 12) {
  const P = [];
  const n = 10;
  P.push([0.0005, -len - r1 * 0.55], [r1 * 0.7, -len - r1 * 0.38]);
  for (let i = n; i >= 0; i--) {
    const t = i / n;
    let r = r0 + (r1 - r0) * t;
    r *= 1 + bulge * Math.sin(Math.PI * Math.min(1, t * 1.5));
    P.push([r, -t * len]);
  }
  P.push([r0 * 0.75, r0 * 0.35], [0.0005, r0 * 0.6]);
  return lathe(P, seg);
}

// bacino (pantaloni): centro delle anche a y = 0
export function pelvisGeo(w) {
  const g = lathe([[0.0005, -0.15], [0.11, -0.135], [0.165, -0.08], [0.175, -0.01], [0.168, 0.06], [0.155, 0.12]], 18);
  return deform(g, (v) => { v.x *= w; v.z *= 0.66; if (v.z < 0) v.z *= 1.12; });
}

// busto: da y = -0.06 (cintura) a 0.68 (base del collo); spalle larghe, petto avanti, schiena dritta
export function torsoGeo(w, kind) {
  const loose = kind === 'felpa' ? 1.06 : kind === 'cappotto' ? 1.08 : 1.0;
  const g = lathe([[0.0005, -0.07], [0.152, -0.06], [0.158, 0.06], [0.148, 0.2], [0.158, 0.3], [0.182, 0.42], [0.19, 0.5], [0.178, 0.57], [0.13, 0.625], [0.075, 0.655], [0.058, 0.68]], 20);
  return deform(g, (v) => {
    const y = v.y;
    v.x *= w * loose * (1 + 0.22 * ss(0.38, 0.56, y) - 0.12 * ss(0.58, 0.66, y));
    v.z *= 0.6 * loose;
    if (v.z > 0) v.z *= 1 + 0.12 * ss(0.25, 0.42, y) * (1 - ss(0.5, 0.6, y));
    else v.z *= 1 - 0.06 * ss(0.1, 0.3, y);
  });
}

// colletto, cappuccio, falde del cappotto: pezzi nel colore del capo
export function garmentExtras(w, kind) {
  const out = [];
  if (kind === 'giacca') {
    const c = new THREE.TorusGeometry(0.085, 0.022, 8, 20); c.rotateX(Math.PI / 2); c.scale(1.1 * w, 1, 0.9); c.translate(0, 0.645, 0.005); out.push(c);
    for (const s of [-1, 1]) { const l = new THREE.BoxGeometry(0.06, 0.2, 0.012); l.rotateZ(s * 0.35); l.translate(s * 0.05 * w, 0.52, 0.118 * 1.05); out.push(l); }
  } else if (kind === 'felpa') {
    const h = new THREE.SphereGeometry(0.13, 16, 10, 0, Math.PI * 2, 0, Math.PI * 0.55); h.rotateX(-2.1); h.scale(1.05, 0.8, 0.9); h.translate(0, 0.64, -0.085); out.push(h);
    const pocket = new THREE.BoxGeometry(0.2 * w, 0.1, 0.015); pocket.translate(0, 0.1, 0.105); out.push(pocket);
  } else if (kind === 'cappotto') {
    const c = new THREE.TorusGeometry(0.09, 0.03, 8, 20); c.rotateX(Math.PI / 2); c.scale(1.15 * w, 1, 0.95); c.translate(0, 0.64, 0); out.push(c);
  }
  return out;
}
// falde del cappotto (attaccate alle anche)
export function coatSkirtGeo(w) {
  const g = lathe([[0.215, -0.55], [0.2, -0.3], [0.18, -0.05], [0.17, 0.08]], 20);
  return deform(g, (v) => { v.x *= w; v.z *= 0.74; });
}

// testa centrata in (0,0,0): cranio deformato con mascella, mento, zigomi
export function skullGeo() {
  const g = new THREE.SphereGeometry(0.115, 30, 22);
  return deform(g, (v) => {
    const r = 0.115;
    if (v.y < 0.01) {
      const k = Math.min(1, (0.01 - v.y) / r);
      v.x *= 1 - 0.3 * k * k;
      if (v.z > 0) v.z *= 1 + 0.08 * k; else v.z *= 1 - 0.22 * k;
      v.y -= 0.018 * k * k;
    }
    if (v.z < 0) v.z *= 1.1;
    v.x *= 0.9;
    // orbite appena incavate
    const ex = Math.abs(v.x) - 0.036, ey = v.y - 0.014;
    if (v.z > 0.07) v.z -= 0.006 * Math.exp(-(ex * ex + ey * ey) / 0.0004);
    v.y *= 1.08;
  });
}

// lineamenti: ogni pezzo ha un ruolo (per il colore)
export function faceParts() {
  const P = [];
  const add = (geo, role) => P.push({ geo, role });
  for (const s of [-1, 1]) {
    const eye = new THREE.SphereGeometry(0.0165, 12, 10); eye.scale(1, 0.85, 0.7); eye.translate(0.036 * s, 0.016, 0.091); add(eye, 'eye');
    const iris = new THREE.SphereGeometry(0.0085, 10, 8); iris.scale(1, 1, 0.5); iris.translate(0.036 * s, 0.016, 0.1025); add(iris, 'iris');
    const lid = new THREE.SphereGeometry(0.0185, 12, 6, 0, Math.PI * 2, 0, Math.PI * 0.42); lid.scale(1, 0.75, 0.75); lid.translate(0.036 * s, 0.02, 0.09); add(lid, 'skin');
    const brow = new THREE.BoxGeometry(0.038, 0.007, 0.012); brow.rotateZ(-0.12 * s); brow.translate(0.038 * s, 0.043, 0.098); add(brow, 'brow');
    const ear = new THREE.SphereGeometry(0.03, 10, 8); ear.scale(0.35, 1, 0.7); ear.translate(0.103 * s, 0.004, -0.008); add(ear, 'skin');
  }
  const nose = new THREE.SphereGeometry(0.02, 12, 10); nose.scale(0.75, 1.5, 0.9); nose.rotateX(0.25); nose.translate(0, -0.006, 0.106); add(nose, 'skin');
  const tip = new THREE.SphereGeometry(0.0145, 10, 8); tip.translate(0, -0.026, 0.117); add(tip, 'skin');
  const lips = new THREE.SphereGeometry(0.026, 14, 8); lips.scale(1, 0.32, 0.45); lips.translate(0, -0.053, 0.1); add(lips, 'lips');
  const chin = new THREE.SphereGeometry(0.03, 12, 8); chin.scale(1, 0.7, 0.7); chin.translate(0, -0.088, 0.083); add(chin, 'skin');
  const neck = new THREE.CylinderGeometry(0.048, 0.056, 0.13, 14); neck.translate(0, -0.135, -0.012); add(neck, 'skin');
  return P;
}

// capelli: calotta con ciocche (rumore radiale) e volumi in più a seconda dello stile
export function hairGeos(style) {
  const out = [];
  if (style === 'rasati') {
    const c = new THREE.SphereGeometry(0.119, 24, 14, 0, Math.PI * 2, 0, Math.PI * 0.5); c.rotateX(-0.28); c.scale(0.92, 1.12, 1.07); c.translate(0, 0.012, -0.004); out.push(c); return out;
  }
  const cap = new THREE.SphereGeometry(0.126, 30, 16, 0, Math.PI * 2, 0, Math.PI * 0.56);
  deform(cap, (v) => {
    const a = Math.atan2(v.z, v.x);
    const n = 1 + 0.035 * Math.sin(a * 23 + v.y * 40) * Math.sin(a * 7) + (style === 'ricci' ? 0.08 * Math.sin(a * 13) * Math.sin(v.y * 90) : 0);
    v.x *= n; v.z *= n;
  });
  cap.rotateX(-0.3); cap.scale(0.93, 1.12, 1.08); cap.translate(0, 0.015, -0.006);
  out.push(cap);
  // frangia corta sulla fronte
  const fr = new THREE.SphereGeometry(0.06, 14, 8, 0, Math.PI * 2, 0, Math.PI * 0.5); fr.scale(1.4, 0.45, 0.7); fr.rotateX(0.5); fr.translate(0, 0.075, 0.075); out.push(fr);
  if (style === 'lunghi') {
    const back = lathe([[0.02, -0.26], [0.1, -0.24], [0.125, -0.12], [0.13, 0.0], [0.125, 0.06]], 20);
    deform(back, (v) => { if (v.z > 0.03) v.z = 0.03 + (v.z - 0.03) * 0.2; v.x *= 0.95; });
    back.translate(0, 0, -0.025); out.push(back);
  } else if (style === 'raccolti') {
    const bun = new THREE.SphereGeometry(0.058, 16, 12); bun.scale(1, 0.9, 1); bun.translate(0, 0.07, -0.125); out.push(bun);
  } else if (style === 'ricci') {
    for (let i = 0; i < 18; i++) {
      const a = i * 2.39996, y = 0.02 + (i % 6) * 0.018, r = 0.115;
      const b = new THREE.SphereGeometry(0.034, 8, 6); b.translate(Math.cos(a) * r, y + 0.03, Math.sin(a) * r * 0.95 - 0.015);
      if (Math.sin(a) * r > 0.07 && y < 0.07) continue;
      out.push(b);
    }
  }
  return out;
}

// cappelli
export function hatGeos(kind) {
  const out = [];
  if (kind === 'berretto') {
    const b = new THREE.SphereGeometry(0.132, 22, 12, 0, Math.PI * 2, 0, Math.PI * 0.52); b.scale(0.95, 1.18, 1.06); b.translate(0, 0.022, -0.004); out.push(b);
    const rim = new THREE.TorusGeometry(0.124, 0.02, 8, 26); rim.rotateX(Math.PI / 2); rim.scale(0.95, 1, 1.06); rim.translate(0, 0.03, -0.004); out.push(rim);
  } else if (kind === 'cuffie') {
    const band = new THREE.TorusGeometry(0.128, 0.012, 8, 24, Math.PI); band.scale(0.96, 1.05, 1); band.translate(0, 0.02, 0); out.push(band);
    for (const s of [-1, 1]) { const e = new THREE.CylinderGeometry(0.045, 0.045, 0.04, 18); e.rotateZ(Math.PI / 2); e.translate(0.118 * s, -0.005, 0); out.push(e); }
  }
  return out;
}

// mano: palmo, dita unite, pollice; il polso è a y = 0
export function handGeo() {
  const palm = new THREE.SphereGeometry(0.042, 12, 10); palm.scale(0.95, 1.25, 0.55); palm.translate(0, -0.045, 0);
  const fingers = new THREE.SphereGeometry(0.038, 12, 10); fingers.scale(1, 1.25, 0.5); fingers.translate(0, -0.105, 0.006);
  const thumb = limbGeo(0.05, 0.013, 0.011, 0.05, 8); thumb.rotateZ(0.6); thumb.rotateY(-0.4); thumb.translate(-0.03, -0.03, 0.015);
  return [palm, fingers, thumb];
}

// scarpa da ginnastica: tomaia e suola chiara; la caviglia è a y = 0
export function shoeGeos() {
  const upper = new THREE.SphereGeometry(0.06, 16, 10); upper.scale(0.95, 0.7, 2.15); upper.translate(0, -0.035, 0.05);
  const sole = new THREE.BoxGeometry(0.105, 0.028, 0.27); sole.translate(0, -0.072, 0.05);
  const toe = new THREE.SphereGeometry(0.052, 12, 8); toe.scale(1, 0.55, 0.7); toe.translate(0, -0.06, 0.155);
  return { upper: [upper, toe], sole: [sole] };
}
