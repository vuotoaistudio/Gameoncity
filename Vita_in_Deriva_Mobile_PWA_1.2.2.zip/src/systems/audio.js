// Audio sintetizzato in tempo reale (nessun file): città, acqua, pioggia, vento, uccelli, campane,
// passi, carillon del sogno. Parte solo dopo un gesto del giocatore, come chiedono i browser.

const NOTE = (n) => 440 * Math.pow(2, (n - 69) / 12);
// frase del carillon: La minore pentatonica, lenta, un po' stonata
const MELODY = [76, 79, 81, 79, 76, 74, 76, null, 72, 74, 76, 79, 76, 74, 72, null, 69, 72, 74, 76, 74, 72, 69, null, 67, 69, 72, 74, 72, null, null, null];

export class AudioEngine {
  constructor() { this.ctx = null; this.enabled = true; this.volume = 0.8; this.lastHour = null; this.melodyStep = 0; this.nextNote = 0; this.nextBird = 0; this.nextTraffic = 0; this.nextLap = 0; }

  start() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    let ctx;
    try { ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch { this.enabled = false; return; }
    this.ctx = ctx;
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -16; comp.ratio.value = 4;
    this.lowpass = ctx.createBiquadFilter(); this.lowpass.type = 'lowpass'; this.lowpass.frequency.value = 18000;
    this.master = ctx.createGain(); this.master.gain.value = this.volume;
    this.lowpass.connect(comp); comp.connect(this.master); this.master.connect(ctx.destination);
    // riverbero generato: coda di rumore che decade
    this.reverb = ctx.createConvolver();
    this.reverb.buffer = this._impulse(3.2, 2.4);
    this.reverbGain = ctx.createGain(); this.reverbGain.gain.value = 0.35;
    this.reverb.connect(this.reverbGain); this.reverbGain.connect(this.lowpass);
    this.white = this._noise('white'); this.pink = this._noise('pink'); this.brown = this._noise('brown');

    this.layers = {
      city: this._loop(this.brown, 'lowpass', 320, 0.7),
      traffic: this._loop(this.white, 'bandpass', 650, 0.6),
      water: this._loop(this.pink, 'bandpass', 1100, 0.9),
      rain: this._loop(this.white, 'highpass', 2200, 0.5),
      wind: this._loop(this.pink, 'bandpass', 500, 1.2)
    };
    // bordone del sogno
    this.drone = ctx.createGain(); this.drone.gain.value = 0;
    const dl = ctx.createBiquadFilter(); dl.type = 'lowpass'; dl.frequency.value = 420;
    this.drone.connect(dl); dl.connect(this.lowpass); dl.connect(this.reverb);
    this.droneOsc = [55, 82.41, 110.3].map((f, i) => {
      const o = ctx.createOscillator(); o.type = i === 2 ? 'sawtooth' : 'sine'; o.frequency.value = f;
      const g = ctx.createGain(); g.gain.value = i === 2 ? 0.12 : 0.5;
      o.connect(g); g.connect(this.drone); o.start();
      return o;
    });
    const lfo = ctx.createOscillator(); lfo.frequency.value = 0.07;
    const lg = ctx.createGain(); lg.gain.value = 18;
    lfo.connect(lg); for (const o of this.droneOsc) lg.connect(o.detune); lfo.start();
  }

  _noise(kind) {
    const ctx = this.ctx, len = ctx.sampleRate * 3, buf = ctx.createBuffer(1, len, ctx.sampleRate), d = buf.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, last = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      if (kind === 'white') d[i] = w;
      else if (kind === 'pink') { b0 = 0.997 * b0 + w * 0.029591; b1 = 0.985 * b1 + w * 0.032534; b2 = 0.95 * b2 + w * 0.048056; d[i] = (b0 + b1 + b2 + w * 0.0555) * 1.6; }
      else { last = (last + 0.02 * w) / 1.02; d[i] = last * 3.5; }
    }
    return buf;
  }

  _impulse(seconds, decay) {
    const ctx = this.ctx, len = ctx.sampleRate * seconds, buf = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const d = buf.getChannelData(c);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay);
    }
    return buf;
  }

  _loop(buffer, type, freq, q) {
    const ctx = this.ctx;
    const src = ctx.createBufferSource(); src.buffer = buffer; src.loop = true; src.loopStart = Math.random();
    const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
    const g = ctx.createGain(); g.gain.value = 0;
    src.connect(f); f.connect(g); g.connect(this.lowpass);
    src.start(0, Math.random() * 2);
    return { src, f, g };
  }

  _set(param, v, tc = 0.6) { param.setTargetAtTime(v, this.ctx.currentTime, tc); }

  setVolume(v) { this.volume = v; if (this.master) this._set(this.master.gain, v, 0.1); }

  // battito del cuore (Kokka), sussurri (paranoia), fisarmonica del musicista, vibrazione del telefono
  heart(t, rate, vol) {
    for (const off of [0, 0.16]) {
      const ctx = this.ctx, o = ctx.createOscillator(); o.type = 'sine'; o.frequency.setValueAtTime(70, t + off); o.frequency.exponentialRampToValueAtTime(40, t + off + 0.12);
      const g = ctx.createGain(); g.gain.setValueAtTime(0, t + off); g.gain.linearRampToValueAtTime(vol * (off ? 0.6 : 1), t + off + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + off + 0.18);
      o.connect(g); g.connect(this.master); o.start(t + off); o.stop(t + off + 0.2);
    }
  }
  whisper() {
    if (!this.ctx) return;
    const ctx = this.ctx, t = ctx.currentTime;
    const src = ctx.createBufferSource(); src.buffer = this.pink;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = 8;
    for (let k = 0; k < 8; k++) f.frequency.setValueAtTime(900 + Math.random() * 2200, t + k * 0.12);
    const pan = ctx.createStereoPanner(); pan.pan.value = Math.random() < 0.5 ? -0.9 : 0.9;
    const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.18, t + 0.1); g.gain.setValueAtTime(0.18, t + 0.8); g.gain.linearRampToValueAtTime(0, t + 1.1);
    src.connect(f); f.connect(g); g.connect(pan); pan.connect(this.lowpass); pan.connect(this.reverb);
    src.start(t, Math.random()); src.stop(t + 1.2);
  }
  buzz() {
    if (!this.ctx) return;
    const ctx = this.ctx, t = ctx.currentTime;
    for (const off of [0, 0.25]) {
      const o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = 160;
      const g = ctx.createGain(); g.gain.setValueAtTime(0, t + off); g.gain.linearRampToValueAtTime(0.05, t + off + 0.02); g.gain.setValueAtTime(0.05, t + off + 0.15); g.gain.linearRampToValueAtTime(0, t + off + 0.18);
      o.connect(g); g.connect(this.master); o.start(t + off); o.stop(t + off + 0.2);
    }
  }
  _accordion(f, vol, dur) {
    const ctx = this.ctx, t = ctx.currentTime;
    const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + 0.06); g.gain.setValueAtTime(vol, t + dur * 0.8); g.gain.linearRampToValueAtTime(0, t + dur);
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1800;
    const vib = ctx.createOscillator(); vib.frequency.value = 5.5; const vg = ctx.createGain(); vg.gain.value = 6; vib.connect(vg);
    for (const [m, det] of [[1, -6], [1, 6], [0.5, 0]]) {
      const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f * m; o.detune.value = det; vg.connect(o.detune);
      o.connect(lp); o.start(t); o.stop(t + dur + 0.05);
    }
    vib.start(t); vib.stop(t + dur + 0.05);
    lp.connect(g); g.connect(this.lowpass); g.connect(this.reverb);
  }

  // p: { night, day, rain, wind, nearWater, drift, drunk, inside, localHour, localMinute, heart, busker }
  update(p) {
    if (!this.ctx || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime, out = 1 - p.inside;
    const L = this.layers;
    this._set(L.city.g.gain, (0.05 + 0.07 * p.day) * out);
    this._set(L.water.g.gain, 0.16 * p.nearWater * out, 0.4);
    this._set(L.rain.g.gain, Math.min(0.22, p.rain * 0.12) * out, 1.5);
    this._set(L.wind.g.gain, Math.min(0.12, p.wind * 0.006) * out, 1.5);
    // il traffico va e viene; di notte si dirada
    if (t > this.nextTraffic) {
      this.nextTraffic = t + 2 + Math.random() * 5;
      this._set(L.traffic.g.gain, (Math.random() * 0.05 + 0.01) * (1 - 0.75 * p.night) * out, 1.2);
      this._set(L.traffic.f.frequency, 400 + Math.random() * 600, 2);
    }
    if (t > this.nextLap) { this.nextLap = t + 0.6 + Math.random() * 1.6; this._set(L.water.f.frequency, 700 + Math.random() * 900, 0.3); }
    this._set(L.wind.f.frequency, 350 + 300 * Math.sin(t * 0.13), 1);
    // sogno: bordone e carillon
    this._set(this.drone.gain, Math.min(0.12, p.drift * 0.07 + p.inside * 0.1), 1.5);
    this._set(this.reverbGain.gain, 0.3 + p.inside * 0.5, 1);
    if ((p.inside > 0.5 || p.drift > 0.45) && t > this.nextNote) {
      const beat = p.inside > 0.5 ? 0.42 : 0.6;
      this.nextNote = t + beat;
      const n = MELODY[this.melodyStep++ % MELODY.length];
      if (n !== null) this._musicBox(NOTE(n) * (1 + (Math.random() - 0.5) * 0.012 * (1 + p.drunk * 4)), (p.inside > 0.5 ? 0.09 : 0.05) * Math.max(p.inside, p.drift));
    }
    // uccelli di giorno, senza pioggia
    if (p.day > 0.6 && p.rain < 0.1 && out > 0.5 && t > this.nextBird) {
      this.nextBird = t + 3 + Math.random() * 9;
      const k = 2 + Math.floor(Math.random() * 4);
      for (let i = 0; i < k; i++) this._chirp(t + i * (0.09 + Math.random() * 0.08), 2600 + Math.random() * 2400);
    }
    // campane: battono le ore vere, dalle 7 alle 22
    if (this.lastHour !== null && p.localHour !== this.lastHour && p.localMinute === 0 && p.localHour >= 7 && p.localHour <= 22) {
      const strikes = p.localHour % 12 || 12;
      for (let i = 0; i < strikes; i++) this.bell(t + 0.5 + i * 2.3, 0.22 * out + 0.05);
    }
    this.lastHour = p.localHour;
    if (p.heart > 0.15 && t > (this.nextHeart || 0)) { const rate = 1.1 + p.heart * 0.9; this.nextHeart = t + 1 / rate; this.heart(t + 0.02, rate, 0.12 * p.heart); }
    if (p.busker > 0.02 && t > (this.nextBusk || 0)) {
      const n = MELODY[(this.buskStep = (this.buskStep || 0) + 1) % MELODY.length];
      this.nextBusk = t + 0.55;
      if (n !== null) this._accordion(NOTE(n - 12), 0.06 * p.busker, 0.5);
    }
    // Ambra: tutto ovattato
    this._set(this.lowpass.frequency, 18000 - Math.pow(p.drunk, 0.7) * 16500, 0.8);
  }

  _musicBox(f, vol) {
    const ctx = this.ctx, t = ctx.currentTime;
    const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + 2.2);
    for (const [mult, a] of [[1, 1], [2.01, 0.35], [4.03, 0.12]]) {
      const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = f * mult;
      const og = ctx.createGain(); og.gain.value = a;
      o.connect(og); og.connect(g); o.start(t); o.stop(t + 2.3);
    }
    g.connect(this.lowpass); g.connect(this.reverb);
  }

  _chirp(t, f) {
    const ctx = this.ctx;
    const o = ctx.createOscillator(); o.type = 'sine';
    o.frequency.setValueAtTime(f, t); o.frequency.exponentialRampToValueAtTime(f * 1.5, t + 0.05); o.frequency.exponentialRampToValueAtTime(f * 0.9, t + 0.09);
    const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.025, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.1);
    o.connect(g); g.connect(this.lowpass); g.connect(this.reverb); o.start(t); o.stop(t + 0.12);
  }

  // clacson di un'utilitaria: due note quadre, filtrate, con un po' di città intorno
  honk(pan = 0, vol = 0.12) {
    if (!this.ctx) return;
    const ctx = this.ctx, t = ctx.currentTime, dur = 0.28 + Math.random() * 0.25;
    const p = ctx.createStereoPanner ? ctx.createStereoPanner() : null; if (p) p.pan.value = pan;
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 2200;
    const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + 0.02); g.gain.setValueAtTime(vol, t + dur); g.gain.exponentialRampToValueAtTime(0.0001, t + dur + 0.08);
    for (const fr of [415, 520]) { const o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = fr; o.connect(f); o.start(t); o.stop(t + dur + 0.1); }
    f.connect(g); if (p) { g.connect(p); p.connect(this.lowpass); } else g.connect(this.lowpass);
    const rg = ctx.createGain(); rg.gain.value = 0.25; g.connect(rg); rg.connect(this.reverb);
  }

  // campanella del tram: din din
  tramBell(pan = 0, vol = 0.1) {
    if (!this.ctx) return;
    const ctx = this.ctx;
    for (const dt of [0, 0.22]) {
      const t = ctx.currentTime + dt;
      for (const [r, a] of [[1, 1], [2.76, 0.4], [5.4, 0.2]]) {
        const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = 1320 * r;
        const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol * a, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.6);
        const p = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
        if (p) { p.pan.value = pan; o.connect(g); g.connect(p); p.connect(this.lowpass); } else { o.connect(g); g.connect(this.lowpass); }
        g.connect(this.reverb); o.start(t); o.stop(t + 0.7);
      }
    }
  }

  // tuono: rombo grave che rotola, più forte se il lampo è vicino
  thunder(near = 0.5) {
    if (!this.ctx) return;
    const v = 0.12 + Math.max(0, near) * 0.3;
    this._burst(70, 0.4, 3.5, v, 'lowpass', 0.8);
    setTimeout(() => this._burst(120, 0.5, 2.2, v * 0.7, 'lowpass', 0.6), 180 + Math.random() * 300);
    if (near > 0.6) this._burst(900, 0.4, 0.4, v * 0.6, 'lowpass', 0.3);
  }

  // motore del mezzo che guidi: due oscillatori filtrati, i giri seguono la velocità
  engineStart(kind) {
    if (!this.ctx) return;
    this.engineStop();
    const ctx = this.ctx, scooter = kind === 'scooter';
    const g = ctx.createGain(); g.gain.value = 0;
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = scooter ? 1600 : 700; f.Q.value = 2;
    const o1 = ctx.createOscillator(); o1.type = scooter ? 'square' : 'sawtooth';
    const o2 = ctx.createOscillator(); o2.type = 'sawtooth';
    const n = ctx.createBufferSource(); n.buffer = this.brown; n.loop = true;
    const ng = ctx.createGain(); ng.gain.value = 0.35;
    o1.connect(f); o2.connect(f); n.connect(ng); ng.connect(f); f.connect(g); g.connect(this.lowpass);
    o1.start(); o2.start(); n.start();
    this.eng = { g, f, o1, o2, n, scooter };
    this._set(g.gain, 0.05, 0.3);
  }
  engine(frac, thr, kind) {
    const e = this.eng; if (!e) return;
    const base = e.scooter ? 70 : 38, span = e.scooter ? 190 : 110;
    // marce: i giri salgono e ricadono
    const gear = e.scooter ? frac : (frac * 4) % 1 * 0.7 + frac * 0.3;
    this._set(e.o1.frequency, base + span * gear + thr * 12, 0.08);
    this._set(e.o2.frequency, (base + span * gear) * 1.5 + 3, 0.08);
    this._set(e.f.frequency, (e.scooter ? 1200 : 450) + gear * 1400 + thr * 500, 0.1);
    this._set(e.g.gain, 0.035 + thr * 0.045 + frac * 0.02, 0.15);
  }
  engineStop() {
    const e = this.eng; if (!e) return;
    this.eng = null;
    this._set(e.g.gain, 0, 0.15);
    setTimeout(() => { try { e.o1.stop(); e.o2.stop(); e.n.stop(); e.g.disconnect(); } catch { /* già fermo */ } }, 800);
  }
  // urto: colpo sordo, lamiera, a volte vetri
  crash(k = 0.5) {
    if (!this.ctx) return;
    this._burst(90, 0.6, 0.5, 0.25 * k + 0.08, 'lowpass', 0.3);
    this._burst(1800, 2, 0.25, 0.08 * k, 'bandpass', 0.2);
    if (k > 0.6) setTimeout(() => this.glass(), 60);
  }
  // allarme dell'auto: due toni che si alternano per qualche secondo
  carAlarm(pan = 0) {
    if (!this.ctx) return;
    const ctx = this.ctx, t = ctx.currentTime;
    const o = ctx.createOscillator(); o.type = 'square';
    for (let i = 0; i < 24; i++) o.frequency.setValueAtTime(i % 2 ? 1250 : 900, t + i * 0.3);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.05, t); g.gain.setValueAtTime(0.05, t + 7); g.gain.linearRampToValueAtTime(0, t + 7.3);
    const p = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    if (p) { p.pan.value = pan; o.connect(g); g.connect(p); p.connect(this.lowpass); } else { o.connect(g); g.connect(this.lowpass); }
    o.start(t); o.stop(t + 7.4);
  }
  // incasso: un trillo leggero
  cash() { if (this.ctx) { this.coins(); setTimeout(() => this.chime(), 150); } }

  // motore vicino: alza il rumore del traffico quando un'auto passa accanto
  engines(near) { if (this.ctx && this.layers) this._set(this.layers.traffic.g.gain, Math.min(0.14, 0.02 + near * 0.12), 0.25); }

  bell(t, vol = 0.25) {
    if (!this.ctx) return;
    const ctx = this.ctx, base = 392;
    for (const [r, a, d] of [[0.5, 0.5, 6], [1, 1, 5], [1.19, 0.6, 3.5], [1.5, 0.45, 3], [2, 0.35, 2.5], [2.52, 0.25, 2], [3.01, 0.15, 1.5], [4.17, 0.1, 1]]) {
      const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = base * r;
      const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol * a * 0.4, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      o.connect(g); g.connect(this.lowpass); g.connect(this.reverb); o.start(t); o.stop(t + d + 0.1);
    }
  }

  _burst(freq, q, dur, vol, type = 'bandpass', toReverb = 0) {
    const ctx = this.ctx, t = ctx.currentTime;
    const src = ctx.createBufferSource(); src.buffer = this.white;
    const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
    const g = ctx.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g); g.connect(this.lowpass);
    if (toReverb) { const rg = ctx.createGain(); rg.gain.value = toReverb; g.connect(rg); rg.connect(this.reverb); }
    src.start(t, Math.random() * 2); src.stop(t + dur + 0.02);
  }

  step(speed, surface, inside) {
    if (!this.ctx || this.ctx.state !== 'running') return;
    const v = Math.min(1, speed / 7);
    if (surface === 'ferro') { this._burst(2400 + Math.random() * 600, 7, 0.09, 0.05 + v * 0.05, 'bandpass', inside); this._burst(180, 1, 0.06, 0.08); }
    else if (surface === 'piastrelle') { this._burst(3200, 2, 0.05, 0.06 + v * 0.05, 'bandpass', 0.8); }
    else if (surface === 'moquette') { this._burst(400, 0.7, 0.07, 0.04 + v * 0.03, 'lowpass', 0.2); }
    else { this._burst(1500 + Math.random() * 500, 1.3, 0.05, 0.05 + v * 0.06, 'bandpass', inside * 0.6); this._burst(120, 0.8, 0.05, 0.07 * (0.5 + v)); }
  }

  land(v) { if (this.ctx) { this._burst(140, 0.8, 0.12, Math.min(0.2, v * 0.03)); this._burst(1300, 1, 0.06, 0.05); } }

  shutter() {
    if (!this.ctx) return;
    this._burst(5000, 1, 0.015, 0.25, 'highpass');
    setTimeout(() => this._burst(3800, 2, 0.03, 0.15, 'bandpass'), 70);
  }

  chime() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    [72, 76, 79, 84].forEach((n, i) => setTimeout(() => this._musicBox(NOTE(n), 0.08), i * 110));
    this.bell(t + 0.6, 0.06);
  }

  whoosh(up = true) {
    if (!this.ctx) return;
    const ctx = this.ctx, t = ctx.currentTime;
    const src = ctx.createBufferSource(); src.buffer = this.pink;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = 2;
    f.frequency.setValueAtTime(up ? 200 : 2400, t); f.frequency.exponentialRampToValueAtTime(up ? 2400 : 200, t + 1.6);
    const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.25, t + 0.5); g.gain.exponentialRampToValueAtTime(0.0001, t + 2);
    src.connect(f); f.connect(g); g.connect(this.lowpass); g.connect(this.reverb);
    src.start(t); src.stop(t + 2.1);
  }

  // voce sintetica: sillabe che seguono il testo; pan = -1 sinistra, 1 destra
  babble(text, pitch = 1, pan = 0, vol = 0.09, tone = '') {
    if (!this.ctx || this.ctx.state !== 'running') return;
    const ctx = this.ctx, t0 = ctx.currentTime + 0.02;
    const syl = Math.min(18, Math.max(3, Math.round(text.replace(/[^a-zàèéìòù]/gi, '').length / 3)));
    const out = ctx.createGain(); out.gain.value = vol;
    const p = ctx.createStereoPanner(); p.pan.value = Math.max(-1, Math.min(1, pan));
    out.connect(p); p.connect(this.lowpass); if (tone === 'strange') p.connect(this.reverb);
    const base = (tone === 'strange' ? 120 : tone === 'rude' ? 190 : 165) * pitch;
    const step = tone === 'strange' ? 0.16 : tone === 'rude' ? 0.075 : 0.095;
    for (let i = 0; i < syl; i++) {
      const t = t0 + i * step * (0.85 + Math.random() * 0.3);
      const o = ctx.createOscillator(); o.type = 'triangle';
      const f = base * (0.85 + Math.random() * 0.35) * (tone === 'strange' ? 1 - i / syl * 0.4 : 1);
      o.frequency.setValueAtTime(f, t); o.frequency.linearRampToValueAtTime(f * (tone === 'strange' ? 0.7 : 1.08), t + step * 0.8);
      const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 600 + Math.random() * 1400; bp.Q.value = 2.5;
      const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(1, t + 0.015); g.gain.exponentialRampToValueAtTime(0.001, t + step * 0.9);
      o.connect(bp); bp.connect(g); g.connect(out); o.start(t); o.stop(t + step);
    }
  }
  coins() {
    if (!this.ctx) return;
    for (let i = 0; i < 4; i++) setTimeout(() => { this._burst(5200 + Math.random() * 2400, 18, 0.12, 0.05, 'bandpass', 0.2); }, i * 70 + Math.random() * 30);
  }
  espresso() {
    if (!this.ctx) return;
    const ctx = this.ctx, t = ctx.currentTime;
    const src = ctx.createBufferSource(); src.buffer = this.white;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = 1.2; f.frequency.setValueAtTime(3000, t); f.frequency.linearRampToValueAtTime(1800, t + 1.4);
    const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.09, t + 0.2); g.gain.linearRampToValueAtTime(0, t + 1.5);
    src.connect(f); f.connect(g); g.connect(this.lowpass); src.start(t); src.stop(t + 1.6);
    setTimeout(() => this._burst(2600, 6, 0.06, 0.06), 1600);
  }
  rustle() { if (this.ctx) for (let i = 0; i < 5; i++) setTimeout(() => this._burst(3500 + Math.random() * 3000, 1, 0.08, 0.04, 'highpass'), i * 60); }
  lighter() { if (this.ctx) { this._burst(4500, 3, 0.04, 0.12); setTimeout(() => this._burst(800, 0.7, 0.5, 0.05, 'lowpass'), 120); } }

  glass() { if (this.ctx) { this._burst(4200, 12, 0.25, 0.06, 'bandpass', 0.3); this._burst(900, 1, 0.08, 0.04); } }

  // rissa: colpo sordo, colpo a vuoto, urlo, sirena della polizia
  punch(hit = true) {
    if (!this.ctx) return;
    if (!hit) { this._burst(900, 0.6, 0.12, 0.05, 'bandpass'); return; }
    const ctx = this.ctx, t = ctx.currentTime;
    const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.setValueAtTime(120, t); o.frequency.exponentialRampToValueAtTime(45, t + 0.12);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.35, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
    o.connect(g); g.connect(this.lowpass); o.start(t); o.stop(t + 0.18);
    this._burst(600, 0.9, 0.07, 0.18, 'lowpass', 0.15);
  }
  scream(pitch = 1, pan = 0) {
    if (!this.ctx || this.ctx.state !== 'running') return;
    const ctx = this.ctx, t = ctx.currentTime;
    const o = ctx.createOscillator(); o.type = 'sawtooth';
    const f0 = 420 * pitch;
    o.frequency.setValueAtTime(f0, t); o.frequency.linearRampToValueAtTime(f0 * 1.5, t + 0.25); o.frequency.linearRampToValueAtTime(f0 * 1.1, t + 0.9);
    const vib = ctx.createOscillator(); vib.frequency.value = 7; const vg = ctx.createGain(); vg.gain.value = 18; vib.connect(vg); vg.connect(o.frequency);
    const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1400; bp.Q.value = 1.6;
    const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.07, t + 0.06); g.gain.linearRampToValueAtTime(0, t + 0.95);
    const p = ctx.createStereoPanner(); p.pan.value = Math.max(-1, Math.min(1, pan));
    o.connect(bp); bp.connect(g); g.connect(p); p.connect(this.lowpass); p.connect(this.reverb);
    o.start(t); vib.start(t); o.stop(t + 1); vib.stop(t + 1);
  }
  // sirena bitonale italiana; vol 0 la spegne
  siren(vol) {
    if (!this.ctx) return;
    const ctx = this.ctx;
    if (!this.sirenOsc) {
      this.sirenOsc = ctx.createOscillator(); this.sirenOsc.type = 'square';
      const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 1800;
      this.sirenGain = ctx.createGain(); this.sirenGain.gain.value = 0;
      this.sirenOsc.connect(f); f.connect(this.sirenGain); this.sirenGain.connect(this.lowpass); this.sirenGain.connect(this.reverb);
      this.sirenOsc.start(); this.sirenT = 0;
    }
    const t = ctx.currentTime;
    if (t > this.sirenT) { this.sirenHi = !this.sirenHi; this.sirenOsc.frequency.setValueAtTime(this.sirenHi ? 660 : 495, t); this.sirenT = t + 0.6; }
    this._set(this.sirenGain.gain, Math.min(0.05, vol * 0.05), 0.3);
  }
}
