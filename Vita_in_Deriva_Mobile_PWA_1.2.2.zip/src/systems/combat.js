// Violenza opzionale, spenta finché il giocatore non la attiva (e conferma di essere adulto).
// Risse a mani nude, rapine a chi è a terra, gente che scappa, polizia che insegue.
// Limiti fissi: chi va a terra resta svenuto e poi si rialza; niente torture, niente violenza sessuale,
// nessun bersaglio scelto per gruppo o identità; i personaggi della storia non si possono colpire.
import { euro } from './economy.js';

const PROTECTED = new Set(['marta', 'aldo', 'teo', 'nora', 'nora-back']);
const pick = (a) => a[Math.floor(Math.random() * a.length)];
export const FIGHT_LINES = {
  flee: ['Aiuto!', 'Chiamate la polizia!', 'È impazzito!', 'Via, via, via!', 'Ma cosa fai?!', 'Lasciami stare!'],
  fight: ['Vieni qua, che ti sistemo.', 'Hai sbagliato persona.', 'Adesso vedi.', 'Ma chi ti credi di essere?', 'Ti spacco.'],
  police: ['Fermo! Polizia locale!', 'Alt! Mani bene in vista!', 'Non fare lo stupido, fermati!', 'Centrale, lo abbiamo in vista.'],
  protect: ['Ehi! Ma sei fuori?', 'Non ci provare nemmeno.', 'Calmati. Respira.', 'Non con me.'],
  miss: ['Ahah, non mi prendi neanche.', 'Sei ubriaco, vai a casa.', 'Mancato.'],
  mug: ['Fermo lì. Il portafoglio. Adesso.', 'Non fare scherzi. Dammi i soldi e nessuno si fa male.']
};

export class Combat {
  // g: { settings, crowd(), player(), avatar(), wallet(), audio, toast, mods(), save(), hospital(), jail(), pan(x,z) }
  constructor(g) {
    this.g = g;
    this.health = 100; this.heat = 0; this.cd = 0; this.t = 0; this.lastHurt = -99;
    this.down = null; this.downT = 0; this.black = 0; this.flash = 0; this.spawnT = 0; this.told = {};
  }
  get enabled() { return !!this.g.settings.violence; }
  stars() { return this.heat <= 0.05 ? 0 : Math.min(3, Math.ceil(this.heat)); }

  // pugno davanti a sé: colpisce la persona più vicina nel cono di fronte
  attack() {
    if (!this.enabled || this.cd > 0 || this.down) return null;
    const g = this.g, P = g.player(), crowd = g.crowd(), A = g.audio;
    this.cd = 0.55;
    // si colpisce dove si guarda
    P.facing = P.yaw + Math.PI;
    g.avatar().gesture('punch', 0.42);
    const fx = Math.sin(P.facing), fz = Math.cos(P.facing);
    let best = null, bs = -Infinity;
    for (const n of crowd.npcs) {
      if (!n.root.visible || n.ko > 0 || n === crowd.clerkNpc) continue;
      const dx = n.x - P.pos.x, dz = n.z - P.pos.z, d = Math.hypot(dx, dz);
      if (d > 1.7 || d < 0.01) continue;
      const dot = (dx * fx + dz * fz) / d;
      if (dot < 0.5) continue;
      if (dot - d * 0.25 > bs) { bs = dot - d * 0.25; best = n; }
    }
    if (!best) { A.punch(false); return null; }
    const m = g.mods();
    if (PROTECTED.has(best.story)) { A.punch(false); best.hitT = 0.35; crowd.say(best, pick(FIGHT_LINES.protect), 'rude'); return 'protected'; }
    if (Math.random() < (m.drunk || 0) * 0.45 + (m.opi || 0) * 0.3) {
      A.punch(false); crowd.say(best, pick(FIGHT_LINES.miss), 'rude');
      if (best.rude || best.role === 'pusher') best.aggro = true;
      return 'miss';
    }
    const dmg = (16 + Math.random() * 12) * (1 + 0.5 * (m.stim || 0)) * (1 - 0.3 * (m.crash || 0));
    setTimeout(() => A.punch(true), 90);
    const res = crowd.hurt(best, dmg);
    const pan = g.pan(best.x, best.z);
    if (res === 'ko') {
      this.tell('ko', 'È a terra, svenuto. Puoi frugargli nelle tasche (<em>E</em>), ma qualcuno ha visto.');
    } else if (best.kind === 'police' || best.role === 'pusher' || best.rude || (!best.L.sitting && Math.random() < 0.15)) {
      best.aggro = true; best.flee = 0;
      crowd.say(best, pick(best.kind === 'police' ? FIGHT_LINES.police : FIGHT_LINES.fight), 'rude');
    } else if (!best.L.sitting) {
      best.flee = 7; best.fleeFrom = { x: P.pos.x, z: P.pos.z };
      crowd.say(best, pick(FIGHT_LINES.flee), 'rude');
      A.scream(best.voice || 1, pan);
    }
    const seen = crowd.panic(P.pos.x, P.pos.z, 16, best);
    if (seen > 0) setTimeout(() => A.scream(0.8 + Math.random() * 0.6, (Math.random() - 0.5) * 1.6), 250);
    // la polizia arriva se qualcuno ha visto; senza testimoni resta quasi tutto tra te e lui
    this.wanted(best.kind === 'police' ? 1.2 : seen > 0 ? (res === 'ko' ? 0.7 : 0.25) : (res === 'ko' ? 0.25 : 0.05));
    return res;
  }

  // un reato (furto, consegna sospetta, investimento): la polizia arriva anche se la violenza è spenta
  crime(amount, what) {
    this.crimes = (this.crimes || 0) + 1;
    this.lastCrime = what || 'reato';
    this.wanted(amount);
  }

  wanted(amount) {
    const before = this.stars();
    this.heat = Math.min(3, this.heat + amount);
    const s = this.stars();
    if (s > before) this.g.toast(s === 1 ? 'Qualcuno ha chiamato la polizia.' : s === 2 ? 'Arrivano altre pattuglie.' : 'Mezza città ti sta cercando.', true);
  }

  // frugare nelle tasche di chi è svenuto
  rob(n) {
    if (!this.enabled || !(n.ko > 0)) return false;
    const g = this.g;
    if (n.robbed) { g.toast('Gli hai già preso tutto.'); return false; }
    n.robbed = true;
    const v = Math.round(n.role === 'pusher' ? 25 + Math.random() * 60 : n.kind === 'police' ? 0 : 2 + Math.random() * 30);
    g.avatar().gesture('take', 0.8);
    g.audio.rustle();
    if (v > 0) { g.wallet().earn(v); setTimeout(() => g.audio.coins(), 300); g.toast(`Gli prendi ${euro(v)}. Non ti senti meglio.`); }
    else g.toast('Niente soldi, solo una radio che gracchia il tuo indirizzo.');
    this.wanted(0.5);
    g.save();
    return true;
  }

  // un colpo ricevuto
  hurtPlayer(dmg) {
    if (!this.enabled || this.down) return;
    this.health = Math.max(0, this.health - dmg);
    this.lastHurt = this.t; this.flash = 1;
    this.g.avatar().gesture('hurt', 0.4);
    this.g.audio.punch(true);
    if (this.health <= 0) this._goDown('ko');
  }
  onNpcHit(n) { this.hurtPlayer(n.kind === 'police' ? 9 : n.role === 'pusher' ? 15 : 9 + Math.random() * 5); }
  onCaught() { if (!this.down) this._goDown('arresto'); }

  _goDown(kind) {
    this.down = kind; this.downT = 0; this.downDid = false;
    this.g.player().enabled = false;
  }
  _wake() {
    const g = this.g, w = g.wallet(), crowd = g.crowd();
    if (this.down === 'arresto') {
      const fine = Math.min(w.money, 40 * Math.max(1, this.stars()));
      w.pay(fine);
      g.jail();
      g.toast(`Una notte in questura. Multa di ${euro(fine)}. All'alba ti lasciano andare con un foglio che non leggi.`, true);
    } else {
      const lost = Math.round(w.money * 0.4 * 100) / 100;
      w.pay(lost);
      g.hospital();
      g.toast(`Ti svegli al Pronto Soccorso con un cerotto sul sopracciglio.${lost > 0 ? ` Mancano ${euro(lost)} dal portafoglio.` : ''}`, true);
    }
    this.health = 70; this.heat = 0;
    for (const n of crowd.npcs) { if (n.aggro) { n.aggro = false; crowd._goHome(n); } if (n.kind === 'police') { n.chase = false; n.leaving = true; } }
    for (const n of crowd.police) crowd.remove(n);
    g.save();
  }

  tell(key, html) { if (this.told[key]) return; this.told[key] = true; this.g.toast(html, true); }

  update(dt, playing) {
    const g = this.g, crowd = g.crowd(), P = g.player();
    this.t += dt; this.cd -= dt;
    this.flash = Math.max(0, this.flash - dt * 2.5);
    if (this.down) {
      this.downT += dt;
      this.black = this.downT < 1.5 ? this.downT / 1.5 : Math.max(0, 1 - (this.downT - 3) / 2);
      if (!this.downDid && this.downT >= 1.6) { this.downDid = true; this._wake(); }
      if (this.downT > 5) { this.down = null; this.black = 0; if (playing()) P.enabled = true; }
      g.audio.siren(0);
      return;
    }
    if (!this.enabled && this.heat <= 0.05) {
      if (this.heat || crowd.police.length) { this.heat = 0; for (const n of crowd.police) crowd.remove(n); for (const n of crowd.npcs) if (n.aggro) { n.aggro = false; crowd._goHome(n); } }
      this.health = 100; g.audio.siren(0);
      return;
    }
    if (this.t - this.lastHurt > 8 || !this.enabled) this.health = Math.min(100, this.health + dt * (this.enabled ? 2 : 20));
    // la polizia: una pattuglia per stella
    const cops = crowd.police.filter((n) => n.chase);
    let nearest = Infinity;
    for (const n of cops) nearest = Math.min(nearest, Math.hypot(n.x - P.pos.x, n.z - P.pos.z));
    // anche le volanti contano: finché una ti sta dietro non ti perdono
    if (g.policeCarDist) nearest = Math.min(nearest, g.policeCarDist());
    this.spawnT -= dt;
    if (cops.length < this.stars() && this.spawnT <= 0 && !(g.driving && g.driving())) {
      this.spawnT = 5;
      const n = crowd.spawnPolice(P.pos);
      if (n) { crowd.say(n, pick(FIGHT_LINES.police), 'rude'); this.tell('police', 'La polizia ti cerca. Scappa correndo, nasconditi lontano, oppure fatti prendere.'); }
    }
    // la tensione cala se nessuno ti vede
    if (nearest > 40) this.heat = Math.max(0, this.heat - dt * 0.06);
    else if (nearest > 20) this.heat = Math.max(0, this.heat - dt * 0.015);
    if (this.heat <= 0.05 && (cops.length || (g.policeCarDist && g.policeCarDist() < 1e9))) {
      this.heat = 0;
      for (const n of cops) { n.chase = false; n.aggro = false; n.leaving = true; }
      g.toast('Ti hanno perso di vista.');
    }
    g.audio.siren(cops.length || nearest < 1e9 ? Math.max(0, 1 - nearest / 90) : 0);
  }
}
