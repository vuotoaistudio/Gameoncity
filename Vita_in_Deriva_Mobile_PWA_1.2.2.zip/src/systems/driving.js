// Guidare: auto e scooter con fisica arcade (sterzo che dipende dalla velocità, freno a mano, urti),
// telecamera che insegue, fari di notte, furti d'auto e pattuglie che inseguono a sirene accese.
import * as THREE from 'three';
import { carGeometries, scooterGeometries } from '../fx/vehicles.js';

export const SPEC = {
  auto: { name: 'utilitaria', max: 19, rev: 5, acc: 5.2, brake: 13, wb: 2.6, steer: 0.55, r: 0.82, off: 1.15, half: [0.92, 2.1], cam: 6.2, camH: 2.0 },
  scooter: { name: 'scooter', max: 15, rev: 1.8, acc: 6.5, brake: 11, wb: 1.3, steer: 0.5, r: 0.42, off: 0.45, half: [0.38, 0.95], cam: 4.0, camH: 1.7 },
  polizia: { name: 'volante', max: 21, rev: 5, acc: 7, brake: 14, wb: 2.6, steer: 0.62, r: 0.78, off: 1.15, half: [0.92, 2.1], cam: 6.2, camH: 2.0 }
};
const LINES = {
  scared: ['Ma guarda dove vai!', 'Pazzo!', 'Rallenta!', 'Ehi! Il marciapiede!', 'Ma sei matto?'],
  thief: ['Al ladro! Al ladro!', 'La mia macchina!', 'Fermatelo!', 'Chiamate i carabinieri!'],
  witness: ['Ma quello sta rubando una macchina…', 'Ehi! Che fai?', 'Chiamo la polizia.']
};
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const wrap = (a) => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; };

let CAR_G = null, SCOOT_G = null;
function carMesh(color, police) {
  CAR_G ||= carGeometries();
  const g = new THREE.Group(), G = CAR_G;
  const paint = new THREE.MeshPhysicalMaterial({ color: new THREE.Color(color), roughness: 0.3, metalness: 0.55, clearcoat: 1, clearcoatRoughness: 0.07 });
  const add = (geo, mat, cast = true) => { const m = new THREE.Mesh(geo, mat); m.castShadow = cast; m.receiveShadow = true; g.add(m); return m; };
  add(G.body, paint);
  add(G.glass, new THREE.MeshStandardMaterial({ color: 0x0c0f12, roughness: 0.05, metalness: 0.2 }));
  add(G.trim, new THREE.MeshStandardMaterial({ color: 0x1a1a1c, roughness: 0.6 }), false);
  const head = new THREE.MeshBasicMaterial({ color: 0xdedad0 }), tail = new THREE.MeshBasicMaterial({ color: 0x7a0f10 });
  add(G.front, head, false); add(G.rear, tail, false);
  // ruote separate: girano e sterzano
  const wheelM = new THREE.MeshStandardMaterial({ color: 0x141414, roughness: 0.85 }), hubM = new THREE.MeshStandardMaterial({ color: 0x9a9ca0, roughness: 0.3, metalness: 0.9 });
  const wheels = [];
  for (const [x, z] of [[-0.8, 1.3], [0.8, 1.3], [-0.8, -1.32], [0.8, -1.32]]) {
    const pivot = new THREE.Group(); pivot.position.set(x, 0.31, z); g.add(pivot);
    const spin = new THREE.Group(); pivot.add(spin);
    const t = new THREE.Mesh(new THREE.CylinderGeometry(0.31, 0.31, 0.22, 16).rotateZ(Math.PI / 2), wheelM); t.castShadow = true;
    const h = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.17, 0.235, 10).rotateZ(Math.PI / 2), hubM);
    spin.add(t, h);
    wheels.push({ pivot, spin, front: z > 0 });
  }
  let bar = null;
  if (police) {
    // livrea: fascia chiara sulle fiancate e lampeggianti blu sul tetto
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(1.79, 0.12, 3.6), new THREE.MeshStandardMaterial({ color: 0xe9eef2, roughness: 0.4 }));
    stripe.position.set(0, 0.62, 0); g.add(stripe);
    bar = { L: new THREE.MeshBasicMaterial({ color: 0x1030ff }), R: new THREE.MeshBasicMaterial({ color: 0x1030ff }) };
    const l = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.1, 0.22), bar.L); l.position.set(-0.28, 1.53, -0.75); g.add(l);
    const r = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.1, 0.22), bar.R); r.position.set(0.28, 1.53, -0.75); g.add(r);
  }
  return { group: g, wheels, head, tail, bar, paint };
}
function scooterMesh(color) {
  SCOOT_G ||= scooterGeometries();
  const g = new THREE.Group(), G = SCOOT_G;
  const add = (geo, mat, cast = true) => { const m = new THREE.Mesh(geo, mat); m.castShadow = cast; m.receiveShadow = true; g.add(m); return m; };
  const lean = new THREE.Group(); g.add(lean);
  const addL = (geo, mat) => { const m = new THREE.Mesh(geo, mat); m.castShadow = true; lean.add(m); return m; };
  const paint = new THREE.MeshPhysicalMaterial({ color: new THREE.Color(color), roughness: 0.28, metalness: 0.2, clearcoat: 1, clearcoatRoughness: 0.08 });
  addL(G.paint, paint);
  addL(G.dark, new THREE.MeshStandardMaterial({ color: 0x23201d, roughness: 0.7 }));
  addL(G.chrome, new THREE.MeshStandardMaterial({ color: 0xcfd2d6, roughness: 0.15, metalness: 1 }));
  addL(G.wheels, new THREE.MeshStandardMaterial({ color: 0x151515, roughness: 0.85 }));
  const head = new THREE.MeshBasicMaterial({ color: 0xdedad0 }), tail = new THREE.MeshBasicMaterial({ color: 0x7a0f10 });
  addL(G.lamp, head); addL(G.tail, tail);
  void add;
  return { group: g, lean, wheels: [], head, tail, bar: null, paint };
}

let NEXT_ID = 1;
export class Vehicle {
  constructor(kind, color, x, z, yaw, flags = {}) {
    this.id = flags.id || 'v' + (NEXT_ID++);
    this.kind = kind; this.spec = SPEC[kind]; this.color = color;
    this.x = x; this.z = z; this.yaw = yaw; this.y = 0;
    this.speed = 0; this.steer = 0; this.spin = 0;
    this.owned = !!flags.owned; this.stolen = !!flags.stolen; this.police = kind === 'polizia';
    const m = kind === 'scooter' ? scooterMesh(color) : carMesh(color, this.police);
    Object.assign(this, { group: m.group, wheels: m.wheels, head: m.head, tail: m.tail, bar: m.bar, lean: m.lean });
    this.pose();
  }
  get fx() { return Math.sin(this.yaw); }
  get fz() { return Math.cos(this.yaw); }
  pose(dt = 0, night = 0, braking = false, t = 0) {
    this.group.position.set(this.x, this.y + (this.kind === 'scooter' ? 0 : 0.08), this.z);
    this.group.rotation.y = this.yaw;
    this.spin += this.speed * dt / (this.kind === 'scooter' ? 0.21 : 0.31);
    for (const w of this.wheels) { w.spin.rotation.x = this.spin; w.pivot.rotation.y = w.front ? this.steer : 0; }
    if (this.lean) this.lean.rotation.z = -this.steer * Math.min(1, Math.abs(this.speed) / 8) * 0.9;
    const lights = night > 0.35 || this.driven;
    this.head.color.setScalar(lights && night > 0.35 ? 3 : 0.75);
    this.tail.color.setRGB(braking ? 3 : lights && night > 0.35 ? 1.6 : 0.45, 0.02, 0.02);
    if (this.bar) {
      const on = Math.floor(t * 6) % 2 === 0;
      this.bar.L.color.setRGB(0.05, 0.15, on ? 4 : 0.2); this.bar.R.color.setRGB(0.05, 0.15, on ? 0.2 : 4);
    }
  }
}

export class Driving {
  // g: { scene, collision(), traffic(), crowd(), player(), avatar(), audio, camera, toast, combat(), settings, save(), city(), pan(x,z) }
  constructor(g) {
    this.g = g;
    this.vehicles = [];   // mezzi presenti in città (tuoi, rubati e lasciati, volanti)
    this.current = null;
    this.cops = [];
    this.lock = null;     // scasso in corso
    this.camYaw = 0; this.camDist = 6; this.mouseT = 0;
    this.light = new THREE.SpotLight(0xfff1d6, 0, 45, 0.55, 0.6, 1.4);
    this.light.castShadow = false;
    g.scene.add(this.light, this.light.target);
    this.stolenParked = new Set();
    this.t = 0;
  }

  // ---------- mezzi propri (salvati) ----------
  load(list) {
    for (const s of list || []) {
      if (!SPEC[s.kind] || !Number.isFinite(s.x)) continue;
      const v = new Vehicle(s.kind, s.color, s.x, s.z, s.yaw || 0, { owned: true, id: s.id });
      this._add(v);
    }
  }
  saveList() { return this.vehicles.filter((v) => v.owned).map((v) => ({ id: v.id, kind: v.kind, color: v.color, x: +v.x.toFixed(2), z: +v.z.toFixed(2), yaw: +v.yaw.toFixed(3) })); }
  _add(v) { this.vehicles.push(v); this.g.scene.add(v.group); return v; }
  _remove(v) { this.g.scene.remove(v.group); this.vehicles = this.vehicles.filter((q) => q !== v); }

  // un mezzo comprato arriva su una strada libera vicino a te
  deliver(kind, color) {
    const P = this.g.player().pos, col = this.g.collision();
    let spot = null;
    for (const r of this.g.city().features.roads) {
      if (r.width < 5 || r.bridge) continue;
      for (const p of r.pts) {
        const d = Math.hypot(p[0] - P.x, p[1] - P.z);
        if (d < 8 || d > 60 || !col.isFree(p[0], p[1])) continue;
        if (!spot || d < spot.d) spot = { d, p };
      }
    }
    const at = spot ? spot.p : (col.nearestFree(P.x + 3, P.z) || [P.x + 3, P.z]);
    const v = this._add(new Vehicle(kind, color, at[0], at[1], Math.atan2(P.x - at[0], P.z - at[1]), { owned: true }));
    return v;
  }

  // ---------- salire e scendere ----------
  // il mezzo più vicino a cui puoi salire, con l'etichetta per il suggerimento a schermo
  nearest(P) {
    let best = null;
    const consider = (d, o) => { if (d < 3.2 && (!best || d < best.d)) best = Object.assign({ d }, o); };
    for (const v of this.vehicles) {
      if (v.police || v === this.current) continue;
      consider(Math.hypot(v.x - P.x, v.z - P.z) - v.spec.half[0], { type: 'mine', v, label: v.owned ? `Sali sul tuo ${v.spec.name}` : `Sali sull'${v.spec.name === 'scooter' ? 'o scooter' : 'auto'}` });
    }
    const pk = this.g.city().parked;
    if (pk) pk.cars.forEach((c, i) => { if (!this.stolenParked.has(i)) consider(Math.hypot(c.x - P.x, c.z - P.z) - 0.9, { type: 'parked', i, c, label: 'Forza la portiera e ruba l\'auto' }); });
    const tr = this.g.traffic();
    if (tr) for (const v of tr.cars) if (v.pose && v.v < 3.5) consider(Math.hypot(v.pose.x - P.x, v.pose.z - P.z) - 0.9, { type: 'traffic', t: v, label: 'Tira giù l\'autista e prendi l\'auto' });
    return best;
  }

  enter(target) {
    const g = this.g;
    if (target.type === 'mine') return this._drive(target.v);
    if (target.type === 'parked') {
      if (this.lock) return;
      // scasso: qualche secondo chinato sulla portiera
      this.lock = { t: 0, dur: 2.6, target };
      g.avatar().gesture('take', 2.6);
      g.audio.rustle();
      g.toast('Forzi la serratura…');
      return;
    }
    if (target.type === 'traffic') {
      const tv = target.t, pose = tv.pose;
      const color = '#' + tv.color.getHexString();
      tv.w = -1; tv.pose = null; tv.cool = 40;
      const v = this._add(new Vehicle('auto', color, pose.x, pose.z, pose.yaw, { stolen: true }));
      // l'autista scende e scappa urlando
      const crowd = g.crowd();
      const side = [pose.dz, -pose.dx];
      const n = crowd._static('passante', pose.x + side[0] * 1.6, pose.z + side[1] * 1.6, pose.yaw, {});
      n.flee = 9; n.fleeFrom = { x: pose.x, z: pose.z };
      crowd.say(n, pick(LINES.thief), 'rude');
      g.audio.scream(1.1, g.pan(pose.x, pose.z));
      const seen = crowd.panic(pose.x, pose.z, 18, n);
      g.combat().crime(1.3 + (seen > 0 ? 0.3 : 0), 'Furto d\'auto con l\'autista dentro');
      this._drive(v);
    }
  }

  _finishLock() {
    const g = this.g, tg = this.lock.target, pk = g.city().parked, c = tg.c;
    this.lock = null;
    this.stolenParked.add(tg.i);
    // l'auto parcheggiata sparisce dalla fila e diventa un mezzo vero
    const zero = new THREE.Matrix4().makeScale(0, 0, 0);
    for (const m of pk.meshes) { m.setMatrixAt(tg.i, zero); m.instanceMatrix.needsUpdate = true; }
    for (const idx of pk.segs[tg.i] || []) g.collision().off.add(idx);
    const v = this._add(new Vehicle('auto', c.color || '#7d7d78', c.x, c.z, c.a, { stolen: true }));
    v.parkedIndex = tg.i;
    // c'è chi guarda? A volte parte l'allarme
    const crowd = g.crowd();
    let seen = 0;
    for (const n of crowd.npcs) if (n.root.visible && !n.ko && n.kind !== 'police' && Math.hypot(n.x - c.x, n.z - c.z) < 16) { seen++; if (seen === 1) crowd.say(n, pick(LINES.witness), 'rude'); }
    const alarm = Math.random() < 0.35;
    if (alarm) { g.audio.carAlarm(g.pan(c.x, c.z)); g.toast('Parte l\'allarme!', true); }
    g.combat().crime((seen ? 0.9 : 0.15) + (alarm ? 0.6 : 0), 'Furto d\'auto');
    this._drive(v);
  }

  _drive(v) {
    const g = this.g, P = g.player();
    this.current = v; v.driven = true;
    this.camYaw = v.yaw + Math.PI; P.lookYaw = P.yaw = this.camYaw; P.lookPitch = 0.22;
    this.camDist = v.spec.cam;
    g.audio.engineStart(v.kind);
    g.onEnter && g.onEnter(v);
  }

  exit(silent) {
    const v = this.current; if (!v) return;
    const g = this.g, P = g.player(), col = g.collision();
    v.driven = false; v.speed = 0;
    this.current = null;
    // scendi dal lato del guidatore (a sinistra)
    const lx = v.fz, lz = -v.fx;
    const w = v.spec.half[0] + 0.55;
    const spot = col.nearestFree(v.x + lx * w, v.z + lz * w, 8) || col.nearestFree(v.x - lx * w, v.z - lz * w, 8) || [v.x, v.z];
    P.teleport(spot[0], spot[1], v.yaw + Math.PI);
    P.jumpQueued = false;
    this.light.intensity = 0;
    g.audio.engineStop();
    g.onExit && g.onExit(v, silent);
  }

  // ---------- ogni fotogramma ----------
  update(dt, ctx) {
    const g = this.g;
    this.t += dt;
    const night = ctx.night;
    if (this.lock) {
      this.lock.t += dt;
      const P = g.player().pos, c = this.lock.target.c;
      if (Math.hypot(P.x - c.x, P.z - c.z) > 3.6) { this.lock = null; g.toast('Hai lasciato perdere.'); }
      else if (this.lock.t >= this.lock.dur) this._finishLock();
    }
    for (const v of this.vehicles) if (v !== this.current && !v.police) v.pose(0, night, false, this.t);
    this._cops(dt, ctx);
    const v = this.current;
    if (!v) return null;
    return this._physics(v, dt, ctx);
  }

  _input() {
    const P = this.g.player(), k = P.keys;
    let thr = 0, st = 0;
    if (P.enabled) {
      if (k.has('KeyW') || k.has('ArrowUp')) thr += 1;
      if (k.has('KeyS') || k.has('ArrowDown')) thr -= 1;
      if (k.has('KeyA') || k.has('ArrowLeft')) st += 1;
      if (k.has('KeyD') || k.has('ArrowRight')) st -= 1;
      thr -= P.touch.mz; st -= P.touch.mx;
    }
    return { thr: Math.max(-1, Math.min(1, thr)), st: Math.max(-1, Math.min(1, st)), hand: P.enabled && k.has('Space') };
  }

  // fisica condivisa da giocatore e volanti
  _step(v, dt, thr, st, hand) {
    const S = v.spec, col = this.g.collision();
    const ox = v.x, oz = v.z;
    let braking = false;
    if (thr > 0.05) {
      if (v.speed < -0.3) { v.speed += S.brake * dt; braking = true; }
      else v.speed += S.acc * thr * dt * Math.max(0.05, 1 - v.speed / S.max);
    } else if (thr < -0.05) {
      if (v.speed > 0.3) { v.speed -= S.brake * dt; braking = true; }
      else v.speed = Math.max(-S.rev, v.speed - S.acc * 0.6 * dt);
    } else {
      const drag = (0.9 + 0.012 * v.speed * v.speed) * dt;
      v.speed = Math.abs(v.speed) < drag ? 0 : v.speed - Math.sign(v.speed) * drag;
    }
    if (hand) { const d = 9 * dt; v.speed = Math.abs(v.speed) < d ? 0 : v.speed - Math.sign(v.speed) * d; braking = true; }
    const target = st * S.steer * (1 - 0.55 * Math.min(1, Math.abs(v.speed) / S.max)) * (hand ? 1.35 : 1);
    v.steer += (target - v.steer) * Math.min(1, dt * 7);
    v.yaw += v.speed / S.wb * Math.tan(v.steer) * dt;
    v.x += Math.sin(v.yaw) * v.speed * dt;
    v.z += Math.cos(v.yaw) * v.speed * dt;
    // urti: due cerchi lungo l'asse (davanti e dietro)
    let px = 0, pz = 0, bridge = false;
    for (const s of [1, -1]) {
      const cx = v.x + Math.sin(v.yaw) * S.off * s, cz = v.z + Math.cos(v.yaw) * S.off * s;
      const [rx, rz, br] = col.resolve(cx, cz, S.r);
      px += rx - cx; pz += rz - cz; bridge = bridge || br;
    }
    let impact = 0;
    const push = Math.hypot(px, pz);
    if (push > 0.015) {
      v.x += px; v.z += pz;
      const head = (px * Math.sin(v.yaw) + pz * Math.cos(v.yaw)) / push;
      impact = Math.abs(v.speed) * Math.abs(head);
      v.speed *= head * Math.sign(v.speed) < -0.5 ? -0.18 : 0.75;
    }
    if (!bridge && col.inWater(v.x, v.z)) { v.x = ox; v.z = oz; impact = Math.max(impact, Math.abs(v.speed)); v.speed = 0; }
    v.y = bridge ? 0.32 : 0;
    return { braking, impact };
  }

  _physics(v, dt, ctx) {
    const g = this.g, P = g.player();
    const { thr, st, hand } = this._input();
    const { braking, impact } = this._step(v, dt, thr, st, hand);
    // traffico e volanti: ci si urta
    let hitCar = 0;
    const others = [];
    const tr = g.traffic();
    if (tr) for (const t of [...tr.cars, ...tr.trams]) if (t.pose) others.push({ x: t.pose.x, z: t.pose.z, r: t.kind === 'tram' ? 2.6 : 1.4, obj: t });
    for (const c of this.vehicles) if (c !== v) others.push({ x: c.x, z: c.z, r: c.spec.r + 0.4, obj: c });
    for (const o of others) {
      const dx = v.x - o.x, dz = v.z - o.z, d = Math.hypot(dx, dz), min = o.r + v.spec.r;
      if (d < min && d > 1e-3) { v.x = o.x + dx / d * min; v.z = o.z + dz / d * min; hitCar = Math.max(hitCar, Math.abs(v.speed)); v.speed *= 0.35; if (o.obj.speed !== undefined && o.obj !== v) o.obj.speed = (o.obj.speed || 0) * 0.5; }
    }
    const hit = Math.max(impact, hitCar);
    if (hit > 5.5 && this.t - (this.lastCrash || 0) > 0.6) {
      this.lastCrash = this.t;
      g.audio.crash(Math.min(1, hit / 15));
      this.shake = Math.min(1, hit / 12);
      if (hit > 9) g.combat().hurtPlayer(Math.round(hit * 0.8));
    }
    // pedoni: si scansano, si spaventano; con la violenza attiva un colpo forte li butta a terra
    const crowd = g.crowd();
    for (const n of crowd.npcs) {
      if (!n.root.visible || n.ko > 0 || n.L.sitting) continue;
      const dx = n.x - v.x, dz = n.z - v.z;
      const lz = dx * Math.sin(v.yaw) + dz * Math.cos(v.yaw), lx = dx * Math.cos(v.yaw) - dz * Math.sin(v.yaw);
      const hw = v.spec.half[0] + 0.45, hl = v.spec.half[1] + 0.45;
      if (Math.abs(lx) < hw && Math.abs(lz) < hl) {
        const s = Math.sign(lx) || 1;
        n.x += Math.cos(v.yaw) * (hw - Math.abs(lx) + 0.1) * s; n.z += -Math.sin(v.yaw) * (hw - Math.abs(lx) + 0.1) * s;
        if (Math.abs(v.speed) > 4 && !crowd.busy(n)) {
          if (g.settings.violence && Math.abs(v.speed) > 8 && n.kind !== 'police' && !n.story) {
            crowd.hurt(n, 200); g.audio.punch(true);
            const seen = crowd.panic(n.x, n.z, 20, n);
            g.combat().crime(seen ? 1.4 : 0.7, 'Investimento');
          } else if (!n.story) { n.flee = 3; n.fleeFrom = { x: v.x, z: v.z }; crowd.say(n, pick(LINES.scared), 'rude'); }
        }
      }
    }
    v.pose(dt, ctx.night, braking || (thr < -0.05 && v.speed > 0.3), this.t);
    // il giocatore viaggia col mezzo
    P.pos.set(v.x, v.y, v.z); P.y = v.y; P.vel.set(Math.sin(v.yaw) * v.speed, Math.cos(v.yaw) * v.speed); P.grounded = true;
    P.facing = v.yaw;
    const av = g.avatar();
    if (v.kind === 'scooter') {
      av.root.visible = true;
      av.root.position.set(v.x - Math.sin(v.yaw) * 0.22, v.y - 0.12, v.z - Math.cos(v.yaw) * 0.22);
      av.root.rotation.set(0, v.yaw, 0);
      av.animate(dt, 0, false, 0);
      av.sit(v.lean ? v.lean.rotation.z : 0);
    } else av.root.visible = false;
    // fari: una luce vera davanti, accesa di notte
    if (ctx.night > 0.35) {
      this.light.intensity = 22 * ctx.night;
      this.light.position.set(v.x + Math.sin(v.yaw) * 2, v.y + 0.75, v.z + Math.cos(v.yaw) * 2);
      this.light.target.position.set(v.x + Math.sin(v.yaw) * 14, 0, v.z + Math.cos(v.yaw) * 14);
    } else this.light.intensity = 0;
    g.audio.engine(Math.abs(v.speed) / v.spec.max, Math.abs(thr), v.kind);
    this._camera(v, dt);
    return { speed: Math.abs(v.speed), kmh: Math.round(Math.abs(v.speed) * 3.6) };
  }

  _camera(v, dt) {
    const g = this.g, P = g.player(), cam = g.camera, col = g.collision();
    // il mouse ruota la visuale; se lo lasci, torna dietro al mezzo
    const behind = v.yaw + Math.PI;
    if (Math.abs(wrap(P.lookYaw - this.lastLook || 0)) > 1e-4) this.mouseT = 1.6;
    this.mouseT -= dt;
    if (this.mouseT <= 0 && Math.abs(v.speed) > 1) P.lookYaw += wrap(behind - P.lookYaw) * Math.min(1, dt * 2.5);
    this.lastLook = P.lookYaw;
    P.yaw = P.lookYaw; P.pitch = P.lookPitch = Math.max(0.05, Math.min(0.9, P.lookPitch));
    const yaw = P.yaw, pitch = P.pitch;
    const pivot = new THREE.Vector3(v.x, v.y + v.spec.camH * 0.6, v.z);
    const back = new THREE.Vector3(Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
    let dist = v.spec.cam + Math.min(2.5, Math.abs(v.speed) * 0.08);
    const end = pivot.clone().addScaledVector(back, dist);
    const t = col.raycast(pivot.x, pivot.z, end.x, end.z);
    if (t < 1) dist = Math.max(1.5, dist * t - 0.4);
    this.camDist += (dist - this.camDist) * Math.min(1, dt * (dist < this.camDist ? 16 : 3));
    const pos = pivot.clone().addScaledVector(back, this.camDist);
    pos.y = Math.max(pos.y, v.y + 0.8);
    this.shake = Math.max(0, (this.shake || 0) - dt * 2.5);
    if (this.shake) pos.add(new THREE.Vector3((Math.random() - 0.5) * this.shake * 0.3, (Math.random() - 0.5) * this.shake * 0.2, 0));
    cam.position.copy(pos);
    cam.lookAt(v.x + Math.sin(v.yaw) * 2.5, v.y + 1.1, v.z + Math.cos(v.yaw) * 2.5);
  }

  // ---------- volanti della polizia ----------
  _cops(dt, ctx) {
    const g = this.g, combat = g.combat(), P = g.player().pos;
    const stars = combat.stars();
    const want = this.current && stars > 0 ? Math.min(2, stars) : 0;
    // nuove volanti dietro l'angolo
    this.copT = (this.copT || 0) - dt;
    if (this.cops.length < want && this.copT <= 0) {
      this.copT = 6;
      const spot = this._roadSpot(P, 70, 140);
      if (spot) {
        const c = this._add(new Vehicle('polizia', '#25467f', spot[0], spot[1], Math.atan2(P.x - spot[0], P.z - spot[1])));
        c.stuck = 0; this.cops.push(c);
        g.toast('Una volante ti ha visto. Sirene.', true);
      }
    }
    let nearest = Infinity;
    for (const c of [...this.cops]) {
      const d = Math.hypot(c.x - P.x, c.z - P.z);
      // se non ti cercano più, se ne vanno
      // troppo lontana, o incastrata davvero: se ne va e ne arriva un'altra
      if ((!want && d > 60) || d > 260 || (c.revs || 0) >= 4) { this._remove(c); this.cops = this.cops.filter((q) => q !== c); if ((c.revs || 0) >= 4) this.copT = 1; continue; }
      nearest = Math.min(nearest, d);
      let thr = 0, st = 0;
      if (want) {
        // segue le strade: ricalcola il percorso ogni due secondi, punta dritto solo quando sei vicino
        c.pathT = (c.pathT || 0) - dt;
        if (c.pathT <= 0) { c.pathT = 2; c.path = this._route(c.x, c.z, P.x, P.z); if (c.path) c.path.push([P.x, P.z]); }
        let tx = P.x, tz = P.z;
        const clear = d < 35 && this._open(c.x, c.z, P.x, P.z);
        if (!clear && c.path && c.path.length > 1) {
          // inseguimento "pure pursuit": il punto della strada 6 m più avanti di dove si trova adesso
          const pp = c.path;
          let bi = 0, bd = Infinity, bt = 0;
          for (let i = 0; i < Math.min(pp.length - 1, 6); i++) {
            const a = pp[i], b = pp[i + 1], dx = b[0] - a[0], dz = b[1] - a[1], l2 = dx * dx + dz * dz || 1;
            const t = Math.max(0, Math.min(1, ((c.x - a[0]) * dx + (c.z - a[1]) * dz) / l2));
            const dd = Math.hypot(c.x - a[0] - dx * t, c.z - a[1] - dz * t);
            if (dd < bd) { bd = dd; bi = i; bt = t; }
          }
          if (bi > 0) pp.splice(0, bi);
          let left = 6 + Math.min(4, Math.abs(c.speed) * 0.3), i = 0, px = pp[0][0] + (pp[1][0] - pp[0][0]) * bt, pz = pp[0][1] + (pp[1][1] - pp[0][1]) * bt;
          tx = pp[1][0]; tz = pp[1][1];
          for (i = 1; i < pp.length; i++) {
            const L = Math.hypot(pp[i][0] - px, pp[i][1] - pz);
            if (L >= left) { tx = px + (pp[i][0] - px) * left / L; tz = pz + (pp[i][1] - pz) * left / L; break; }
            left -= L; px = pp[i][0]; pz = pp[i][1]; tx = px; tz = pz;
          }
        }
        const ang = wrap(Math.atan2(tx - c.x, tz - c.z) - c.yaw);
        st = Math.max(-1, Math.min(1, ang * 2.2));
        thr = d < 3.2 ? -0.3 : d < 9 ? 0.35 : Math.abs(ang) > 1.9 ? 0.35 : (Math.abs(c.speed) > 9 && Math.abs(ang) > 0.5 ? -0.3 : 1 - Math.min(0.5, Math.abs(ang) * 0.4));
        // incastrata: retromarcia con lo sterzo girato
        if (c.rev > 0) { c.rev -= dt; thr = -1; st = -st; }
        else if (c.stuck > 1.2) {
          c.stuck = 0; c.pathT = 0;
          // incastrata dove non la vedi: avanza lungo la strada fino al prossimo punto libero
          const pp = c.path, col = this.g.collision();
          let warped = false;
          if (pp && pp.length > 2 && d > 12 && !this._open(c.x, c.z, P.x, P.z)) {
            for (let i = Math.min(pp.length - 1, 5); i >= 1; i--) {
              const q = pp[i];
              if (col.isFree(q[0], q[1]) && Math.hypot(q[0] - P.x, q[1] - P.z) > 8) {
                const n = pp[Math.min(pp.length - 1, i + 1)];
                c.x = q[0]; c.z = q[1]; c.yaw = Math.atan2(n[0] - q[0], n[1] - q[1]) || c.yaw; c.speed = 5; pp.splice(0, i); warped = true; break;
              }
            }
          }
          if (!warped) { c.rev = 1.1; c.revs = (c.revs || 0) + 1; }
        }
      } else thr = 0.4;
      const r = this._step(c, dt, thr, st, false);
      c.stuck = Math.abs(c.speed) < 1 && thr > 0 ? c.stuck + dt : Math.max(0, c.stuck - dt * 0.5);
      void r;
      c.pose(dt, ctx.night, thr < 0, this.t);
      // fermato accanto alla volante: arresto
      const me = this.current;
      if (want && d < 6 && (!me || Math.abs(me.speed) < 1.5)) {
        c.catchT = (c.catchT || 0) + dt;
        if (c.catchT > 2.2) { c.catchT = 0; this.arrested(); }
      } else c.catchT = 0;
    }
    this.copDist = nearest;
  }

  arrested() {
    const v = this.current, g = this.g;
    if (v) { this.exit(true); if (v.stolen) { this._remove(v); g.toast('L\'auto rubata viene sequestrata.'); } }
    for (const c of this.cops) this._remove(c);
    this.cops = [];
    g.combat().onCaught();
  }

  // si può andare dritti da qui a lì? (niente muri, niente acqua, spazio per un'auto)
  _open(x0, z0, x1, z1) {
    const col = this.g.collision(), L = Math.hypot(x1 - x0, z1 - z0), n = Math.ceil(L / 2);
    for (let i = 1; i < n; i++) {
      const x = x0 + (x1 - x0) * i / n, z = z0 + (z1 - z0) * i / n;
      const [rx, rz, br] = col.resolve(x, z, 0.6);
      if (Math.hypot(rx - x, rz - z) > 0.05 || (!br && col.inWater(x, z))) return false;
    }
    return true;
  }

  // rete stradale per le volanti (contromano permesso: è la polizia)
  _graph() {
    if (this.graph) return this.graph;
    const nodes = [], index = new Map(), adj = [];
    const id = (p) => { const k = p[0].toFixed(1) + ',' + p[1].toFixed(1); let i = index.get(k); if (i === undefined) { i = nodes.length; index.set(k, i); nodes.push(p); adj.push([]); } return i; };
    for (const r of this.g.city().features.roads) {
      // le volanti entrano anche nelle zone pedonali (in centro storico sono quasi ovunque)
      if (r.width < 4.4 || r.kind === 'steps') continue;
      for (let i = 0; i < r.pts.length - 1; i++) {
        const a = id(r.pts[i]), b = id(r.pts[i + 1]);
        const w = Math.hypot(r.pts[i + 1][0] - r.pts[i][0], r.pts[i + 1][1] - r.pts[i][1]);
        adj[a].push([b, w]); adj[b].push([a, w]);
      }
    }
    return (this.graph = { nodes, adj });
  }
  _nearestNode(x, z) {
    const G = this._graph(); let best = -1, bd = Infinity;
    for (let i = 0; i < G.nodes.length; i++) { const p = G.nodes[i], d = (p[0] - x) ** 2 + (p[1] - z) ** 2; if (d < bd) { bd = d; best = i; } }
    return best;
  }
  _route(x0, z0, x1, z1) {
    const G = this._graph(); if (!G.nodes.length) return null;
    const s = this._nearestNode(x0, z0), t = this._nearestNode(x1, z1);
    if (s < 0 || t < 0) return null;
    const n = G.nodes.length, gS = new Float64Array(n).fill(Infinity), prev = new Int32Array(n).fill(-1), done = new Uint8Array(n);
    const open = [s]; gS[s] = 0;
    const H = (i) => Math.hypot(G.nodes[i][0] - G.nodes[t][0], G.nodes[i][1] - G.nodes[t][1]);
    let guard = 0;
    while (open.length && guard++ < 20000) {
      let bi = 0, bf = Infinity;
      for (let k = 0; k < open.length; k++) { const f = gS[open[k]] + H(open[k]); if (f < bf) { bf = f; bi = k; } }
      const u = open.splice(bi, 1)[0];
      if (u === t) break;
      if (done[u]) continue; done[u] = 1;
      for (const [v, w] of G.adj[u]) { const ng = gS[u] + w; if (ng < gS[v]) { gS[v] = ng; prev[v] = u; open.push(v); } }
    }
    if (prev[t] < 0 && s !== t) return null;
    const path = []; for (let i = t; i >= 0; i = prev[i]) { path.push(G.nodes[i]); if (i === s) break; }
    return path.reverse();
  }

  _roadSpot(P, r0, r1) {
    // tutti i punti delle strade larghe nell'anello giusto, poi uno a caso che sia libero
    const col = this.g.collision(), G = this._graph(), c = [];
    for (const p of G.nodes) { const d = Math.hypot(p[0] - P.x, p[1] - P.z); if (d > r0 && d < r1) c.push(p); }
    for (let k = 0; k < 30 && c.length; k++) { const p = c[Math.floor(Math.random() * c.length)]; if (col.isFree(p[0], p[1])) return p; }
    return null;
  }


  // per gli altri giocatori: che mezzo guidi (0 a piedi, 1 auto, 2 scooter, 3 volante)
  get netKind() { const v = this.current; return !v ? 0 : v.kind === 'scooter' ? 2 : 1; }
}
