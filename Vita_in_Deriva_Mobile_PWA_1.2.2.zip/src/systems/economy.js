// Soldi, energia, oggetti e negozi.

// articoli: prezzo in euro, energia restituita, effetto speciale
export const ITEMS = {
  caffe: { name: 'Caffè', price: 1.2, energy: 15, fx: 'caffeina', text: 'Al banco, in piedi, come si deve.' },
  cappuccino: { name: 'Cappuccino', price: 1.8, energy: 18, fx: 'caffeina', text: 'La schiuma sa di mattina, anche se è sera.' },
  cornetto: { name: 'Cornetto', price: 1.5, energy: 25, text: 'Ancora caldo. Le briciole finiscono ovunque.' },
  acqua: { name: 'Bottiglietta d\'acqua', price: 1.0, energy: 5, fx: 'acqua', text: 'Fresca. Ti schiarisce un po\' la testa.' },
  trancio: { name: 'Trancio di pizza', price: 3.5, energy: 45, text: 'Bordo croccante, mozzarella che fila.' },
  panino: { name: 'Panino al salame', price: 4.5, energy: 50, text: 'Michetta e salame, come una volta.' },
  focaccia: { name: 'Focaccia', price: 2.2, energy: 30, text: 'Unta al punto giusto.' },
  ambra: { name: 'Ambra', price: 5, energy: 0, fx: 'ambra', adult: true, text: 'Calda, un po\' amara.' },
  fumo: { name: 'Fumo Verde', price: 10, energy: -5, fx: 'fumo', adult: true, text: 'Il fumo sale lento. I colori si fanno più vicini.' },
  kokka: { name: 'Kokka', price: 30, energy: 20, fx: 'kokka', adult: true, text: 'Il cuore accelera. Tutto diventa nitido, troppo.' },
  lyn: { name: 'Lyn', price: 25, energy: -10, fx: 'lyn', adult: true, text: 'Dolce, viola. Il tempo comincia a colare.' },
  francobollo: { name: 'Francobollo', price: 20, energy: 0, fx: 'francobollo', adult: true, text: 'Sulla lingua non sa di niente. Per ora.' },
  giornale: { name: 'Giornale', price: 1.5, energy: 0, fx: 'giornale', text: '' },
  gratta: { name: 'Gratta e Vinci', price: 2, energy: 0, fx: 'gratta', text: '' },
  aspirina: { name: 'Aspirina', price: 4.2, energy: 5, fx: 'aspirina', text: 'Il mal di testa si allontana.' },
  vestiti: { name: 'Cambio d\'abito', price: 25, energy: 0, fx: 'vestiti', text: '' },
  tisana: { name: 'Tisana', price: 3, energy: 8, fx: 'calma', text: 'Camomilla e qualcosa che non riconosci.' }
};

export const SHOP_TYPES = {
  bar: { label: 'Bar', items: ['caffe', 'ambra', 'acqua', 'cornetto'], sign: ['#1f3a2c', '#f3e9d2'], greet: ['Cosa ti do?', 'Dimmi.', 'Ciao, il solito?'] },
  caffe: { label: 'Caffè', items: ['caffe', 'cappuccino', 'cornetto', 'acqua'], sign: ['#5a2b2b', '#f6e7c8'], greet: ['Buongiorno! Un caffè?', 'Prego, dimmi pure.'] },
  coffeeshop: { label: 'Coffee shop', items: ['fumo', 'tisana', 'acqua'], sign: ['#0f2a1c', '#8ff5b0'], neon: true, adult: true, greet: ['Tranquillo, siediti dove vuoi.', 'Prima volta qui? Va\' piano.'] },
  edicola: { label: 'Edicola', items: ['giornale', 'acqua'], sign: ['#1d2b4a', '#ffffff'], greet: ['Il giornale di oggi è appena arrivato.'] },
  forno: { label: 'Forno', items: ['focaccia', 'cornetto', 'panino'], sign: ['#e8d8b8', '#5a3a1a'], greet: ['Focaccia appena sfornata.'] },
  pizzeria: { label: 'Pizza', items: ['trancio', 'acqua'], sign: ['#8a1f1f', '#fff1c9'], greet: ['Margherita o patate?'] },
  tabacchi: { label: 'Tabacchi', items: ['gratta', 'acqua'], sign: ['#123a7a', '#ffffff'], tabacchi: true, greet: ['Gratta e Vinci? Oggi qualcuno ha vinto.'] },
  farmacia: { label: 'Farmacia', items: ['aspirina', 'acqua'], sign: ['#0f5a33', '#ffffff'], cross: true, greet: ['Buonasera, ha bisogno?'] },
  vestiti: { label: 'Vestiti', items: ['vestiti'], sign: ['#2a2230', '#f2b8c6'], greet: ['Prova pure, il camerino è lì.'] },
  archivio: { label: 'Archivio', items: [], sign: ['#3a2f22', '#e6c98a'], archivio: true, greet: ['Hai portato qualcosa che la città sta dimenticando?'] },
  alimentari: { label: 'Alimentari', items: ['panino', 'acqua', 'focaccia'], sign: ['#2c4a2c', '#ffffff'], greet: ['Prego.'] }
};

export function classifyShop(p) {
  const t = p.tags || {};
  if (t['vid:archivio']) return 'archivio';
  if (t['vid:coffeeshop']) return 'coffeeshop';
  const k = p.kind, s = t.shop;
  if (/^(bar|pub|biergarten|nightclub)$/.test(k)) return 'bar';
  if (k === 'cafe' || s === 'coffee' || s === 'pastry') return 'caffe';
  if (s === 'newsagent' || s === 'kiosk') return 'edicola';
  if (s === 'bakery') return 'forno';
  if ((k === 'fast_food' || k === 'restaurant') && /pizza/.test(t.cuisine || '')) return 'pizzeria';
  if (k === 'fast_food' || k === 'restaurant') return 'pizzeria';
  if (s === 'tobacco' || s === 'e-cigarette') return 'tabacchi';
  if (k === 'pharmacy' || s === 'chemist') return 'farmacia';
  if (s === 'clothes' || s === 'boutique' || s === 'second_hand' || s === 'shoes') return 'vestiti';
  if (s === 'supermarket' || s === 'convenience' || s === 'greengrocer') return 'alimentari';
  return null;
}

// prezzo che l'Archivio paga per una foto di anomalia
const TYPE_VALUE = [9, 7, 6, 11, 8];
export function photoValue(photo) {
  if (!photo || !photo.anomaly || photo.ruined || photo.sold) return 0;
  return Math.round(TYPE_VALUE[photo.firstType ?? 0] + (photo.anomalies || 1) * 2 + (photo.drift || 0.7) * 6);
}

// gratta e vinci: per lo più si perde, come nella realtà
export function scratch(rnd = Math.random) {
  const r = rnd();
  if (r < 0.6) return 0;
  if (r < 0.85) return 2;
  if (r < 0.95) return 5;
  if (r < 0.99) return 20;
  return 100;
}

export class Wallet {
  constructor(saved) {
    this.money = saved && Number.isFinite(saved.money) ? saved.money : 20;
    this.energy = saved && Number.isFinite(saved.energy) ? saved.energy : 80;
  }
  canPay(p) { return this.money + 1e-9 >= p; }
  pay(p) { if (!this.canPay(p)) return false; this.money = Math.round((this.money - p) * 100) / 100; return true; }
  earn(p) { this.money = Math.round((this.money + p) * 100) / 100; }
  // l'energia cala camminando, di più correndo; sotto il 20% non si corre
  update(dt, speed, running) {
    const drain = 0.012 + (speed > 0.5 ? 0.025 : 0) + (running ? 0.06 : 0);
    this.energy = Math.max(0, Math.min(100, this.energy - drain * dt));
  }
  eat(e) { this.energy = Math.max(0, Math.min(100, this.energy + e)); }
  toJSON() { return { money: this.money, energy: this.energy }; }
}

export const euro = (v) => v.toLocaleString('it-IT', { style: 'currency', currency: 'EUR' });
