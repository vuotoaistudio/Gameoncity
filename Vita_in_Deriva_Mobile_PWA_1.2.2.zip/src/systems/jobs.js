// Lavori: legali (rider, volantini, taxi) e illeciti (pacchi per i vicoli, auto rubate su commissione).
// Ogni lavoro ha tappe con un punto sulla mappa; i soldi arrivano a fine lavoro.
import { euro } from './economy.js';

const rand = (a, b) => a + Math.random() * (b - a);
const fmtT = (s) => `${Math.floor(Math.max(0, s) / 60)}:${String(Math.floor(Math.max(0, s) % 60)).padStart(2, '0')}`;
const COLOR_NAME = { '#8f1d1d': 'rossa scura', '#e7e4dc': 'bianca', '#22252b': 'nera', '#5b6d78': 'grigio azzurro', '#7d7d78': 'grigia', '#1f3550': 'blu', '#c9b27b': 'color sabbia', '#3e5b45': 'verde', '#b8b8b2': 'argento', '#5a2b33': 'bordeaux', '#f2f0ea': 'bianco latte', '#2c2c2e': 'antracite' };
const FOOD = ['due margherite', 'un tagliere di salumi', 'lampredotto e una birra', 'sushi per quattro', 'una schiacciata farcita', 'pappa al pomodoro', 'una bistecca da asporto', 'tre cappuccini e cornetti'];

export class Jobs {
  // g: { features, shops(), crowd(), collision(), driving(), wallet(), toast, audio, combat(), player(), night(), save(), avatar(), parked(), stats() }
  constructor(g) {
    this.g = g;
    this.active = null; this.offers = []; this.refreshT = 0;
    this.done = { legal: 0, illegal: 0, earned: 0 };
    const F = g.features;
    // mete per il taxi: monumenti e piazze con un nome
    const area = (r) => { let a = 0; for (let i = 0; i < r.length; i++) { const p = r[i], q = r[(i + 1) % r.length]; a += p[0] * q[1] - q[0] * p[1]; } return Math.abs(a / 2); };
    const cen = (r) => { let x = 0, z = 0; for (const p of r) { x += p[0]; z += p[1]; } return [x / r.length, z / r.length]; };
    this.landmarks = [];
    for (const b of [...F.buildings, ...(F.outlines || [])]) {
      const n = b.tags && b.tags.name;
      if (!n || !/Palazzo|Basilica|Chiesa|Duomo|Cattedrale|Museo|Galleria|Battistero|Loggia|Teatro|Stazione|Mercato|Biblioteca|Darsena|Torre/i.test(n) || area(b.outer) < 250) continue;
      const c = cen(b.outer), p = g.collision().nearestFree(c[0], c[1], 60);
      if (p && !this.landmarks.some((l) => l.name === n)) this.landmarks.push({ name: n, x: p[0], z: p[1] });
    }
    for (const p of F.plazas) if (p.name) { const c = cen(p.outer), q = g.collision().nearestFree(c[0], c[1], 30); if (q) this.landmarks.push({ name: p.name, x: q[0], z: q[1] }); }
    // l'officina di Sergio: in fondo a una strada di servizio lontana dal centro
    let best = null;
    for (const r of F.roads) {
      if (r.kind !== 'service' && r.kind !== 'residential') continue;
      const p = r.pts[r.pts.length - 1], d = Math.hypot(p[0], p[1]);
      if (d < 350 || d > 900 || !g.collision().isFree(p[0], p[1])) continue;
      const score = (r.kind === 'service' ? 200 : 0) - Math.abs(d - 550);
      if (!best || score > best.score) best = { score, x: p[0], z: p[1] };
    }
    this.garage = best ? { x: best.x, z: best.z, label: 'Officina di Sergio' } : null;
  }

  load(s) { if (s) Object.assign(this.done, s); }
  toJSON() { return this.done; }

  // ---------- luoghi ----------
  _door(P, r0, r1) {
    const B = this.g.features.buildings, col = this.g.collision();
    for (let k = 0; k < 80; k++) {
      const b = B[Math.floor(Math.random() * B.length)];
      if (b.minHeight > 1 || b.tags.name) continue;
      const i = Math.floor(Math.random() * b.outer.length), a = b.outer[i], c = b.outer[(i + 1) % b.outer.length];
      const L = Math.hypot(c[0] - a[0], c[1] - a[1]); if (L < 4) continue;
      const mx = (a[0] + c[0]) / 2, mz = (a[1] + c[1]) / 2;
      for (const s of [1, -1]) {
        const x = mx + s * (c[1] - a[1]) / L * 1.3, z = mz - s * (c[0] - a[0]) / L * 1.3;
        const d = Math.hypot(x - P.x, z - P.z);
        if (d >= r0 && d <= r1 && col.isFree(x, z)) return { x, z, addr: (b.tags['addr:street'] ? b.tags['addr:street'] + ' ' + (b.tags['addr:housenumber'] || '') : this._street(x, z)) };
      }
    }
    return null;
  }
  _street(x, z) {
    let best = 'una via senza nome', bd = 40;
    for (const r of this.g.features.roads) { if (!r.name) continue; for (const p of r.pts) { const d = Math.hypot(p[0] - x, p[1] - z); if (d < bd) { bd = d; best = r.name; } } }
    return best;
  }

  // ---------- offerte ----------
  _make(kind, P) {
    const g = this.g, night = g.night() > 0.5;
    if (kind === 'rider') {
      const shops = g.shops().shops.filter((s) => /pizzeria|forno|caffe|alimentari/.test(s.type));
      const s = shops.sort((a, b) => Math.hypot(a.x - P.x, a.z - P.z) - Math.hypot(b.x - P.x, b.z - P.z))[Math.floor(Math.random() * Math.min(6, shops.length))];
      const to = s && this._door({ x: s.x, z: s.z }, 150, 650);
      if (!s || !to) return null;
      const d = Math.hypot(to.x - s.x, to.z - s.z);
      return { kind, legal: true, title: 'Consegna a domicilio', who: 'App Pedala', pay: +(4 + d * 0.011).toFixed(2), food: FOOD[Math.floor(Math.random() * FOOD.length)], from: { x: s.doorX + s.nx * 1.2, z: s.doorZ + s.nz * 1.2, label: s.name }, to: { x: to.x, z: to.z, label: to.addr }, time: Math.round(d / 2.6 + 70), text: `Ritira da ${s.name}, consegna in ${to.addr}.` };
    }
    if (kind === 'volantini') {
      const stops = []; let at = P;
      for (let i = 0; i < 4; i++) { const d = this._door(at, 40, 160); if (!d) break; stops.push({ x: d.x, z: d.z, label: d.addr }); at = d; }
      if (stops.length < 3) return null;
      return { kind, legal: true, title: 'Volantini del ristorante', who: 'Trattoria da Gino', pay: 6 + stops.length * 2.5, stops, text: `Lascia i volantini in ${stops.length} portoni qui intorno.` };
    }
    if (kind === 'taxi') {
      const from = this._door(P, 60, 260), L = this.landmarks;
      if (!from || !L.length) return null;
      const far = L.filter((l) => Math.hypot(l.x - from.x, l.z - from.z) > 300);
      const dest = far.length ? far[Math.floor(Math.random() * far.length)] : L[Math.floor(Math.random() * L.length)];
      const d = Math.hypot(dest.x - from.x, dest.z - from.z);
      return { kind, legal: true, title: 'Corsa NCC', who: 'App Autisti', needsCar: true, pay: +(7 + d * 0.016).toFixed(2), from: { x: from.x, z: from.z, label: 'Cliente in ' + from.addr }, to: { x: dest.x, z: dest.z, label: dest.name }, text: `Un cliente in ${from.addr} vuole andare a ${dest.name}. Serve un'auto.` };
    }
    if (kind === 'pacco') {
      const pushers = g.crowd().npcs.filter((n) => n.role === 'pusher' && n.root.visible);
      const src = pushers.sort((a, b) => Math.hypot(a.x - P.x, a.z - P.z) - Math.hypot(b.x - P.x, b.z - P.z))[0];
      const fromP = src ? { x: src.x, z: src.z } : this._door(P, 80, 250);
      const to = fromP && this._door(fromP, 300, 750);
      if (!fromP || !to) return null;
      const d = Math.hypot(to.x - fromP.x, to.z - fromP.z);
      return { kind, legal: false, title: 'Un pacco da portare', who: 'Il Biondo', pay: Math.round((45 + d * 0.13) * (night ? 1.3 : 1)), from: { x: fromP.x, z: fromP.z, label: 'Il tipo col cappuccio' }, to: { x: to.x, z: to.z, label: to.addr }, time: Math.round(d / 2.4 + 90), text: `Ritira un pacco nel vicolo e portalo in ${to.addr}. Non farti fermare: se un vigile lo vede, sono guai.` };
    }
    if (kind === 'furto') {
      const pk = g.parked(); if (!pk || !this.garage) return null;
      const drv = g.driving();
      const cands = pk.cars.map((c, i) => ({ c, i })).filter(({ c, i }) => !drv.stolenParked.has(i) && Math.hypot(c.x - P.x, c.z - P.z) > 150 && Math.hypot(c.x - P.x, c.z - P.z) < 650);
      if (!cands.length) return null;
      const t = cands[Math.floor(Math.random() * cands.length)];
      const col = COLOR_NAME[t.c.color] || 'scura';
      const hint = { x: t.c.x + rand(-30, 30), z: t.c.z + rand(-30, 30) };
      return { kind, legal: false, title: 'Auto su commissione', who: 'Sergio', pay: Math.round(rand(180, 340)), carIndex: t.i, color: col, area: { x: hint.x, z: hint.z, label: `Utilitaria ${col}` }, to: this.garage, text: `Mi serve un'utilitaria ${col}, parcheggiata dalle parti di ${this._street(t.c.x, t.c.z)}. Portamela in officina senza graffi.` };
    }
    return null;
  }

  refreshOffers(force) {
    const P = this.g.player().pos;
    if (!force && this.offers.length >= 4 && this.refreshT > 0) return;
    this.refreshT = 150;
    const kinds = ['rider', 'rider', 'volantini', 'taxi', 'pacco', 'furto'];
    this.offers = [];
    for (const k of kinds) { const o = this._make(k, P); if (o) this.offers.push(o); }
  }

  accept(o) {
    if (this.active) return false;
    this.offers = this.offers.filter((q) => q !== o);
    const a = this.active = Object.assign({ stage: 0, t: 0, crashes: 0 }, o);
    if (o.kind === 'taxi') {
      const n = this.g.crowd()._static('turista', o.from.x, o.from.z, 0, { name: 'Cliente', job: true });
      a.client = n;
    }
    if (o.kind === 'volantini') { a.left = o.stops.slice(); }
    this.g.toast(`Lavoro accettato: <em>${o.title}</em>. ${o.legal ? '' : 'Occhio alla polizia.'}`);
    return true;
  }

  cancel(why) {
    const a = this.active; if (!a) return;
    if (a.client) this.g.crowd().remove(a.client);
    this.active = null;
    this.g.toast(why || 'Lavoro annullato.');
  }

  _pay(v, extra) {
    const g = this.g, a = this.active;
    g.wallet().earn(v);
    this.done.earned = +(this.done.earned + v).toFixed(2);
    this.done[a.legal ? 'legal' : 'illegal']++;
    g.audio.cash();
    g.toast(`${a.title}: <em>+${euro(v)}</em>${extra ? ' · ' + extra : ''}`);
    this.active = null;
    g.save();
  }

  // dove andare adesso (per freccia, minimappa e scheda obiettivo)
  target() {
    const a = this.active; if (!a) return null;
    if (a.kind === 'volantini') return a.left[0];
    if (a.kind === 'furto') return a.stage === 0 ? (a.exact || a.area) : a.to;
    return a.stage === 0 ? a.from : a.to;
  }
  objective() {
    const a = this.active; if (!a) return null;
    const clock = a.deadline ? ` · ${fmtT(a.deadline - a.t)}` : '';
    if (a.kind === 'rider') return a.stage === 0 ? `Ritira ${a.food} da ${a.from.label}` : `Consegna ${a.food} in ${a.to.label}${clock}`;
    if (a.kind === 'volantini') return `Volantini: ${a.stops.length - a.left.length}/${a.stops.length} · prossimo portone in ${a.left[0].label}`;
    if (a.kind === 'taxi') return a.stage === 0 ? 'Vai a prendere il cliente (in auto) e fermati accanto' : `Porta il cliente a ${a.to.label}`;
    if (a.kind === 'pacco') return a.stage === 0 ? 'Ritira il pacco dal tipo col cappuccio' : `Consegna il pacco in ${a.to.label}${clock}`;
    if (a.kind === 'furto') return a.stage === 0 ? `Trova e ruba l'utilitaria ${a.color} (E sulla portiera)` : 'Porta l\'auto all\'officina di Sergio';
    return '';
  }

  update(dt) {
    const g = this.g;
    this.refreshT -= dt;
    const a = this.active; if (!a) return;
    a.t += dt;
    const P = g.player().pos, drv = g.driving(), car = drv.current;
    const speed = car ? Math.abs(car.speed) : 0;
    const T = this.target(); if (!T) return;
    const d = Math.hypot(T.x - P.x, T.z - P.z);
    const arrive = d < (car ? 7 : 3) && speed < 2.2;
    if (a.deadline && a.t > a.deadline && !a.late) { a.late = true; g.toast(a.legal ? 'Sei in ritardo: niente mancia.' : 'Sei in ritardo. Il Biondo non sarà contento.', true); }
    if (car && drv.lastCrash && drv.lastCrash !== a.lastCrashSeen) { a.lastCrashSeen = drv.lastCrash; a.crashes++; }

    if (a.kind === 'rider') {
      if (arrive && a.stage === 0) { a.stage = 1; a.t = 0; a.deadline = a.time; g.avatar().gesture('take', 0.8); g.toast(`Ritirato: ${a.food}. Hai ${fmtT(a.time)} per consegnare.`); }
      else if (arrive && a.stage === 1) { const tip = a.late ? 0 : Math.round(rand(0, 4) * (1 - a.t / a.deadline) * 2) / 2; g.avatar().gesture('give', 0.8); this._pay(+(a.pay * (a.late ? 0.6 : 1) + tip).toFixed(2), tip ? `mancia ${euro(tip)}` : ''); }
    } else if (a.kind === 'volantini') {
      if (arrive) { a.left.shift(); g.avatar().gesture('give', 0.6); g.audio.rustle(); if (!a.left.length) this._pay(a.pay); }
    } else if (a.kind === 'taxi') {
      if (a.stage === 0 && d < 7 && car && car.kind === 'auto' && speed < 2) {
        a.stage = 1; if (a.client) { g.crowd().remove(a.client); a.client = null; }
        g.toast(`Il cliente sale: «A ${a.to.label}, per favore. Con calma.»`); a.crashes = 0;
      } else if (a.stage === 0 && d < 5 && !car) g.toast('Il cliente ti guarda: «Ma la macchina?»');
      else if (a.stage === 1 && !car) { this.cancel('Sei sceso dall\'auto: il cliente se ne va senza pagare.'); }
      else if (a.stage === 1 && arrive) { const cut = Math.min(0.8, a.crashes * 0.2); this._pay(+(a.pay * (1 - cut)).toFixed(2), a.crashes ? `${a.crashes} botte, il cliente toglie la mancia` : 'cliente soddisfatto'); }
    } else if (a.kind === 'pacco') {
      if (arrive && a.stage === 0) { a.stage = 1; a.t = 0; a.deadline = a.time; g.avatar().gesture('take', 0.8); g.toast('Hai il pacco. Pesa più di quanto sembri. Non aprirlo.'); }
      else if (a.stage === 1) {
        // vigili e volanti: se ti vedono col pacco, scatta l'inseguimento
        this.copT = (this.copT || 0) - dt;
        if (this.copT <= 0) {
          this.copT = 1;
          const near = g.crowd().police.some((n) => Math.hypot(n.x - P.x, n.z - P.z) < 16) || drv.cops.some((c) => Math.hypot(c.x - P.x, c.z - P.z) < 22);
          if (near && !a.spotted && Math.random() < 0.45) { a.spotted = true; g.combat().crime(1.2, 'Pacco sospetto'); g.toast('Un agente ha visto il pacco. Scappa!', true); }
          // ogni tanto passa una pattuglia a piedi a controllare
          if (!a.patrolled && a.t > 25 && Math.random() < 0.02) { a.patrolled = true; g.crowd().spawnPolice(P); }
        }
        if (arrive) { const v = a.late ? Math.round(a.pay * 0.4) : a.pay; g.avatar().gesture('give', 0.8); this._pay(v, a.late ? 'in ritardo, paga dimezzata' : 'nessuna domanda'); }
      }
    } else if (a.kind === 'furto') {
      const pk = g.parked(), c = pk.cars[a.carIndex];
      if (a.stage === 0) {
        if (!a.exact && c && Math.hypot(c.x - P.x, c.z - P.z) < 45) { a.exact = { x: c.x, z: c.z, label: `Utilitaria ${a.color}` }; g.toast(`Eccola: l'utilitaria ${a.color}.`); }
        if (car && car.parkedIndex === a.carIndex) { a.stage = 1; g.toast('Ce l\'hai. Ora all\'officina, senza farti seguire.'); }
        else if (drv.stolenParked.has(a.carIndex) && !(car && car.parkedIndex === a.carIndex)) { /* rubata e lasciata: si può riprendere */ }
      } else if (a.stage === 1) {
        if (arrive && car && car.parkedIndex === a.carIndex) {
          const cut = Math.min(0.6, a.crashes * 0.1);
          drv.exit(true); drv._remove(car);
          this._pay(Math.round(a.pay * (1 - cut)), g.combat().stars() ? 'Sergio chiude la saracinesca in fretta' : 'Sergio la porta dentro');
        }
      }
    }
  }
}
