// I testi della storia sono nati sui Navigli: in un'altra città i luoghi cambiano nome.
// Le sostituzioni vanno dalla più specifica alla più generica.
const RULES = {
  'firenze-centro': [
    [/murato quando il canale è stato coperto/g, 'murato dopo l\'alluvione del sessantasei'],
    [/Stanotte\. Darsena\./g, 'Stanotte. Piazza del Duomo.'],
    [/Di notte, alla Darsena: cerca una porta sul campanile/g, 'Di notte, in Piazza del Duomo: cerca una porta sul campanile'],
    [/aspetta la notte alla Darsena/g, 'aspetta la notte sul Ponte Vecchio'],
    [/Aldo alla Darsena/g, 'Aldo sull\'Arno'],
    [/sulla riva della Darsena/g, 'sulla spalletta dell\'Arno'],
    [/Notturno, Darsena/g, 'Notturno, Santa Maria Novella'],
    [/Cartolina della Darsena/g, 'Cartolina del Ponte Vecchio'],
    [/Scusi, la Darsena è di qua\?/g, 'Scusi, il Ponte Vecchio è di qua?'],
    [/Darsena, il campanile di notte/g, 'Piazza del Duomo, il campanile di notte'],
    [/Santa Maria della Nebbia/g, 'Santa Maria del Fiore'],
    [/alla Darsena/g, 'sull\'Arno'], [/della Darsena/g, 'dell\'Arno'], [/la Darsena/g, 'l\'Arno'], [/Darsena/g, 'Arno'],
    [/is this the real Naviglio\?/g, 'is this the real Ponte Vecchio?'],
    [/quando i Navigli erano tutti aperti/g, 'quando l\'Arno è uscito, nel sessantasei'],
    [/residenti dei Navigli/g, 'residenti di Santo Spirito'],
    [/Navigli/g, 'lungarni'], [/Naviglio/g, 'Arno'],
    [/sull'alzaia/gi, 'sul Lungarno'], [/dell'alzaia/gi, 'del Lungarno'], [/l'alzaia/gi, 'il Lungarno'], [/alzaia/gi, 'Lungarno'],
    [/lungo il canale/g, 'lungo l\'Arno'], [/sul canale/g, 'sull\'Arno'], [/nel canale/g, 'nell\'Arno'],
    [/Il canale/g, 'L\'Arno'], [/il canale/g, 'l\'Arno'], [/canale/g, 'fiume'],
    [/Il tram nove passava/g, 'Il ventitré passava'],
    [/casa di ringhiera/g, 'casa con le persiane verdi'],
    [/Gazzetta delle Conche/g, 'Gazzetta del Lungarno']
  ]
};

let rules = null;
export function setCity(id) { rules = RULES[id] || null; }
export function loc(text) {
  if (!rules || typeof text !== 'string') return text;
  let t = text;
  for (const [re, to] of rules) t = t.replace(re, to);
  return t;
}

// tutto ciò che compare a schermo passa di qui: i testi già scritti e quelli che arrivano dopo
export function watchDom(root) {
  if (!rules) return;
  const fix = (node) => {
    if (node.nodeType === 3) { const t = loc(node.nodeValue); if (t !== node.nodeValue) node.nodeValue = t; return; }
    if (node.nodeType !== 1 || node.tagName === 'SCRIPT' || node.tagName === 'STYLE' || node.tagName === 'INPUT') return;
    for (const c of node.childNodes) fix(c);
  };
  fix(root);
  new MutationObserver((list) => {
    for (const m of list) {
      if (m.type === 'characterData') fix(m.target);
      else for (const n of m.addedNodes) fix(n);
    }
  }).observe(root, { childList: true, subtree: true, characterData: true });
}
