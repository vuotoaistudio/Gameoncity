// Case in vendita nei palazzi veri: cartello VENDESI sulla facciata, indirizzo reale, piano, metri quadri.
// Una casa si abita (si dorme, ci si risveglia) oppure si affitta e rende finché giochi.
import * as THREE from 'three';
import { signedArea } from '../world/osm.js';

const hash = (n) => { n = (n ^ 61) ^ (n >>> 16); n = n + (n << 3); n = n ^ (n >>> 4); n = Math.imul(n, 0x27d4eb2d); n = n ^ (n >>> 15); return (n >>> 0) / 4294967296; };
const OK_KIND = /^(apartments|residential|yes|house|terrace|detached|semidetached_house)$/;

function plate(text, bg, fg, sub) {
  const c = document.createElement('canvas'); c.width = 256; c.height = 160;
  const g = c.getContext('2d');
  g.fillStyle = bg; g.fillRect(0, 0, 256, 160);
  g.strokeStyle = fg; g.lineWidth = 8; g.strokeRect(8, 8, 240, 144);
  g.fillStyle = fg; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.font = '800 54px "Karla", "Arial Black", sans-serif'; g.fillText(text, 128, 66);
  if (sub) { g.font = '600 22px "IBM Plex Mono", monospace'; g.fillText(sub, 128, 118); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  return new THREE.MeshStandardMaterial({ map: t, roughness: 0.6, side: THREE.DoubleSide });
}

export class RealEstate {
  constructor(features, collision, scene, opts = {}) {
    this.col = collision; this.scene = scene;
    this.owned = {};             // id -> { mode: 'casa' | 'affitto', since }
    this.rentAcc = 0; this.rentT = 0;
    const perM2 = opts.perM2 || 36;
    const roads = features.roads.filter((r) => r.name);
    const nearestRoad = (x, z) => {
      let best = null, bd = 60;
      for (const r of roads) for (let i = 0; i < r.pts.length - 1; i++) {
        const a = r.pts[i], b = r.pts[i + 1], dx = b[0] - a[0], dz = b[1] - a[1], l2 = dx * dx + dz * dz || 1;
        const t = Math.max(0, Math.min(1, ((x - a[0]) * dx + (z - a[1]) * dz) / l2));
        const d = Math.hypot(x - a[0] - dx * t, z - a[1] - dz * t);
        if (d < bd) { bd = d; best = r.name; }
      }
      return best;
    };
    const cands = [];
    for (const b of features.buildings) {
      const t = b.tags;
      if (t['building:part'] || t.name || b.minHeight > 1 || !OK_KIND.test(t.building || '')) continue;
      const area = Math.abs(signedArea(b.outer));
      if (area < 70 || area > 1600 || b.height < 7) continue;
      const h = hash(b.id % 2147483647);
      if (h > 0.09) continue;
      cands.push({ b, area, h });
    }
    cands.sort((a, b) => a.h - b.h);
    this.list = [];
    for (const { b, area, h } of cands) {
      if (this.list.length >= 70) break;
      // la porta: il lato più lungo che dà su uno spazio libero
      const ccw = signedArea(b.outer) > 0;
      let door = null;
      for (let i = 0; i < b.outer.length; i++) {
        const a = b.outer[i], c = b.outer[(i + 1) % b.outer.length], L = Math.hypot(c[0] - a[0], c[1] - a[1]);
        if (L < 4) continue;
        const nx = (ccw ? 1 : -1) * (c[1] - a[1]) / L, nz = (ccw ? -1 : 1) * (c[0] - a[0]) / L;
        const mx = (a[0] + c[0]) / 2, mz = (a[1] + c[1]) / 2;
        if (!collision.isFree(mx + nx * 1.4, mz + nz * 1.4)) continue;
        if (!door || L > door.L) door = { L, x: mx + nx * 1.1, z: mz + nz * 1.1, wx: mx + nx * 0.04, wz: mz + nz * 0.04, nx, nz };
      }
      if (!door) continue;
      const levels = Math.max(2, b.levels);
      const whole = area < 160 && levels <= 3 && h < 0.012;
      const floor = whole ? 0 : 1 + Math.floor(hash(b.id + 7) * (levels - 1));
      const top = !whole && floor >= levels - 1 && hash(b.id + 3) > 0.5;
      const size = whole ? Math.round(area * levels * 0.8) : Math.max(28, Math.min(160, Math.round(area * (0.18 + hash(b.id + 11) * 0.35))));
      const kind = whole ? 'Palazzina intera' : top ? 'Attico' : size < 45 ? 'Monolocale' : size < 70 ? 'Bilocale' : size < 100 ? 'Trilocale' : 'Quadrilocale';
      const price = Math.round(size * perM2 * (top ? 1.35 : 1) * (0.85 + hash(b.id + 5) * 0.3) / 50) * 50;
      const t = b.tags;
      const street = t['addr:street'] || nearestRoad(door.x, door.z) || 'Via senza nome';
      const num = t['addr:housenumber'] || String(1 + Math.floor(hash(b.id + 13) * 60));
      this.list.push({ id: String(b.id), bid: b.bid, kind, size, floor, levels, price, rent: +(price * 0.0025).toFixed(2), address: `${street} ${num}`, door, top });
    }
    // cartelli
    this.mats = { vendesi: plate('VENDESI', '#ffffff', '#c0202a', 'tel. 055 ···'), casa: plate('CASA TUA', '#1d3b2c', '#e9e1c8', ''), affitto: plate('AFFITTATO', '#f2efe6', '#1d3b5a', '') };
    this.signGeo = new THREE.PlaneGeometry(0.62, 0.39);
    this.group = new THREE.Group(); scene.add(this.group);
    for (const L of this.list) {
      const m = new THREE.Mesh(this.signGeo, this.mats.vendesi);
      m.position.set(L.door.wx, 2.55, L.door.wz); m.rotation.y = Math.atan2(L.door.nx, L.door.nz);
      this.group.add(m); L.sign = m;
    }
  }

  load(saved) {
    this.owned = {};
    for (const [id, o] of Object.entries(saved || {})) if (this.list.some((L) => L.id === id)) this.owned[id] = { mode: o.mode === 'affitto' ? 'affitto' : 'casa', since: o.since || Date.now() };
    this.refreshSigns();
  }
  toJSON() { return this.owned; }
  refreshSigns() { for (const L of this.list) { const o = this.owned[L.id]; L.sign.material = o ? this.mats[o.mode] : this.mats.vendesi; } }

  get home() { const L = this.list.find((q) => this.owned[q.id] && this.owned[q.id].mode === 'casa'); return L || null; }
  near(P, r = 2.8) { let best = null, bd = r; for (const L of this.list) { const d = Math.hypot(L.door.x - P.x, L.door.z - P.z); if (d < bd) { bd = d; best = L; } } return best; }
  nearestForSale(P) { let best = null, bd = Infinity; for (const L of this.list) { if (this.owned[L.id]) continue; const d = Math.hypot(L.door.x - P.x, L.door.z - P.z); if (d < bd) { bd = d; best = L; } } return best; }

  buy(L, wallet) { if (this.owned[L.id] || !wallet.pay(L.price)) return false; this.owned[L.id] = { mode: this.home ? 'affitto' : 'casa', since: Date.now() }; this.refreshSigns(); return true; }
  sell(L, wallet) { if (!this.owned[L.id]) return 0; const v = Math.round(L.price * 0.85); delete this.owned[L.id]; wallet.earn(v); this.refreshSigns(); return v; }
  setMode(L, mode) {
    if (!this.owned[L.id]) return;
    if (mode === 'casa') for (const o of Object.values(this.owned)) if (o.mode === 'casa') o.mode = 'affitto';
    this.owned[L.id].mode = mode; this.refreshSigns();
  }
  get rentPerMin() { let r = 0; for (const L of this.list) if (this.owned[L.id] && this.owned[L.id].mode === 'affitto') r += L.rent; return r; }

  // gli affitti maturano mentre giochi e arrivano sul conto ogni due minuti
  update(dt, wallet, notify) {
    const r = this.rentPerMin;
    if (!r) return;
    this.rentAcc += r * dt / 60;
    this.rentT += dt;
    if (this.rentT >= 120 && this.rentAcc >= 0.01) { const v = Math.round(this.rentAcc * 100) / 100; wallet.earn(v); notify(v); this.rentAcc = 0; this.rentT = 0; }
  }
}
