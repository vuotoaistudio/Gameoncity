// La storia: Nora, amica d'infanzia, è scomparsa dentro la deriva della città.
// Capitoli con obiettivi chiari, messaggi sul telefono, i suoi sette ricordi, due finali.

export const NORA_RICORDI = [
  ['Il suo braccialetto di lana', 'Rosso e blu, mezzo sfilacciato. Lo porta dalla quinta elementare. Dentro c\'è un nodo che hai fatto tu.'],
  ['Una foto del cortile', 'Voi due a nove anni, sui ballatoi. Dietro, scritto da lei: «quando diventiamo grandi andiamo via». Lei però non è andata da nessuna parte.'],
  ['Il grembiule del bar', 'Ha ancora la spilla col suo nome. In tasca, uno scontrino: «le porte si aprono solo dove nessuno guarda».'],
  ['Un quaderno di disegni', 'Pagine e pagine di facciate. Su ognuna ha cerchiato un piano che nella realtà non esiste.'],
  ['Un messaggio vocale', 'Non si sente quasi niente. Solo il canale, e alla fine la sua voce: «se mi cerchi, aspetta la notte alla Darsena».'],
  ['Le chiavi di casa sua', 'La porta che aprivano, in via delle Gru, oggi è un muro intonacato. La targhetta del campanello è bianca.'],
  ['Un biglietto per l\'ultimo tram', 'Notturno, Darsena. Data di stanotte. Non c\'è il nome del passeggero, ma la calligrafia è la tua.']
];

export const CHAPTERS = [
  { id: 'messaggio', title: 'Il messaggio', obj: 'Vai al Bar Ringhiera e chiedi di Nora a Marta, la barista', hint: 'Il Bar Ringhiera è sull\'alzaia. Apri la mappa sul telefono (tasto P).' },
  { id: 'porte', title: 'Le porte', obj: 'Trova una porta che prima non c\'era ed entra a cercare un ricordo di Nora', hint: 'Le porte compaiono sui palazzi che nessuno guarda da un po\'. Gira, poi torna indietro.' },
  { id: 'archivio', title: 'L\'Archivio', obj: 'Porta all\'Archivio la foto di un\'anomalia', hint: 'Fotografa un palazzo che è cambiato (F, poi clic), poi vai all\'Archivio.' },
  { id: 'chiricorda', title: 'Chi ricorda', obj: 'Trova chi ricorda Nora: Aldo alla Darsena, Teo sul ponte, il Biondo di sera', hint: 'Aldo siede sulla riva della Darsena. Teo suona su un ponte. Il Biondo esce solo quando fa buio.' },
  { id: 'sette', title: 'Sette ricordi', obj: 'Raccogli i ricordi di Nora nelle porte del sogno', hint: 'Ogni porta custodisce un ricordo. Più la città è alla deriva, più porte si aprono.' },
  { id: 'ultima', title: 'L\'ultima porta', obj: 'Di notte, alla Darsena: cerca una porta sul campanile', hint: 'Se non vuoi aspettare la notte vera, puoi cambiare l\'ora nelle impostazioni.' },
  { id: 'fine', title: 'Dopo', obj: 'La città è tua. Continua a camminare.', hint: '' }
];

export class Story {
  constructor(saved) {
    const s = saved || {};
    this.chapter = s.chapter || 0;
    this.noraFound = s.noraFound || 0;     // ricordi di Nora trovati
    this.met = s.met || {};                 // persone che ricordano Nora
    this.messages = s.messages || [];
    this.ending = s.ending || null;
    this.flags = s.flags || {};
    this.listeners = [];
    if (!this.messages.length) this.message('Nora', 'So che è strano scriverti dopo tanto. Se non mi trovi, cerca le porte. Chiedi a Marta, al Bar Ringhiera. Non preoccuparti per me. — N.');
  }
  on(fn) { this.listeners.push(fn); }
  emit(ev, data) { for (const f of this.listeners) f(ev, data); }
  get current() { return CHAPTERS[Math.min(this.chapter, CHAPTERS.length - 1)]; }
  objective() {
    const c = this.current;
    if (c.id === 'chiricorda') return `${c.obj} (${Object.keys(this.met).length}/3)`;
    if (c.id === 'sette') return `${c.obj} (${this.noraFound}/7)`;
    return c.obj;
  }
  message(from, text) {
    const m = { from, text, at: new Date().toISOString(), read: false };
    this.messages.unshift(m);
    this.emit('message', m);
  }
  advance() {
    if (this.chapter >= CHAPTERS.length - 1) return;
    this.chapter++;
    this.emit('chapter', this.current);
  }

  // il prossimo ricordo da mettere in una porta: prima quelli di Nora, poi quelli della città
  nextRicordo() {
    if (this.chapter >= 1 && this.noraFound < NORA_RICORDI.length) return { nora: true, index: this.noraFound, r: NORA_RICORDI[this.noraFound] };
    return null;
  }
  foundRicordo(isNora) {
    if (isNora) this.noraFound++;
    if (this.current.id === 'porte' && isNora) {
      this.advance();
      this.message('Numero sconosciuto', 'L\'Archivio compra le foto di ciò che la città dimentica. Chiedi del signor Ferri. Porta qualcosa di strano.');
    }
    if (this.current.id === 'sette' && this.noraFound >= 7) {
      this.advance();
      this.message('Nora', 'Stanotte. Darsena. Non fare tardi, che poi la porta si chiude. — N.');
    }
  }
  soldPhoto() {
    if (this.current.id === 'archivio') {
      this.advance();
      this.message('Ferri, L\'Archivio', 'Nora veniva qui ogni settimana. Chiedi di lei ad Aldo, a Teo, e al Biondo. Loro guardano la città più degli altri.');
    }
  }
  metPerson(id) {
    if (this.current.id !== 'chiricorda' || this.met[id]) return;
    this.met[id] = true;
    this.emit('met', id);
    if (Object.keys(this.met).length >= 3) {
      // i ricordi già trovati contano
      this.advance();
      if (this.noraFound >= 7) this.advance();
    }
  }
  finish(ending) {
    this.ending = ending;
    while (this.current.id !== 'fine') this.chapter++;
    this.emit('chapter', this.current);
    if (ending === 'torna') this.message('Nora', 'Sono al bar. Ho freddo e non ricordo come ci sono arrivata. Vieni? Offro io il caffè.');
    else this.message('Nora', 'Qui le finestre sono sempre accese. Ogni tanto apro una porta e ti guardo camminare. Va bene così. — N.');
  }
  toJSON() { return { chapter: this.chapter, noraFound: this.noraFound, met: this.met, messages: this.messages.slice(0, 40), ending: this.ending, flags: this.flags }; }
}

// ---------- dialoghi ----------
const pick = (a) => a[Math.floor(Math.random() * a.length)];

export const ROLE_LABEL = {
  passante: 'Passante', anziano: 'Persona anziana', rider: 'Rider', turista: 'Turista', studente: 'Studente',
  impiegato: 'Impiegato', cameriere: 'Cameriere', musicista: 'Musicista', pusher: 'Tipo col cappuccio', senzatetto: 'Senzatetto', vigile: 'Polizia locale'
};

export function dialogue(npc, ctx) {
  const { night, raining, drift, story, drunk, high } = ctx;
  // persone della storia
  if (npc.story === 'marta') {
    if (story.current.id === 'messaggio') return { text: 'Nora? Sì che me la ricordo. Cioè… mi ricordo che c\'era. Il suo grembiule è ancora appeso dietro. Parlava sempre di porte che compaiono sui palazzi. Diceva che dentro ci lasciava le sue cose, per non dimenticarle.', advance: 'messaggio' };
    if (story.ending === 'torna') return { text: 'Nora è di là che ride. Non so cosa le hai fatto, ma è tornata più leggera.' };
    return { text: pick(['Le porte, eh? Fai attenzione. Una volta entrata, Nora ci metteva sempre di più a tornare.', 'Un caffè? Ti vedo stanco.', 'Ieri il palazzo qui di fronte aveva un piano in più. Giuro.']) };
  }
  if (npc.story === 'aldo') {
    if (story.current.id === 'chiricorda') return { text: 'La ragazza del bar? Si sedeva qui con me. Mi chiedeva com\'era la città quando i Navigli erano tutti aperti. Le dicevo: uguale, solo più acqua e più nebbia. Lei rideva e scriveva tutto su un quaderno.', met: 'aldo' };
    return { text: pick(['Quando ero giovane qui passavano le chiatte col sale. Adesso passano i turisti.', 'La nebbia non è più quella di una volta. Ma ogni tanto torna, e allora tornano anche certe cose.', 'Guardi il campanile, di notte. Ogni tanto ha una finestra in più.']) };
  }
  if (npc.story === 'teo') {
    if (story.current.id === 'chiricorda') return { text: 'Nora? Le suonavo sempre la stessa canzone, quella del carillon. Mi diceva che la sentiva anche dentro le porte, più lenta. Io non ci sono mai entrato. Ho paura di non ricordarmi la strada per uscire.', met: 'teo' };
    return { text: pick(['Questa la scrivo da tre anni. Non è ancora finita.', 'Se ti piace lascia qualcosa nella custodia, sennò va bene lo stesso.', 'Di notte l\'eco sotto il ponte è perfetta.']) };
  }
  if (npc.story === 'biondo') {
    if (story.current.id === 'chiricorda') return { text: 'La tua amica? Prendeva i Francobolli. Diceva che così vedeva le porte prima degli altri. Io le dicevo di stare attenta. Le porte non sono un posto dove restare.', met: 'biondo', shop: 'pusher' };
    return { text: pick(['Cerchi qualcosa?', 'Non qui, fai due passi con me.', 'Oh. Tutto tranquillo?']), shop: 'pusher' };
  }
  if (npc.story === 'nora') return { text: 'Sei venuto davvero. Qui è tutto come da piccoli: i ballatoi, le lenzuola stese, la luna enorme. Se mi fotografi torno di là, con te. Se non lo fai resto qui, e nessuno si dimentica più di niente.', ending: true };
  // ruoli
  const lines = {
    passante: [
      night ? 'Tardi per girare, eh? Comunque è la parte bella.' : 'Scusa, vado di fretta.',
      raining ? 'Sempre senza ombrello, io.' : 'Bella giornata per camminare lungo il canale.',
      drift > 0.4 ? 'Hai visto anche tu quel palazzo? Prima non era così… o sì?' : 'Ci conosciamo? Mi sembri qualcuno.',
      'Ogni volta che passo di qui c\'è un bar nuovo.'
    ],
    anziano: ['Ai miei tempi qui c\'era la lavanderia. Si lavava nel canale, d\'inverno con le mani rosse.', 'I giovani d\'oggi camminano guardando il telefono. Io guardo le finestre.', 'Il tram nove passava ogni dieci minuti. Adesso quando vuole lui.'],
    rider: ['Scusa, ho una consegna e sono già in ritardo.', 'Questa via non esiste sulla mappa, lo sai?', 'Quaranta consegne oggi. Le gambe non me le sento più.'],
    turista: ['Excuse me… is this the real Naviglio? Very beautiful.', 'Scusi, la Darsena è di qua? Ah, grazie.', 'We took a photo of that building and in the photo it has one more floor. Strange.'],
    studente: ['Ho l\'esame domani e sono qui. Classico.', 'Sai se c\'è un posto dove studiare aperto fino a tardi?', 'Ascolta questa canzone, è assurda.'],
    impiegato: ['Riunione alle nove, finita alle sette. Mi serve un aperitivo.', 'Lavoro qui da dodici anni e non so ancora come si chiama quella via.'],
    cameriere: ['Siediti dove vuoi, arrivo subito.', 'Stasera c\'è il pienone.', 'Hai visto la barista del Ringhiera? Non sta bene da quando è sparita la sua collega.'],
    musicista: ['Una richiesta? So solo canzoni tristi.', 'La musica tiene ferma la città. È una mia teoria.'],
    pusher: ['Ehi. Ti serve qualcosa?', 'Non dare nell\'occhio. Cosa cerchi?', 'Roba buona, prezzi onesti. Più o meno.'],
    vigile: ['Circolare, circolare.', 'Tutto a posto qui?', 'Stasera c\'è un po\' di movimento. Stai attento.'],
    senzatetto: ['Grazie che ti sei fermato. Quasi nessuno lo fa.', 'Dormo qui da due inverni. Il canale di notte fa compagnia.', 'Ho visto la ragazza del bar entrare in un muro. Nessuno mi crede.']
  }[npc.role] || ['…'];
  let text = pick(lines);
  if (npc.rude && npc.kind === 'walker') return { text: pick(INSULTS), rude: true };
  if (drift > 0.45 || (ctx.trip || 0) > 0.3 || Math.random() < 0.1) return { text: distort(pick(BIZARRE), Math.max(drift, ctx.trip || 0)), strange: true };
  if (drunk > 0.5) text = pick(['Sei un po\' alticcio, eh? Vai piano.', ...lines]);
  if (high > 0.5 && Math.random() < 0.4) text = 'Perché mi guardi così? Hai le pupille enormi.';
  return { text, shop: npc.role === 'pusher' ? 'pusher' : null };
}

// ---------- battute dei passanti ----------
// insulti da strada milanese: sgarbati, mai contro gruppi o identità
export const INSULTS = [
  'Ma guarda dove vai, pirla!', 'Oh, sveglia! Il marciapiede non è tuo.', 'Ma va\' a ciapà i ratt!', 'Scansati, che c\'ho fretta.',
  'Ma sei scemo? Mi hai pestato il piede.', 'Vai a lavorare, invece di girare a vuoto.', 'Che c\'hai da guardare?',
  'Ancora tu? Smettila di seguirmi.', 'Hai una faccia che non mi piace. Anzi, non ce l\'hai proprio, una faccia.', 'Ma la smetti di fissarmi, barbagianni?',
  'Togliti di mezzo, testa di rapa.', 'Ma vai a dormire, che si vede che sei messo male.'
];
// frasi strane, sempre più storte quando la città scivola nel sogno
export const BIZARRE = [
  'Hai lasciato la luce accesa in una casa che non esiste più.', 'Ti ho visto ieri. Avevi la mia faccia.',
  'Il tram nove non passa di qui dal novantasei. Eppure eccolo.', 'Contano i piani, di notte. Io ne ho contati sette. Il palazzo ne ha cinque.',
  'Shh. Il canale sta ascoltando.', 'Ripeti il tuo nome. Ripetilo. Ripetilo.', 'Quando chiudi gli occhi, chi tiene ferme le strade?',
  'Sei nel posto giusto ma all\'ora sbagliata. O il contrario.', 'Io qui ci abito da sempre. Da prima che costruissero il sempre.',
  'Hai sentito anche tu il carillon?', 'Tua madre ti cerca. Dice che è pronta la cena. Da vent\'anni.', 'Le finestre accese sono quelle dove non c\'è nessuno.',
  'Non fotografarmi. Poi resto così per sempre.', 'Hai i passi di qualcun altro.', 'Domani è già successo, non preoccuparti.'
];
export const BARKS = [
  'Pronto? Sì, sto arrivando.', 'Che freddo stasera.', 'Hai visto che prezzi al bar?', 'No, ma io gliel\'avevo detto…', 'Domani piove, dicono.',
  'Sì sì, al ponte, tra cinque minuti.', 'Ma dove l\'ho messo il telefono…', 'Che bella luce adesso sul canale.', 'Mamma mia che giornata.'
];

// deforma una frase: parole ripetute, lettere scambiate, parole al contrario
export function distort(text, amount) {
  if (amount <= 0.05) return text;
  return text.split(' ').map((w) => {
    const r = Math.random();
    if (r < amount * 0.25) return w + ' ' + w;
    if (r < amount * 0.45 && w.length > 3) return w.split('').reverse().join('');
    if (r < amount * 0.7 && w.length > 4) { const a = w.split(''); const i = 1 + Math.floor(Math.random() * (a.length - 2)); [a[i], a[i + 1]] = [a[i + 1], a[i]]; return a.join(''); }
    return w;
  }).join(' ');
}

export function bark(npc, ctx) {
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  if (ctx.bump) return npc.rude || Math.random() < 0.35 ? { text: pick(INSULTS), rude: true } : { text: pick(['Scusi!', 'Ops.', 'Attento…']) };
  const strange = ctx.drift > 0.45 || ctx.trip > 0.3 || Math.random() < 0.12;
  if (strange) return { text: distort(pick(BIZARRE), Math.max(ctx.drift, ctx.trip)), strange: true };
  if (npc.rude && Math.random() < 0.4) return { text: pick(INSULTS), rude: true };
  return { text: pick(BARKS) };
}
