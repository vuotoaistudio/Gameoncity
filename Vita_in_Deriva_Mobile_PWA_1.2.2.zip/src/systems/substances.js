// Sostanze di fantasia con effetti coerenti con quelle reali, e conseguenze.
// Ambra (alcol), Kokka (stimolante), Lyn (oppioide), Fumo Verde (cannabis), Francobollo (psichedelico),
// più caffeina e una tisana calmante. Niente dosaggi reali: solo effetti di gioco.

const DEF = {
  ambra: { absorb: 0.018, decay: 0.0032, dose: 0.26 },
  kokka: { absorb: 0.08, decay: 0.006, dose: 0.55 },
  lyn: { absorb: 0.01, decay: 0.0022, dose: 0.5 },
  fumo: { absorb: 0.03, decay: 0.004, dose: 0.4 },
  francobollo: { absorb: 0.05, decay: 0.0035, dose: 0.9, delay: 45 },
  caffeina: { absorb: 0.05, decay: 0.006, dose: 0.35 },
  calma: { absorb: 0.04, decay: 0.01, dose: 0.5 }
};

export class Substances {
  constructor() {
    this.s = {};
    for (const k of Object.keys(DEF)) this.s[k] = { level: 0, pending: 0, peak: 0, wait: 0, doses: 0 };
    this.ambra = this.s.ambra; // compatibilità
    this.hangover = 0;
    this.crash = 0;          // dopo la Kokka: ansia, lentezza
    this.badTrip = false;
    this.black = 0;
    this.blackoutPhase = 0;
    this.blackoutKind = 'ambra';
    this.listeners = {};
    this.t = 0;
  }
  on(ev, fn) { (this.listeners[ev] ||= []).push(fn); }
  emit(ev, data) { for (const f of this.listeners[ev] || []) f(data); }

  take(kind) {
    const d = DEF[kind], x = this.s[kind];
    if (!d) return;
    if (d.delay) x.wait = d.delay;
    x.pending += d.dose; x.doses++;
    if (kind === 'ambra' || kind === 'kokka' || kind === 'lyn') this.hangover = 0;
    if (kind === 'francobollo') {
      // il viaggio dipende da come stai quando arriva: lo decidiamo all'inizio dell'effetto
      this.tripPending = true;
    }
    if (kind === 'caffeina') this.hangover = Math.max(0, this.hangover - 40);
    if (kind === 'calma') { this.crash = Math.max(0, this.crash - 40); this.s.fumo.level *= 0.8; }
  }
  drinkAmbra() { this.take('ambra'); }
  cureHangover() { this.hangover = 0; this.crash = Math.max(0, this.crash - 30); }
  sober(amount) { this.s.ambra.level = Math.max(0, this.s.ambra.level - amount); }

  update(dt) {
    this.t += dt;
    for (const [k, d] of Object.entries(DEF)) {
      const x = this.s[k];
      if (x.wait > 0) { x.wait -= dt; continue; }
      if (k === 'francobollo' && this.tripPending && x.pending > 0) {
        this.tripPending = false;
        this.badTrip = this.s.ambra.level > 0.4 || this.crash > 0 || this.s.fumo.level > 0.6;
        this.emit('trip', this.badTrip);
      }
      const ab = Math.min(x.pending, dt * d.absorb);
      x.pending -= ab;
      x.level = Math.max(0, Math.min(1, x.level + ab - dt * d.decay));
      x.peak = Math.max(x.peak, x.level);
    }
    const a = this.s.ambra, l = this.s.lyn, k = this.s.kokka;
    // collasso: due depressori insieme
    if (this.blackoutPhase === 0 && a.level > 0.35 && l.level > 0.35) { this.blackoutPhase = 1; this.blackoutKind = 'collasso'; }
    if (this.blackoutPhase === 0 && a.level > 0.86) { this.blackoutPhase = 1; this.blackoutKind = 'ambra'; }
    if (this.blackoutPhase === 1) {
      this.black = Math.min(1, this.black + dt / 2.5);
      if (this.black >= 1) {
        this.blackoutPhase = 2;
        a.level = Math.min(a.level, 0.62); a.pending = 0;
        if (this.blackoutKind === 'collasso') { l.level *= 0.3; l.pending = 0; a.level *= 0.4; }
        this.emit('blackout', this.blackoutKind);
      }
    } else if (this.blackoutPhase === 2) {
      this.black = Math.max(0, this.black - dt / 4);
      if (this.black <= 0) this.blackoutPhase = 0;
    }
    if (a.peak > 0.5 && a.level < 0.12 && a.pending === 0) { a.peak = 0; a.doses = 0; this.hangover = 150; this.emit('hangover'); }
    if (k.peak > 0.4 && k.level < 0.1 && k.pending === 0) { k.peak = 0; this.crash = 90; this.emit('crash'); }
    if (this.hangover > 0) this.hangover = Math.max(0, this.hangover - dt);
    if (this.crash > 0) this.crash = Math.max(0, this.crash - dt);
    if (this.s.francobollo.level < 0.05) this.badTrip = false;
    // paranoia da fumo: sussurri ogni tanto
    if (this.s.fumo.level > 0.65 && Math.random() < dt * 0.05) this.emit('paranoia');
  }

  // Modificatori per giocatore, deriva, immagine e suono
  mods(safeMode) {
    const S = this.s, a = S.ambra.level, k = S.kokka.level, l = S.lyn.level, f = S.fumo.level, tr = S.francobollo.level;
    const h = this.hangover > 0 ? Math.min(1, this.hangover / 30) : 0;
    const cr = this.crash > 0 ? Math.min(1, this.crash / 20) : 0;
    const swayRaw = a * (1 - 0.5 * k) + l * 0.35;
    // le palpebre si chiudono a tratti con la Lyn
    const nod = l > 0.4 ? Math.max(0, Math.sin(this.t * 0.35) - 0.82) * 5 * l : 0;
    return {
      speed: (1 - 0.22 * a - 0.1 * h) * (1 + 0.25 * k) * (1 - 0.3 * l) * (1 - 0.15 * cr) * (1 + 0.05 * S.caffeina.level),
      lag: a * 0.85 + l * 0.5,
      sway: swayRaw * (safeMode ? 0.3 : 1),
      noSprint: h > 0 || a > 0.7 || l > 0.6 || cr > 0.5,
      driftMul: (1 + a * 1.2) * (1 - 0.4 * k) * (1 + 0.4 * f) * (1 + 3 * tr),
      doorEase: tr > 0.3 ? 0.35 : f > 0.5 ? 0.12 : 0, // con il Francobollo le porte compaiono molto prima
      drunk: a, stim: Math.max(k, cr * 0.6), opi: l, weed: f, trip: tr, badTrip: this.badTrip ? tr : 0,
      hangover: h, crash: cr, nod: Math.min(1, nod),
      muffle: Math.max(a, l * 0.9),
      heart: k > 0.2 ? k : cr * 0.5,
      cantFocus: this.badTrip && tr > 0.3
    };
  }

  describe() {
    const S = this.s;
    if (this.blackoutPhase === 1) return this.blackoutKind === 'collasso' ? 'Il respiro si fa lento… troppo lento' : 'Le luci si allungano…';
    const parts = [];
    if (S.francobollo.wait > 0 && S.francobollo.pending > 0) parts.push('Aspetti. Non succede niente. Per ora');
    if (S.francobollo.level > 0.15) parts.push(this.badTrip ? 'Viaggio storto: la città ti guarda' : 'La città respira');
    if (S.kokka.level > 0.2) parts.push('Cuore a mille');
    if (S.lyn.level > 0.2) parts.push('Il tempo cola');
    if (S.fumo.level > 0.2) parts.push(S.fumo.level > 0.65 ? 'Fatto, un po\' paranoico' : 'Leggero');
    const a = S.ambra.level;
    if (a > 0.7) parts.push('Ubriaco'); else if (a > 0.4) parts.push('Brillo'); else if (a > 0.12) parts.push('Un po\' allegro');
    if (this.crash > 0) parts.push('Il crollo: ansia, gambe pesanti');
    if (this.hangover > 0) parts.push('Postumi: la luce fa male');
    return parts.length ? parts.join(' · ') : null;
  }
}
