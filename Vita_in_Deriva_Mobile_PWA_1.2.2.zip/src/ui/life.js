// Interfaccia della vita in città: dialoghi, negozi, Archivio, pusher, gratta e vinci, giornale, telefono.
import { ITEMS, SHOP_TYPES, photoValue, scratch, euro } from '../systems/economy.js';
import { CHAPTERS, dialogue, ROLE_LABEL } from '../systems/story.js';
import { describeWeather } from '../world/weather.js';
import { makeProp, PROP_FOR, GESTURE_FOR } from '../fx/props.js';
import { FIGHT_LINES } from '../systems/combat.js';

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const SOUND_FOR = { caffe: 'espresso', cappuccino: 'espresso', ambra: 'glass', fumo: 'lighter', giornale: 'rustle', gratta: 'rustle', tisana: 'espresso' };

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const PUSHER_NIGHT = ['fumo', 'kokka', 'lyn', 'francobollo'], PUSHER_DAY = ['fumo', 'kokka'];
// dove si trova cosa: per la guida nelle tasche
const WHERE = { ambra: 'al bar', fumo: 'nei coffee shop o nei vicoli', kokka: 'nei vicoli', lyn: 'nei vicoli, solo di sera', francobollo: 'nei vicoli, solo di sera' };

export class LifeUI {
  // g: contesto di gioco (state, wallet, story, subs, audio, settings, toast, pause/resume, onBuy...)
  constructor(g) {
    this.g = g;
    this.dialogNpc = null;
    this.phoneApp = 'obj';
    $('btnShopClose').onclick = () => this.closeShop();
    $('btnPhoneClose').onclick = () => this.togglePhone(false);
    $('btnNewsClose').onclick = () => { $('newsPanel').hidden = true; g.resume(); };
    $('btnScratchClose').onclick = () => { $('scratchPanel').hidden = true; g.resume(); };
    for (const b of document.querySelectorAll('.phone .apps button')) b.onclick = () => { this.phoneApp = b.dataset.app; this.renderPhone(); };
    this._mapDrag();
  }

  get busy() { return !$('shopPanel').hidden || !$('newsPanel').hidden || !$('scratchPanel').hidden || !$('phone').hidden || !!this.dialogNpc; }

  // ---------- dialoghi ----------
  talk(npc) {
    const g = this.g, S = g.state;
    g.crowd.talkTo(npc, 12);
    const res = dialogue(npc, { night: S.night, raining: S.weather.precipitation > 0.05, drift: S.drift.avg, story: g.story, drunk: g.subs.s.ambra.level, high: Math.max(g.subs.s.fumo.level, g.subs.s.francobollo.level) });
    this.dialogNpc = npc;
    $('dlgWho').textContent = npc.name || ROLE_LABEL[npc.role] || 'Qualcuno';
    this.type($('dlgText'), res.text, res.strange ? 55 : res.rude ? 18 : 28);
    g.audio.babble(res.text, npc.voice || 1, g.panFor ? g.panFor(npc.x, npc.z) : 0, 0.1, res.rude ? 'rude' : res.strange ? 'strange' : '');
    $('dialog').classList.toggle('strange', !!res.strange); $('dialog').classList.toggle('rude', !!res.rude);
    const ch = $('dlgChoices'); ch.innerHTML = '';
    const add = (label, fn) => { const b = document.createElement('button'); b.type = 'button'; b.textContent = label; b.onclick = fn; ch.appendChild(b); return b; };
    if (res.advance === 'messaggio' && g.story.current.id === 'messaggio') {
      g.story.advance();
      g.toast('Nuovo obiettivo: <em>' + esc(g.story.objective()) + '</em>', true);
    }
    if (res.met) {
      const before = Object.keys(g.story.met).length;
      g.story.metPerson(res.met);
      if (Object.keys(g.story.met).length > before) g.toast(`Qualcuno ricorda Nora (${Object.keys(g.story.met).length}/3).`, true);
    }
    // di notte, con la violenza attiva, un tipo col cappuccio può provare a rapinarti
    if (g.settings.violence && npc.role === 'pusher' && !npc.story && S.night > 0.5 && g.wallet.money >= 30 && !npc.mugged && Math.random() < 0.4) {
      npc.mugged = true;
      const line = FIGHT_LINES.mug[Math.floor(Math.random() * FIGHT_LINES.mug.length)];
      this.type($('dlgText'), line, 22);
      $('dialog').classList.add('rude');
      g.audio.babble(line, 0.8, 0, 0.12, 'rude');
      add('Dagli 20 €', () => { g.wallet.pay(20); g.audio.coins(); $('dlgText').textContent = 'Bravo. Adesso sparisci.'; ch.innerHTML = ''; add('Vai via', () => this.closeDialog()); });
      add('Rifiuta', () => { this.closeDialog(); npc.aggro = true; g.crowd.say(npc, 'Come vuoi tu.', 'rude'); });
      add('Colpisci per primo', () => { this.closeDialog(); g.faceTo(npc); g.combat.attack(); });
      $('dialog').hidden = false;
      return;
    }
    if (res.shop === 'pusher' && g.settings.substances) add('Cosa hai?', () => { this.closeDialog(); this.openShop({ type: 'pusher', name: npc.name || 'Nel vicolo', items: S.night > 0.3 ? PUSHER_NIGHT : PUSHER_DAY }); });
    if (res.ending) {
      add('Fotografala', () => { this.closeDialog(); g.ending('torna'); });
      add('Lasciala sognare', () => { this.closeDialog(); g.ending('sogna'); });
    } else {
      if (npc.role === 'senzatetto' && g.wallet.money >= 2) add('Lascia 2 €', () => { g.wallet.pay(2); $('dlgText').textContent = 'Grazie davvero. Che la nebbia ti sia leggera.'; ch.innerHTML = ''; add('Ciao', () => this.closeDialog()); });
      if (npc.busker && g.wallet.money >= 1) add('Lascia 1 € nella custodia', () => { g.wallet.pay(1); $('dlgText').textContent = 'Grazie. Questa la suono per te.'; ch.innerHTML = ''; add('Ciao', () => this.closeDialog()); });
      add('Ciao', () => this.closeDialog());
    }
    $('dialog').hidden = false;
    g.audio.chime && npc.story && g.audio._musicBox && g.audio._musicBox(660, 0.02);
  }
  // il testo appare lettera per lettera
  type(el, text, ms = 28) {
    clearInterval(this.typer);
    el.textContent = '';
    let i = 0;
    this.typer = setInterval(() => { i += 1; el.textContent = text.slice(0, i); if (i >= text.length) clearInterval(this.typer); }, ms);
  }

  closeDialog() { if (this.dialogNpc) this.g.crowd.talkTo(this.dialogNpc, 0.5); this.dialogNpc = null; $('dialog').hidden = true; }

  // ---------- negozi ----------
  openShop(shop) {
    const g = this.g;
    this.shop = shop;
    g.pause();
    g.enterShop(shop);
    const st = SHOP_TYPES[shop.type] || { label: 'Nel vicolo', greet: ['Fai in fretta.'], items: shop.items };
    $('shopPanel').classList.toggle('dark', shop.type === 'pusher' || shop.type === 'coffeeshop');
    $('receipt').innerHTML = '';
    this.total = 0;
    $('shopType').textContent = st.label;
    $('shopName').textContent = shop.name;
    const greet = shop.type === 'pusher' && g.state.night <= 0.3 ? 'Di giorno ho solo questo. Il resto quando fa buio.' : st.greet[Math.floor(Math.random() * st.greet.length)];
    this.type($('shopGreet'), greet, 24);
    g.audio.babble(greet, 1.1, 0, 0.08, shop.type === 'pusher' ? 'strange' : '');
    this.renderShop();
    $('shopPanel').hidden = false;
  }
  closeShop() {
    if (this.busyBuy) return;
    $('shopPanel').hidden = true; this.shop = null; this.g.leaveShop(); this.g.resume();
  }

  renderShop() {
    const g = this.g, shop = this.shop, box = $('shopItems');
    box.innerHTML = '';
    $('shopMoney').textContent = 'Nel portafoglio: ' + euro(g.wallet.money);
    const warn = $('shopWarn'); warn.hidden = true;
    if (shop.type === 'archivio') {
      $('shopGreet').textContent = g.story.current.id === 'archivio' || g.story.current.id === 'porte'
        ? 'Sono Ferri. Compro le immagini di ciò che la città dimentica. Nora me ne portava una a settimana.'
        : 'Hai portato qualcosa che la città sta dimenticando?';
      const photos = g.state.album.filter((p) => photoValue(p) > 0);
      if (!photos.length) box.innerHTML = '<p class="empty">Non hai foto di anomalie da vendere. Fotografa un palazzo che è cambiato (F, poi clic).</p>';
      for (const p of photos) {
        const v = photoValue(p);
        const row = document.createElement('div'); row.className = 'item';
        row.innerHTML = `<div style="display:flex;gap:10px;align-items:center"><img alt=""><div><b></b><small></small></div></div><span class="price">${euro(v)}</span><button type="button">Vendi</button>`;
        row.querySelector('img').src = p.img || '';
        row.querySelector('b').textContent = p.where;
        row.querySelector('small').textContent = 'Anomalia: ' + p.caption;
        row.querySelector('button').onclick = () => { p.sold = true; g.wallet.earn(v); g.audio.chime(); g.story.soldPhoto(); g.save(); this.renderShop(); g.toast(`Venduta per ${euro(v)}.`); };
        box.appendChild(row);
      }
      return;
    }
    const list = (shop.items || (SHOP_TYPES[shop.type] || {}).items || []).filter((k) => g.settings.substances || !ITEMS[k].adult);
    if (shop.type === 'pusher' || shop.type === 'coffeeshop') {
      warn.hidden = false;
      warn.textContent = shop.type === 'pusher'
        ? 'Sostanze di fantasia con effetti ispirati a quelli reali. Quello che compri qui finisce in tasca: lo usi quando vuoi (I, o Telefono › Tasche).'
        : 'Sostanze di fantasia: effetti ispirati a quelli reali, con conseguenze. Si possono disattivare nelle impostazioni.';
    }
    for (const k of list) {
      const it = ITEMS[k];
      const row = document.createElement('div'); row.className = 'item';
      row.innerHTML = '<div><b></b><small></small></div><span class="price"></span><button type="button">Compra</button>';
      row.querySelector('b').textContent = it.name;
      row.querySelector('small').textContent = it.energy > 0 ? `+${it.energy} energia` : (it.fx === 'gratta' ? 'Da 0 a 100 €' : it.fx === 'giornale' ? 'Notizie di oggi' : it.adult ? 'Effetti forti' : '');
      row.querySelector('.price').textContent = euro(it.price);
      const btn = row.querySelector('button');
      btn.disabled = !g.wallet.canPay(it.price);
      btn.onclick = () => this.buy(k);
      box.appendChild(row);
    }
    if (!list.length) box.innerHTML = '<p class="empty">Oggi non c\'è niente per te.</p>';
  }

  // l'acquisto come scena: paghi, ti porgono la cosa, la usi
  async buy(k) {
    const g = this.g, it = ITEMS[k];
    if (this.busyBuy) return;
    if (!g.wallet.canPay(it.price)) { g.toast('Non hai abbastanza soldi.'); return; }
    this.busyBuy = true;
    for (const b of document.querySelectorAll('#shopItems button')) b.disabled = true;
    const before = g.wallet.money;
    g.wallet.pay(it.price);
    this.total += it.price;
    this.printLine(it.name, it.price);
    this.tweenMoney(before, g.wallet.money);
    const av = g.avatar, clerk = g.clerk();
    if (this.shop && this.shop.type === 'pusher' && clerk) { g.crowd.lookAround(clerk); g.audio.whisper(); await wait(900); }
    av.gesture('pay', 1.0); g.audio.coins();
    await wait(650);
    if (clerk) g.crowd.give(clerk);
    if (this.shop && this.shop.type === 'pusher') {
      // la bustina passa di mano e sparisce in tasca
      g.audio.rustle();
      av.gesture('take', 0.9);
      await wait(900);
      const P = g.state.pocket; P[k] = (P[k] || 0) + 1;
      g.state.stats.spent = (g.state.stats.spent || 0) + it.price;
      g.toast(`In tasca: <em>${esc(it.name)}</em>. La usi quando vuoi: <em>I</em>, oppure Telefono › Tasche.`);
      this.busyBuy = false;
      this.renderShop(); g.save();
      return;
    }
    const snd = SOUND_FOR[k]; if (snd) g.audio[snd]();
    await wait(snd === 'espresso' ? 1500 : 800);
    await this.consume(k);
    this.busyBuy = false;
    this.applyItem(k);
  }

  // l'oggetto in mano e il gesto per usarlo
  async consume(k, sound) {
    const g = this.g, av = g.avatar, propKind = PROP_FOR[k];
    if (!propKind) return;
    av.hold(makeProp(propKind));
    av.gesture('take', 0.6);
    await wait(600);
    const gk = GESTURE_FOR[propKind] || 'look';
    if (sound) { const snd = SOUND_FOR[k]; if (snd) g.audio[snd](); }
    av.gesture(gk, gk === 'read' ? 1.6 : 2.4);
    if (gk === 'sniff') setTimeout(() => g.audio._burst && g.audio._burst(2600, 0.8, 0.35, 0.06, 'highpass'), 900);
    if (gk === 'drink' || gk === 'eat') setTimeout(() => g.audio._burst && g.audio._burst(900, 1, 0.08, 0.03), 900);
    await wait(gk === 'read' ? 1500 : 2300);
    av.release();
  }

  // usare qualcosa dalle tasche, in strada
  async usePocket(k) {
    const g = this.g, P = g.state.pocket;
    if (!P[k] || this.busyBuy) return;
    P[k]--; if (!P[k]) delete P[k];
    this.togglePhone(false);
    this.busyBuy = true;
    g.audio.rustle();
    await this.consume(k, true);
    this.busyBuy = false;
    const it = ITEMS[k];
    if (it.energy) g.wallet.eat(it.energy);
    if (it.fx) { g.subs.take(it.fx); g.audio.glass(); }
    if (it.text) g.toast(esc(it.name) + '. ' + esc(it.text));
    g.save();
  }

  printLine(name, price) {
    const r = document.createElement('div'); r.className = 'rline';
    r.innerHTML = `<span>1 x ${esc(name)}</span><span>${euro(price)}</span>`;
    $('receipt').appendChild(r);
    let tot = $('receiptTot'); if (!tot) { tot = document.createElement('div'); tot.id = 'receiptTot'; tot.className = 'rtot'; }
    tot.innerHTML = `<span>TOTALE</span><span>${euro(this.total)}</span>`; $('receipt').appendChild(tot);
  }

  tweenMoney(a, b) {
    const el = $('shopMoney'), t0 = performance.now();
    const step = (now) => { const k = Math.min(1, (now - t0) / 600); el.textContent = 'Nel portafoglio: ' + euro(a + (b - a) * k); if (k < 1) requestAnimationFrame(step); };
    requestAnimationFrame(step);
  }

  applyItem(k) {
    const g = this.g, it = ITEMS[k];
    g.state.stats.spent = (g.state.stats.spent || 0) + it.price;
    if (it.energy) g.wallet.eat(it.energy);
    const fx = it.fx;
    if (fx === 'ambra' || fx === 'kokka' || fx === 'lyn' || fx === 'fumo' || fx === 'francobollo') { g.subs.take(fx); if (fx === 'ambra') g.state.stats.drinks = (g.state.stats.drinks || 0) + 1; }
    if (fx === 'caffeina') g.subs.take('caffeina');
    if (fx === 'calma') g.subs.take('calma');
    if (fx === 'acqua') g.subs.sober(0.05);
    if (fx === 'aspirina') g.subs.cureHangover();
    if (fx === 'giornale') { this.closeShop(); this.openNews(); return; }
    if (fx === 'gratta') { this.closeShop(); this.openScratch(); return; }
    if (fx === 'vestiti') { this.closeShop(); g.openCreator(); return; }
    if (it.text) g.toast(esc(it.name) + '. ' + esc(it.text));
    this.renderShop();
    g.save();
  }

  // ---------- giornale ----------
  openNews() {
    const g = this.g, w = g.state.weather;
    g.pause();
    $('newsDate').textContent = new Date().toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' });
    const ch = g.story.current.id;
    const items = [
      ['Il tempo in città', `Oggi ${describeWeather(w)}. ${w.source === 'open-meteo' ? 'Dati del servizio meteorologico.' : 'Previsione del nostro inviato, che guarda il cielo dalla finestra.'}`],
      ch === 'porte' || ch === 'messaggio'
        ? ['Porte che compaiono: «sono solo restauri»', 'Diversi residenti dei Navigli segnalano porte nuove su facciate cieche. Il Comune parla di cantieri non comunicati. Una lettrice: «la mia vicina ci è entrata e non è più uscita».']
        : ['L\'Archivio cerca immagini', 'Il signor Ferri, del negozio L\'Archivio, paga «qualsiasi fotografia di ciò che sta cambiando». Prezzi da 10 a 30 euro.'],
      ['Darsena, il campanile di notte', 'Chi passa dopo mezzanotte giura di vedere una finestra in più sul campanile di Santa Maria della Nebbia. Il parroco: «sarà la nebbia».'],
      ['Cercasi: Nora', 'Una giovane barista dell\'alzaia non si presenta al lavoro da giorni. Chi l\'ha vista è pregato di passare al Bar Ringhiera. Nessuno ricorda di preciso che faccia avesse.']
    ];
    $('newsBody').innerHTML = items.map(([h, p]) => `<div><h3>${esc(h)}</h3><p>${esc(p)}</p></div>`).join('');
    $('newsPanel').hidden = false;
  }

  // ---------- gratta e vinci ----------
  openScratch() {
    const g = this.g;
    g.pause();
    const prize = scratch();
    $('scratchPrize').textContent = prize ? euro(prize) : 'Ritenta';
    $('scratchMsg').textContent = 'Gratta con il mouse o con il dito.';
    $('btnScratchClose').hidden = true;
    const cv = $('scratchCanvas'), ctx = cv.getContext('2d');
    ctx.globalCompositeOperation = 'source-over';
    const grd = ctx.createLinearGradient(0, 0, 300, 150); grd.addColorStop(0, '#c9c9c9'); grd.addColorStop(1, '#9a9a9a');
    ctx.fillStyle = grd; ctx.fillRect(0, 0, 300, 150);
    ctx.fillStyle = '#7a7a7a'; ctx.font = '700 18px Karla, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('GRATTA QUI', 150, 80);
    let done = false, down = false;
    const scrape = (e) => {
      if (!down || done) return;
      const r = cv.getBoundingClientRect(), x = (e.clientX - r.left) * 300 / r.width, y = (e.clientY - r.top) * 150 / r.height;
      ctx.globalCompositeOperation = 'destination-out';
      ctx.beginPath(); ctx.arc(x, y, 16, 0, Math.PI * 2); ctx.fill();
      const data = ctx.getImageData(0, 0, 300, 150).data;
      let clear = 0; for (let i = 3; i < data.length; i += 16) if (data[i] < 20) clear++;
      if (clear / (data.length / 16) > 0.5) {
        done = true; ctx.clearRect(0, 0, 300, 150);
        if (prize) { g.wallet.earn(prize); g.audio.chime(); $('scratchMsg').textContent = `Hai vinto ${euro(prize)}!`; } else $('scratchMsg').textContent = 'Niente, questa volta.';
        $('btnScratchClose').hidden = false; g.save();
      }
    };
    cv.onpointerdown = (e) => { down = true; cv.setPointerCapture(e.pointerId); scrape(e); };
    cv.onpointermove = scrape;
    cv.onpointerup = () => { down = false; };
    $('scratchPanel').hidden = false;
  }

  // ---------- telefono ----------
  togglePhone(on) {
    const g = this.g, open = on ?? $('phone').hidden;
    $('phone').hidden = !open;
    if (open) { g.pause(true); this.renderPhone(); }
    else g.resume();
  }

  renderPhone() {
    const g = this.g, S = g.state, sc = $('phScreen');
    for (const b of document.querySelectorAll('.phone .apps button')) b.setAttribute('aria-selected', String(b.dataset.app === this.phoneApp));
    $('phMoney').textContent = euro(g.wallet.money);
    $('phClock').textContent = S.clock || '';
    if (this.phoneApp === 'obj') {
      const c = g.story.current;
      sc.innerHTML = `<div class="where">Capitolo ${Math.min(g.story.chapter + 1, CHAPTERS.length)} · ${esc(c.title)}</div><div class="big">${esc(g.objectiveText())}</div><p class="lede">${esc(c.hint)}</p>
        <div class="stats"><span>Ricordi di Nora: ${g.story.noraFound}/7</span><span>Persone che la ricordano: ${Object.keys(g.story.met).length}/3</span></div>`;
    } else if (this.phoneApp === 'msg') {
      sc.innerHTML = g.story.messages.map((m) => `<div class="msg${m.read ? '' : ' new'}"><b>${esc(m.from)}</b>${esc(m.text)}</div>`).join('') || '<p class="empty">Nessun messaggio.</p>';
      for (const m of g.story.messages) m.read = true;
      g.refreshHud();
    } else if (this.phoneApp === 'map') {
      sc.innerHTML = '<canvas id="phoneMap" width="600" height="600"></canvas><div class="stats"><span>Tu: freccia</span><span style="color:#f2b8c6">Obiettivo</span><span style="color:#f2b36b">Negozi</span><span style="color:#6ee59a">Coffee shop</span><span style="color:#b48cff">Vicoli</span><span style="color:#8fd3c7">Amici</span></div>';
      this.mapZoom = this.mapZoom || 1.6;
      this.drawMap();
    } else if (this.phoneApp === 'pocket') {
      const P = S.pocket, keys = Object.keys(P).filter((k) => P[k] > 0 && ITEMS[k]);
      sc.innerHTML = '<div class="where">Tasche</div>' + (keys.length ? '' : '<p class="empty">Le tasche sono vuote.</p>');
      for (const k of keys) {
        const row = document.createElement('div'); row.className = 'msg';
        row.innerHTML = `<b>${esc(ITEMS[k].name)} × ${P[k]}</b><span></span> <button type="button" class="btn compact">Usa</button>`;
        row.querySelector('span').textContent = ITEMS[k].text;
        row.querySelector('button').onclick = () => this.usePocket(k);
        sc.appendChild(row);
      }
      const guide = document.createElement('div'); guide.className = 'lede';
      guide.innerHTML = g.settings.substances
        ? '<b>Dove trovare cosa</b><br>' + Object.entries(WHERE).map(([k, w]) => `${esc(ITEMS[k].name)}: ${w}`).join('<br>') + '<br>Sulla mappa: verde i coffee shop, viola i vicoli.'
        : 'Le sostanze sono spente nelle impostazioni.';
      sc.appendChild(guide);
    } else if (this.phoneApp === 'jobs') {
      this.renderJobs(sc);
    } else if (this.phoneApp === 'house') {
      this.renderHouses(sc);
    } else if (this.phoneApp === 'garage') {
      this.renderGarage(sc);
    } else {
      sc.innerHTML = `<div class="where">Portafoglio</div><div class="big">${euro(g.wallet.money)}</div>
        <p class="lede">Energia: ${Math.round(g.wallet.energy)}%. ${g.wallet.energy < 25 ? 'Mangia qualcosa: un trancio, un panino, un cornetto.' : ''}</p>
        <div class="stats"><span>Foto vendute: ${S.album.filter((p) => p.sold).length}</span><span>Spesi: ${euro(S.stats.spent || 0)}</span><span>Ricordi: ${S.ricordi.length}</span></div>
        <p class="lede">Si guadagna con i lavori (app Lavori), con gli affitti delle case, vendendo all'Archivio le foto delle anomalie, e qualche volta con un Gratta e Vinci.</p>`;
    }
  }

  // ---------- lavori ----------
  renderJobs(sc) {
    const g = this.g, J = g.jobs;
    if (!J) { sc.innerHTML = '<p class="empty">La città si sta ancora caricando.</p>'; return; }
    J.refreshOffers();
    sc.innerHTML = '<div class="where">Lavori</div>';
    const el = (html) => { const d = document.createElement('div'); d.className = 'msg job'; d.innerHTML = html; sc.appendChild(d); return d; };
    if (J.active) {
      const a = J.active;
      const d = el(`<div><span class="tag${a.legal ? '' : ' bad'}">${a.legal ? 'legale' : 'illecito'}</span><b style="display:inline">${esc(a.title)}</b></div><span>${esc(J.objective())}</span><div class="row2"><span class="pay">${euro(a.pay)}</span><button type="button" class="ghost">Lascia perdere</button></div>`);
      d.querySelector('button').onclick = () => { J.cancel(); this.renderPhone(); g.refreshHud(); };
    } else {
      if (!J.offers.length) sc.insertAdjacentHTML('beforeend', '<p class="empty">Nessuna offerta adesso. Riprova tra poco.</p>');
      for (const o of J.offers) {
        const needCar = o.needsCar && !(g.driving && (g.driving.current || g.driving.vehicles.some((v) => v.owned && v.kind === 'auto')));
        const d = el(`<div><span class="tag${o.legal ? '' : ' bad'}">${o.legal ? 'legale' : 'illecito'}</span><b style="display:inline">${esc(o.title)}</b></div><span><i>${esc(o.who)}:</i> ${esc(o.text)}</span><div class="row2"><span class="pay">${euro(o.pay)}</span><button type="button">${needCar ? 'Accetta (serve un\'auto)' : 'Accetta'}</button></div>`);
        d.querySelector('button').onclick = () => { if (J.accept(o)) { this.togglePhone(false); g.refreshHud(); } };
      }
    }
    sc.insertAdjacentHTML('beforeend', `<div class="stats"><span>Lavori puliti: ${J.done.legal}</span><span>Lavori sporchi: ${J.done.illegal}</span><span>Guadagnato: ${euro(J.done.earned || 0)}</span></div>`);
  }

  // ---------- case ----------
  renderHouses(sc) {
    const g = this.g, E = g.estate, P = g.state.player.pos;
    if (!E) { sc.innerHTML = ''; return; }
    sc.innerHTML = `<div class="where">Case</div><p class="lede">Rendita degli affitti: <b>${euro(E.rentPerMin)}</b> al minuto.</p>`;
    const mine = E.list.filter((L) => E.owned[L.id]);
    if (!mine.length) sc.insertAdjacentHTML('beforeend', '<p class="empty">Non hai ancora una casa. Cerca i cartelli VENDESI sui portoni.</p>');
    const row = (L, extra, btns) => {
      const d = document.createElement('div'); d.className = 'msg job';
      d.innerHTML = `<b>${esc(L.kind)} · ${L.size} m²</b><span>${esc(L.address)} · ${Math.round(Math.hypot(L.door.x - P.x, L.door.z - P.z))} m</span><div class="row2"><span class="pay">${extra}</span><span></span></div>`;
      const box = d.querySelector('.row2 span:last-child');
      for (const [label, fn, ghost] of btns) { const b = document.createElement('button'); b.type = 'button'; b.textContent = label; if (ghost) b.className = 'ghost'; b.onclick = fn; box.appendChild(b); }
      sc.appendChild(d);
    };
    const nav = (L) => () => { g.setNav({ x: L.door.x, z: L.door.z, label: L.address }); this.togglePhone(false); };
    for (const L of mine) row(L, E.owned[L.id].mode === 'casa' ? 'Ci abiti' : `${euro(L.rent)}/min`, [['Portami lì', nav(L)]]);
    sc.insertAdjacentHTML('beforeend', '<div class="where" style="margin-top:6px">In vendita qui vicino</div>');
    const sale = E.list.filter((L) => !E.owned[L.id]).sort((a, b) => Math.hypot(a.door.x - P.x, a.door.z - P.z) - Math.hypot(b.door.x - P.x, b.door.z - P.z)).slice(0, 6);
    for (const L of sale) row(L, euro(L.price), [['Vai a vederla', nav(L), true]]);
  }

  // ---------- garage e annunci ----------
  renderGarage(sc) {
    const g = this.g, D = g.driving, P = g.state.player.pos;
    if (!D) { sc.innerHTML = ''; return; }
    sc.innerHTML = '<div class="where">Garage</div>';
    const mine = D.vehicles.filter((v) => v.owned);
    if (!mine.length) sc.insertAdjacentHTML('beforeend', '<p class="empty">Non hai mezzi tuoi. Puoi comprarne uno qui sotto (o rubarlo per strada, ma poi ti cercano).</p>');
    for (const v of mine) {
      const d = document.createElement('div'); d.className = 'msg job';
      d.innerHTML = `<b>${v.kind === 'scooter' ? 'Scooter' : 'Utilitaria'}</b><span>${D.current === v ? 'La stai guidando' : `Parcheggiata a ${Math.round(Math.hypot(v.x - P.x, v.z - P.z))} m`}</span><div class="row2"><span class="pay" style="color:${esc(v.color)}">●</span><button type="button" class="ghost">Portamela qui · 15 €</button></div>`;
      const b = d.querySelector('button'); b.disabled = D.current === v;
      b.onclick = () => {
        if (!g.wallet.pay(15)) { g.toast('Non hai 15 € per il carro attrezzi.'); return; }
        const n = D.deliver(v.kind, v.color); D._remove(v); n.id = v.id;
        g.toast('Il carro attrezzi te la lascia qui vicino.'); g.save(); this.renderPhone();
      };
      sc.appendChild(d);
    }
    sc.insertAdjacentHTML('beforeend', '<div class="where" style="margin-top:6px">Annunci</div>');
    const ADS = [
      ['scooter', 'Scooter 125 usato', 'Come nuovo, sempre in garage. Il clacson va a modo suo.', 650, ['#9fd3c7', '#e8d9a8', '#c2405a', '#f2f0ea', '#6b8fb3']],
      ['auto', 'Utilitaria usata', '120.000 km, frizione rifatta, un graffio sul paraurti.', 1900, ['#7d7d78', '#5b6d78', '#8f1d1d', '#22252b']],
      ['auto', 'Utilitaria nuova', 'Chilometri zero, colore a scelta del concessionario.', 3400, ['#1f3550', '#e7e4dc', '#3e5b45', '#c9b27b', '#5a2b33']]
    ];
    for (const [kind, title, text, price, colors] of ADS) {
      const d = document.createElement('div'); d.className = 'msg job';
      d.innerHTML = `<b>${esc(title)}</b><span>${esc(text)}</span><div class="row2"><span class="pay">${euro(price)}</span><button type="button">Compra</button></div>`;
      const b = d.querySelector('button'); b.disabled = !g.wallet.canPay(price);
      if (b.disabled) b.textContent = `Mancano ${euro(price - g.wallet.money)}`;
      b.onclick = () => {
        if (!g.wallet.pay(price)) return;
        const col = colors[Math.floor(Math.random() * colors.length)];
        D.deliver(kind, col); g.audio.cash(); g.save();
        g.toast(`Affare fatto. Il tuo ${kind === 'scooter' ? 'scooter' : 'mezzo'} ti aspetta qui vicino: avvicinati e premi <em>E</em>.`, true);
        this.renderPhone();
      };
      sc.appendChild(d);
    }
  }

  drawMap() {
    const cv = document.getElementById('phoneMap'); if (!cv) return;
    const g = this.g, S = g.state, ctx = cv.getContext('2d'), P = S.player.pos;
    const k = this.mapZoom, cx = 300, cy = 300;
    const X = (x) => cx + (x - P.x) * k, Y = (z) => cy + (z - P.z) * k;
    ctx.fillStyle = '#141418'; ctx.fillRect(0, 0, 600, 600);
    ctx.fillStyle = '#20324a';
    for (const w of S.features.water) { ctx.beginPath(); w.outer.forEach(([x, z], i) => (i ? ctx.lineTo(X(x), Y(z)) : ctx.moveTo(X(x), Y(z)))); ctx.closePath(); ctx.fill(); }
    ctx.fillStyle = '#2b2a30';
    for (const b of S.features.buildings) { ctx.beginPath(); b.outer.forEach(([x, z], i) => (i ? ctx.lineTo(X(x), Y(z)) : ctx.moveTo(X(x), Y(z)))); ctx.closePath(); ctx.fill(); }
    ctx.strokeStyle = '#4a4a52'; ctx.lineCap = 'round';
    for (const r of S.features.roads) { ctx.lineWidth = Math.max(1, r.width * k * 0.6); ctx.beginPath(); r.pts.forEach(([x, z], i) => (i ? ctx.lineTo(X(x), Y(z)) : ctx.moveTo(X(x), Y(z)))); ctx.stroke(); }
    for (const s of g.shops.shops) { ctx.fillStyle = s.type === 'archivio' ? '#e6c98a' : s.type === 'coffeeshop' ? '#6ee59a' : '#f2b36b'; ctx.beginPath(); ctx.arc(X(s.x), Y(s.z), s.type === 'coffeeshop' ? 6 : 4, 0, 7); ctx.fill(); }
    if (g.settings.substances) for (const n of g.crowd.npcs) if (n.role === 'pusher') { ctx.fillStyle = '#b48cff'; ctx.beginPath(); ctx.arc(X(n.x), Y(n.z), 6, 0, 7); ctx.fill(); }
    if (g.settings.violence) for (const n of g.crowd.police) { ctx.fillStyle = '#5b8cff'; ctx.fillRect(X(n.x) - 4, Y(n.z) - 4, 8, 8); }
    for (const a of g.avatars.list.values()) { ctx.fillStyle = '#8fd3c7'; ctx.beginPath(); ctx.arc(X(a.group.position.x), Y(a.group.position.z), 6, 0, 7); ctx.fill(); }
    const t = g.objectiveTarget();
    if (t) {
      ctx.strokeStyle = '#f2b8c6'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(X(t.x), Y(t.z), 11, 0, 7); ctx.stroke();
      ctx.fillStyle = '#f2b8c6'; ctx.font = '600 18px Karla, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(t.label, Math.max(60, Math.min(540, X(t.x))), Math.max(24, Math.min(590, Y(t.z) - 18)));
    }
    // il giocatore: freccia nella direzione dello sguardo
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(-S.player.yaw + Math.PI);
    ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.moveTo(0, -12); ctx.lineTo(8, 9); ctx.lineTo(0, 4); ctx.lineTo(-8, 9); ctx.closePath(); ctx.fill();
    ctx.restore();
    ctx.fillStyle = '#8a8a92'; ctx.font = '12px "IBM Plex Mono", monospace'; ctx.textAlign = 'left'; ctx.fillText('N ↑', 12, 20);
  }

  _mapDrag() {
    document.addEventListener('wheel', (e) => {
      if ($('phone').hidden || this.phoneApp !== 'map' || !e.target.closest || !e.target.closest('#phoneMap')) return;
      this.mapZoom = Math.max(0.4, Math.min(5, (this.mapZoom || 1.6) * Math.exp(-e.deltaY * 0.0015)));
      this.drawMap();
    }, { passive: true });
  }
}
