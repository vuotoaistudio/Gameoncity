// Minimappa rotonda: la città vera disegnata una volta sola, poi ruotata con lo sguardo del giocatore.
const PX = 0.8; // pixel per metro nella mappa pre-disegnata

export class MiniMap {
  constructor(canvas, features, extent) {
    this.canvas = canvas;
    this.g = canvas.getContext('2d');
    this.radiusM = 110;
    const ex = extent;
    this.x0 = ex.minX; this.z0 = ex.minZ;
    const w = Math.min(4096, Math.ceil((ex.maxX - ex.minX) * PX)), h = Math.min(4096, Math.ceil((ex.maxZ - ex.minZ) * PX));
    const off = document.createElement('canvas'); off.width = w; off.height = h;
    const g = off.getContext('2d');
    const T = (p) => [(p[0] - this.x0) * PX, (p[1] - this.z0) * PX];
    const poly = (ring) => { g.beginPath(); ring.forEach((p, i) => { const [x, y] = T(p); i ? g.lineTo(x, y) : g.moveTo(x, y); }); g.closePath(); };
    g.fillStyle = '#1d1c21'; g.fillRect(0, 0, w, h);
    g.fillStyle = '#26352a'; for (const p of features.parks) { poly(p.outer); g.fill(); }
    g.fillStyle = '#3a3833'; for (const p of features.plazas) { poly(p.outer); g.fill(); }
    g.fillStyle = '#1f4256';
    for (const wa of features.water) { poly(wa.outer); g.fill(); }
    g.strokeStyle = '#1f4256'; g.lineCap = 'round'; g.lineJoin = 'round';
    for (const ww of features.waterways) { if (features.water.length && ww.kind !== 'stream') continue; g.lineWidth = ww.width * PX; g.beginPath(); ww.pts.forEach((p, i) => { const [x, y] = T(p); i ? g.lineTo(x, y) : g.moveTo(x, y); }); g.stroke(); }
    // strade: le carrabili più chiare e larghe
    for (const pass of [0, 1]) {
      for (const r of features.roads) {
        const car = r.width >= 6;
        if ((pass === 1) !== car) continue;
        g.strokeStyle = car ? '#6d6a72' : '#4a484f';
        g.lineWidth = Math.max(1.2, r.width * PX);
        g.beginPath(); r.pts.forEach((p, i) => { const [x, y] = T(p); i ? g.lineTo(x, y) : g.moveTo(x, y); }); g.stroke();
      }
    }
    g.fillStyle = '#8c8173'; g.strokeStyle = '#5e564c'; g.lineWidth = 0.6;
    for (const b of features.buildings) { if (b.minHeight > 3) continue; poly(b.outer); g.fill(); g.stroke(); }
    this.map = off;
    this.last = 0;
  }

  // heading: 0 = guardi verso nord, cresce in senso orario
  draw(now, pos, heading, marks) {
    if (now - this.last < 66) return;
    this.last = now;
    const c = this.canvas, g = this.g, W = c.width, H = c.height, R = W / 2;
    const s = (R - 6) / this.radiusM / PX;
    g.clearRect(0, 0, W, H);
    g.save();
    g.beginPath(); g.arc(R, R, R - 3, 0, Math.PI * 2); g.clip();
    g.fillStyle = '#1d1c21'; g.fillRect(0, 0, W, H);
    g.translate(R, R); g.rotate(-heading); g.scale(s, s);
    g.translate(-(pos.x - this.x0) * PX, -(pos.z - this.z0) * PX);
    g.drawImage(this.map, 0, 0);
    g.restore();
    // segni: obiettivo, amici, veicoli
    const toScreen = (x, z) => {
      const dx = x - pos.x, dz = z - pos.z;
      const ca = Math.cos(-heading), sa = Math.sin(-heading);
      const rx = dx * ca - dz * sa, rz = dx * sa + dz * ca;
      return [R + rx * (R - 6) / this.radiusM, R + rz * (R - 6) / this.radiusM, Math.hypot(rx, rz) / this.radiusM];
    };
    for (const m of marks.vehicles || []) {
      const [x, y, d] = toScreen(m.x, m.z); if (d > 0.95) continue;
      g.fillStyle = m.tram ? '#f2b36b' : '#cfd3d8'; g.beginPath(); g.arc(x, y, m.tram ? 3 : 2, 0, Math.PI * 2); g.fill();
    }
    for (const m of marks.peers || []) {
      let [x, y, d] = toScreen(m.x, m.z);
      if (d > 0.92) { const k = 0.92 / d; x = R + (x - R) * k; y = R + (y - R) * k; }
      g.fillStyle = m.color; g.strokeStyle = '#111'; g.lineWidth = 1.5; g.beginPath(); g.arc(x, y, 4.5, 0, Math.PI * 2); g.fill(); g.stroke();
    }
    if (marks.target) {
      let [x, y, d] = toScreen(marks.target.x, marks.target.z);
      const out = d > 0.9;
      if (out) { const k = 0.9 / d; x = R + (x - R) * k; y = R + (y - R) * k; }
      g.save(); g.translate(x, y);
      g.fillStyle = '#f2b8c6'; g.strokeStyle = '#2a1820'; g.lineWidth = 2;
      if (out) { g.rotate(Math.atan2(y - R, x - R) + Math.PI / 2); g.beginPath(); g.moveTo(0, -7); g.lineTo(5.5, 4); g.lineTo(-5.5, 4); g.closePath(); g.fill(); g.stroke(); }
      else { g.beginPath(); g.moveTo(0, -9); g.bezierCurveTo(6, -9, 6, -2, 0, 4); g.bezierCurveTo(-6, -2, -6, -9, 0, -9); g.fill(); g.stroke(); }
      g.restore();
    }
    // io: freccia al centro, sempre verso l'alto
    g.save(); g.translate(R, R);
    g.fillStyle = '#8fd3c7'; g.strokeStyle = '#0c1412'; g.lineWidth = 2;
    g.beginPath(); g.moveTo(0, -8); g.lineTo(6, 6); g.lineTo(0, 3); g.lineTo(-6, 6); g.closePath(); g.fill(); g.stroke();
    g.restore();
    // bordo e nord
    g.strokeStyle = 'rgba(238,233,226,0.35)'; g.lineWidth = 2; g.beginPath(); g.arc(R, R, R - 3, 0, Math.PI * 2); g.stroke();
    const na = -heading - Math.PI / 2;
    const nx = R + Math.cos(na) * (R - 12), ny = R + Math.sin(na) * (R - 12);
    g.fillStyle = '#15141a'; g.beginPath(); g.arc(nx, ny, 8, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#f2b8c6'; g.font = '700 10px "IBM Plex Mono", monospace'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('N', nx, ny + 0.5);
  }
}
