// Luce e aria dal sole reale e dal meteo (reale o simulato).
import * as THREE from 'three';

const D = Math.PI / 180;
const ss = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const C = (r, g, b) => new THREE.Color(r, g, b);

// Restituisce i parametri per luci, nebbia ed esposizione; aggiorna le uniform di acqua e cielo.
export function computeAtmosphere(env, sky, sunDir, sunAlt, weather, dream, moon) {
  const e = sunAlt / D;
  const day = ss(-6, 8, e);
  const night = 1 - ss(-8, 2, e);
  const dusk = ss(-8, 0, e) * (1 - ss(4, 18, e));
  const cloud = weather.cloudCover / 100;
  const overcast = Math.min(1, cloud * 0.85 + (weather.precipitation > 0.1 ? 0.3 : 0));
  const fogDensity = Math.max(0.0009, 2.1 / Math.max(80, weather.visibility)) * (1 + overcast * 0.6);

  env.uSunDir.value.set(sunDir[0], Math.max(sunDir[1], 0.05), sunDir[2]).normalize();
  const warm = ss(0, 25, e);
  const sunColor = C(1.0, 0.52, 0.3).lerp(C(1.0, 0.95, 0.87), warm);
  const sunIntensity = 3.7 * day * (1 - overcast * 0.8);
  env.uSunColor.value.copy(sunColor).multiplyScalar(sunIntensity * 0.75);

  const zenith = C(0.16, 0.32, 0.66).lerp(C(0.4, 0.44, 0.48), overcast);
  const horizon = C(0.6, 0.67, 0.76).lerp(C(0.6, 0.61, 0.62), overcast);
  const duskZ = C(0.22, 0.19, 0.38), duskH = C(0.98, 0.52, 0.38).lerp(C(0.52, 0.45, 0.5), overcast);
  const nightZ = C(0.012, 0.016, 0.045), nightH = C(0.06, 0.055, 0.085);
  zenith.lerp(duskZ, dusk).lerp(nightZ, night);
  horizon.lerp(duskH, dusk).lerp(nightH, night);

  env.uSkyAmb.value.copy(zenith).lerp(horizon, 0.35).multiplyScalar(1.1);
  env.uGroundAmb.value.copy(C(0.24, 0.22, 0.2)).multiplyScalar(day + 0.05).lerp(C(0.07, 0.05, 0.035), night);
  const fogColor = horizon.clone().lerp(C(0.58, 0.58, 0.6), Math.min(1, overcast * 0.45 + (weather.visibility < 1500 ? 0.4 : 0)) * (1 - night));
  env.uFogDensity.value = fogDensity;
  env.uFogColor.value.copy(fogColor);
  env.uNight.value = night;
  env.uDream.value = dream;

  sky.uZenith.value.copy(zenith);
  sky.uHorizon.value.copy(horizon);
  sky.uSunColor.value.copy(sunColor).multiplyScalar(Math.max(0.15, day) * (1 - overcast * 0.6));
  sky.uSunDir.value.set(sunDir[0], sunDir[1], sunDir[2]).normalize();
  sky.uCloud.value = cloud;
  sky.uOvercast.value = overcast;
  sky.uTurbidity.value = 2.2 + overcast * 6 + (weather.visibility < 8000 ? 3 : 0);
  // luna: allontanata dal sole lungo l'eclittica secondo la fase (approssimazione visiva)
  if (moon) {
    const S = new THREE.Vector3(sunDir[0], sunDir[1], sunDir[2]).normalize();
    const pole = new THREE.Vector3(0, Math.sin(45.45 * D), -Math.cos(45.45 * D));
    const east = new THREE.Vector3().crossVectors(pole, S).normalize();
    const el = moon * Math.PI * 2;
    sky.uMoonDir.value.copy(S).multiplyScalar(Math.cos(el)).addScaledVector(east, Math.sin(el)).normalize();
    sky.uMoonPhase.value = moon;
  }
  sky.uNight.value = night;
  sky.uFog.value = Math.min(1, fogDensity * 250);
  sky.uFogColor.value.copy(fogColor);
  sky.uDream.value = dream;

  return {
    day, night, dusk, overcast, fogDensity, fogColor,
    sunColor, sunIntensity,
    hemiSky: zenith.clone().lerp(horizon, 0.5), hemiGround: C(0.3, 0.26, 0.22).multiplyScalar(0.3 + 0.7 * day),
    hemiIntensity: 0.3 + (0.5 + overcast * 0.45) * day + 0.32 * night,
    envIntensity: 0.22 + (0.4 + overcast * 0.35) * day,
    exposure: 0.95 + night * 0.75,
    visibleRange: Math.min(450, 1.7 / fogDensity)
  };
}
