// Costruzione della città 3D a partire dagli elementi di osm.js.
// Materiali fisici (ombre, riflessi del cielo) con facciate procedurali e deriva iniettate negli shader.
import * as THREE from 'three';
import { pointInRing, signedArea, parseLength } from './osm.js';
import { carGeometries } from '../fx/vehicles.js';

export const DRIFT_TEX_W = 256;
export const WATER_LEVEL = -1.7;

// Palette di facciata di ispirazione milanese (intonaci, mattone, pietra)
const FACADE = ['#d9b47c', '#e2c27f', '#d6a89a', '#c98b68', '#bdb6aa', '#e5ddcd', '#a9664d', '#cfc1a0', '#d8cfbf', '#b7a07a', '#c9a27e', '#ddd3c0']
  .map((h) => new THREE.Color(h));

// Uniform condivise (shader personalizzati: acqua, cielo; e iniezioni nei materiali standard)
export function createEnvUniforms() {
  return {
    uSunDir: { value: new THREE.Vector3(0.3, 0.8, -0.4).normalize() },
    uSunColor: { value: new THREE.Color(1.0, 0.95, 0.85) },
    uSkyAmb: { value: new THREE.Color(0.45, 0.5, 0.6) },
    uGroundAmb: { value: new THREE.Color(0.25, 0.23, 0.22) },
    uFogColor: { value: new THREE.Color(0.7, 0.75, 0.8) },
    uFogDensity: { value: 0.0025 },
    uNight: { value: 0 },
    uWet: { value: 0 },
    uTime: { value: 0 },
    uDream: { value: 0 },
    uInterior: { value: 1 }
  };
}

const HASH_GLSL = /* glsl */`
// hash senza seno (Dave Hoskins): stabile anche con coordinate grandi e sulle GPU meno precise
float h1(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
float vnoise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0-2.0*f);
  return mix(mix(h1(i), h1(i+vec2(1,0)), f.x), mix(h1(i+vec2(0,1)), h1(i+vec2(1,1)), f.x), f.y); }
`;

// ---------- edifici: materiale standard + facciata procedurale + deriva ----------
const B_VERT_HEAD = /* glsl */`
attribute float aBid; attribute vec3 aColor; attribute vec4 aInfo; attribute vec2 aDims; attribute vec2 aFacadeUv;
uniform sampler2D uDriftTex; uniform float uDriftW;
varying vec3 vFacade; varying vec2 vUv2; varying vec4 vInfo; varying vec4 vDrift; varying float vH; varying vec3 vWPos; varying vec3 vWNor;
`;
const B_VERT_BEGIN = /* glsl */`
vec4 dr = texelFetch(uDriftTex, ivec2(int(mod(aBid, uDriftW)), int(floor(aBid / uDriftW))), 0);
float dtype = floor(dr.g * 255.0 + 0.5);
vec3 transformed = vec3(position);
float extra = dtype < 0.5 ? floor(dr.r * 3.4) * aInfo.y : 0.0;
float ff = clamp((position.y - aDims.x) / max(aDims.y - aDims.x, 0.1), 0.0, 1.0);
transformed.y += ff * extra;
vUv2 = vec2(aFacadeUv.x, aFacadeUv.y + ff * extra * step(aInfo.z, 0.5));
vH = aDims.y - aDims.x + extra; vInfo = aInfo; vDrift = dr; vFacade = aColor;
vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
vWNor = normalize(mat3(modelMatrix) * normal);
`;
const B_VERT_BEGIN_DEPTH = /* glsl */`
vec4 dr = texelFetch(uDriftTex, ivec2(int(mod(aBid, uDriftW)), int(floor(aBid / uDriftW))), 0);
float dtype = floor(dr.g * 255.0 + 0.5);
vec3 transformed = vec3(position);
transformed.y += clamp((position.y - aDims.x) / max(aDims.y - aDims.x, 0.1), 0.0, 1.0) * (dtype < 0.5 ? floor(dr.r * 3.4) * aInfo.y : 0.0);
`;
const B_FRAG_HEAD = /* glsl */`
uniform float uWet; uniform float uNight; uniform float uTime; uniform vec3 uSkyAmb; uniform float uInterior;
varying vec3 vFacade; varying vec2 vUv2; varying vec4 vInfo; varying vec4 vDrift; varying float vH; varying vec3 vWPos; varying vec3 vWNor;
${HASH_GLSL}
// La stanza dietro il vetro: un raggio entra in una scatola (interior mapping) e incontra pareti,
// pavimento, soffitto e mobili. Restituisce il colore già illuminato e, in .a, quanta luce c'è dentro.
vec4 roomBehind(vec2 id, float fx, float fy, float W, float H, float D, float lit, float shop){
  vec3 V = normalize(vWPos - cameraPosition);
  vec3 N = normalize(vec3(vWNor.x, 0.0, vWNor.z));
  vec3 T = vec3(-N.z, 0.0, N.x);
  vec3 dir = vec3(dot(V, T), V.y, max(-dot(V, N), 0.03));
  // mai componenti nulle: il segno deve restare quello vero, altrimenti il raggio esce dalla stanza
  dir.x = abs(dir.x) < 1e-3 ? (dir.x < 0.0 ? -1e-3 : 1e-3) : dir.x;
  dir.y = abs(dir.y) < 1e-3 ? (dir.y < 0.0 ? -1e-3 : 1e-3) : dir.y;
  vec3 p = vec3(clamp(fx, 0.001, 0.999) * W, clamp(fy, 0.001, 0.999) * H, 0.0);
  vec3 tt = max(vec3(((dir.x > 0.0 ? W : 0.0) - p.x) / dir.x, ((dir.y > 0.0 ? H : 0.0) - p.y) / dir.y, (D - p.z) / dir.z), vec3(0.0));
  float t = min(min(tt.x, tt.y), tt.z);
  vec3 q = p + dir * t;
  float r1 = h1(id + 7.3), r2 = h1(id + 1.9), r3 = h1(id + 4.4);
  vec3 wall = mix(vec3(0.84, 0.8, 0.72), mix(vec3(0.78, 0.62, 0.5), vec3(0.58, 0.67, 0.72), r2), r1 * 0.7);
  vec3 c;
  bool floorHit = false, isCeil = false;
  if (t == tt.z) {
    vec2 b = q.xy / vec2(W, H);
    c = wall;
    if (shop > 0.5) {
      // scaffali con la merce
      float row = fract(b.y * 4.0);
      vec3 goods = mix(mix(vec3(0.75, 0.25, 0.2), vec3(0.2, 0.42, 0.7), h1(floor(b * vec2(14.0, 4.0)) + id)), vec3(0.9, 0.82, 0.5), step(0.66, h1(floor(b * vec2(9.0, 4.0)) + id * 2.0)));
      c = mix(vec3(0.32, 0.25, 0.18), goods, step(0.12, row) * step(row, 0.8) * step(0.08, b.y) * step(b.y, 0.92));
    } else if (r3 > 0.55) {
      vec2 pc = abs(b - vec2(0.3 + r1 * 0.4, 0.58));
      if (max(pc.x / 0.13, pc.y / 0.1) < 1.0) c = mix(vec3(0.12, 0.18, 0.28), vec3(0.62, 0.42, 0.26), r2) * (0.8 + 0.4 * h1(floor(b * 20.0)));
      else if (max(pc.x / 0.145, pc.y / 0.115) < 1.0) c = vec3(0.55, 0.42, 0.22);
    } else if (r3 > 0.2) {
      float m = step(abs(b.x - 0.5), 0.32) * step(b.y, 0.36);
      c = mix(c, mix(vec3(0.24, 0.17, 0.11), vec3(0.32, 0.34, 0.4), r1), m);
    } else {
      // porta socchiusa sul corridoio buio
      float dm = step(abs(b.x - (0.2 + r1 * 0.6)), 0.12) * step(b.y, 0.78);
      c = mix(c, vec3(0.05, 0.045, 0.04), dm);
    }
  } else if (t == tt.y) {
    if (dir.y < 0.0) {
      floorHit = true;
      vec2 f = q.xz;
      c = r1 > 0.45 ? vec3(0.4, 0.26, 0.15) * (0.82 + 0.18 * h1(floor(f * vec2(1.2, 7.0))))
                    : vec3(0.62, 0.58, 0.52) * (0.88 + 0.12 * h1(floor(f * 3.0)));
    } else { isCeil = true; c = vec3(0.88, 0.87, 0.84); }
  } else {
    c = wall * 0.86;
    // un armadio o una libreria su un lato
    if (r2 > 0.6 && q.z > D * 0.35 && q.z < D * 0.85 && q.y < H * 0.82) c = mix(vec3(0.3, 0.22, 0.15), vec3(0.85, 0.82, 0.75), step(0.5, r1)) * (0.85 + 0.15 * step(0.5, fract(q.y * 2.5)));
  }
  float depth = q.z / D;
  float dayAmb = dot(uSkyAmb, vec3(0.3, 0.59, 0.11));
  vec3 L = vec3(dayAmb * 0.5 * (1.0 - depth * 0.7)) * (isCeil ? 0.7 : 1.0) * (floorHit ? 1.15 : 1.0);
  if (lit > 0.5) {
    vec3 lampC = r2 > 0.82 ? vec3(0.75, 0.85, 1.0) : vec3(1.0, 0.7, 0.4);
    vec2 lp = vec2(W * (0.35 + 0.3 * r3), D * 0.55);
    float hot = 1.0 - smoothstep(0.0, 0.75, length((q.xz - lp) / vec2(W, D)));
    float k = 0.7 + 1.5 * hot + (isCeil ? 1.2 * hot * hot : 0.0);
    L += lampC * k * (shop > 0.5 ? 1.8 : 1.0);
  }
  return vec4(c * L, dot(L, vec3(0.33)));
}
`;
const B_FRAG_COLOR = /* glsl */`
float fGlass = 0.0, fLit = 0.0, fRough = 0.85;
vec3 fInt = vec3(0.0);
{
  float d = vDrift.r; float type = floor(vDrift.g * 255.0 + 0.5);
  float seed = vInfo.x, floorH = vInfo.y, part = vInfo.z, style = vInfo.w;
  float shop = (style > 0.5 && style < 1.5) ? 1.0 : 0.0;
  vec3 col = vFacade;
  if (type > 1.5 && type < 2.5) {
    vec3 dream = mix(vec3(0.96, 0.74, 0.80), vec3(0.58, 0.84, 0.80), h1(vec2(seed, 3.0)));
    col = mix(col, dream, smoothstep(0.15, 0.9, d));
  }
  #ifndef VID_LITE
  float grime = vnoise(vUv2 * vec2(0.35, 0.6) + seed * 40.0);
  col *= 0.86 + 0.18 * grime;
  // colature della pioggia lungo la facciata e intonaco a macchie
  col *= 0.93 + 0.07 * vnoise(vec2(vUv2.x * 2.3 + seed * 17.0, vUv2.y * 0.07));
  col *= 0.96 + 0.06 * vnoise(vUv2 * 3.1);
  #endif
  bool vivid = uInterior > 0.5;
  vec3 frameC = seed > 0.55 ? vec3(0.86, 0.85, 0.8) : (seed > 0.3 ? vec3(0.2, 0.17, 0.13) : vec3(0.36, 0.25, 0.16));
  if (part < 0.5) {
    float u = vUv2.x, v = vUv2.y;
    if (style > 2.5) {
      // marmo policromo fiorentino: riquadri bianchi, cornici verdi, specchiature rosa
      vec2 g = vec2(u / 4.6, v / 6.5); vec2 f = fract(g);
      float frame = step(0.04, f.x) * step(f.x, 0.96) * step(0.035, f.y) * step(f.y, 0.965);
      float inner = step(0.12, f.x) * step(f.x, 0.88) * step(0.1, f.y) * step(f.y, 0.9);
      vec3 white = vec3(0.9, 0.88, 0.82) * (0.9 + 0.1 * vnoise(vUv2 * 2.0));
      vec3 green = vec3(0.12, 0.2, 0.17) * (0.85 + 0.2 * vnoise(vUv2 * 5.0));
      vec3 pink = vec3(0.8, 0.6, 0.55);
      col = white;
      if (frame > 0.5 && inner < 0.5) col = green;
      if (inner > 0.5 && mod(floor(g.y), 3.0) == 1.0) col = mix(pink, white, 0.25 * vnoise(vUv2 * 3.0));
      if (fract(v / 13.0) < 0.02) col = green;
      if (v < 0.9) col = green * 1.2;
      col *= mix(0.8, 1.0, smoothstep(0.0, 3.0, v));
      fRough = 0.35;
    } else {
    if (style > 1.5) {
      // pietra forte a bugnato: conci grandi e rustici in basso, più lisci in alto
      float rowH = v < 4.5 ? 0.9 : 0.55;
      float row = floor(v / rowH);
      float bw = v < 4.5 ? 1.6 : 1.1;
      float bx = (u + mod(row, 2.0) * bw * 0.5) / bw;
      vec2 fb = vec2(fract(bx), fract(v / rowH));
      float joint = min(min(fb.x, 1.0 - fb.x) * bw, min(fb.y, 1.0 - fb.y) * rowH);
      float bulge = v < 4.5 ? smoothstep(0.0, 0.18, joint) : smoothstep(0.0, 0.03, joint);
      col = vFacade * (0.82 + 0.3 * h1(vec2(floor(bx), row))) * mix(0.55, 1.0, bulge) * (0.9 + 0.15 * vnoise(vUv2 * 3.0));
    }
    col *= mix(0.78, 1.0, smoothstep(0.0, 2.5, v));
    float groundH = shop > 0.5 ? 4.4 : 3.7;
    float bay = 3.2 + seed * 0.9;
    if (type > 0.5 && type < 1.5 && d > 0.3) bay *= 0.55;
    if (v < 0.9) col = mix(col, vec3(0.5, 0.49, 0.46) * (0.9 + 0.1 * vnoise(vUv2 * 4.0)), 0.8);
    if (v > vH - 0.75) { col *= 1.12; if (v > vH - 0.2) col *= 0.85; if (v < vH - 0.62) col *= 0.7; }
    else if (v < groundH) {
      float w = bay * 1.45; float cell = floor(u / w); float fx = fract(u / w);
      float open = step(0.1, fx) * step(fx, 0.9) * step(0.12, v) * step(v, groundH - 0.55);
      if (shop > 0.5) {
        float frame = 1.0 - step(0.13, fx) * step(fx, 0.87) * step(v, groundH - 0.62);
        if (open > 0.5) {
          if (frame > 0.5) col = vec3(0.12, 0.13, 0.12);
          else {
            fGlass = 1.0; col = vec3(0.02);
            float on = step(0.25, h1(vec2(cell, seed * 9.0)));
            if (vivid) {
              float fxw = (fx - 0.13) / 0.74, fyw = (v - 0.12) / (groundH - 0.74);
              fInt = roomBehind(vec2(cell, seed * 9.0), fxw, fyw, w * 0.74, groundH - 0.74, w * 1.6, on, 1.0).rgb * (0.6 + 0.4 * on);
            } else fLit = on * uNight;
          }
          if (uNight > 0.5 && h1(vec2(cell, seed * 3.0)) < 0.25) { fGlass = 0.0; fLit = 0.0; fInt = vec3(0.0); col = vec3(0.42, 0.43, 0.42) * (0.8 + 0.2 * step(0.5, fract(v * 9.0))); }
        }
        // insegna sopra la vetrina
        if (v > groundH - 0.55 && v < groundH - 0.2) col = mix(col, vec3(0.16, 0.18, 0.2), 0.8);
      } else {
        float door = step(0.82, h1(vec2(cell, seed * 5.0)));
        float win = step(0.3, fx) * step(fx, 0.7) * step(1.1, v) * step(v, groundH - 0.6);
        if (door > 0.5) { if (open > 0.5) col = vec3(0.22, 0.15, 0.1) * (0.85 + 0.15 * step(0.5, fract(fx * 8.0))); }
        else if (win > 0.5) {
          fGlass = 1.0; col = vec3(0.03);
          // inferriata del piano terra
          if (fract(fx * 7.0) < 0.12 || fract(v * 4.0) < 0.1) { fGlass = 0.0; col = vec3(0.12); }
          else if (vivid) fInt = roomBehind(vec2(cell, seed * 5.0), fx, (v - 1.1) / (groundH - 1.7), w, groundH - 1.7, w * 1.2, step(0.7, h1(vec2(cell, 2.0 + seed))) * uNight, 0.0).rgb;
        }
      }
    } else {
      float fv = (v - groundH) / floorH; float fl = floor(fv); float fy = fract(fv);
      float cell = floor(u / bay); float fx = fract(u / bay);
      float win, surround;
      bool isRound = type > 0.5 && type < 1.5 && d > 0.6;
      if (isRound) {
        vec2 q = vec2((fx - 0.5) * bay, (fy - 0.52) * floorH);
        float r = length(q * vec2(1.0, 0.85));
        win = step(r, 0.7); surround = step(r, 0.85) - win;
      } else {
        win = step(0.3, fx) * step(fx, 0.7) * step(0.22, fy) * step(fy, 0.82);
        surround = step(0.27, fx) * step(fx, 0.73) * step(0.19, fy) * step(fy, 0.86) - win;
      }
      float side = (step(0.15, fx) * step(fx, 0.3) + step(0.7, fx) * step(fx, 0.85)) * step(0.22, fy) * step(fy, 0.82);
      float rnd = h1(vec2(cell, fl + seed * 31.0));
      if (type > 2.5 && type < 3.5 && rnd < d) { win = 0.0; side = 0.0; surround = 0.0; }
      #ifndef VID_LITE
      // sporco che cola sotto i davanzali
      if (fx > 0.3 && fx < 0.7 && fy < 0.19) col *= 1.0 - 0.13 * (1.0 - fy / 0.19) * (0.4 + 0.6 * vnoise(vec2(u * 9.0, fl * 3.0 + seed)));
      // marcapiano
      if (fy < 0.035) col *= 1.1; else if (fy < 0.06) col *= 0.88;
      #endif
      if (surround > 0.5) { col = mix(col, vec3(0.86, 0.83, 0.77), 0.6); if (fy < 0.22 && fy > 0.19) col *= 1.08; }
      bool shutters = seed > 0.38;
      vec3 shut = mix(vec3(0.22, 0.33, 0.24), vec3(0.33, 0.23, 0.15), step(0.8, seed));
      // lamelle: si attenuano con la distanza per non tremolare
      float sx = fy * floorH * 7.0, aa = fwidth(sx);
      float slat = mix(smoothstep(0.5 - aa, 0.5 + aa, fract(sx)), 0.5, clamp(aa * 1.5, 0.0, 1.0));
      if (shutters && side > 0.5) { col = shut * (0.82 + 0.18 * slat); fRough = 0.6; }
      if (win > 0.5) {
        float closed = shutters ? step(0.78 - 0.2 * (1.0 - uNight), h1(vec2(cell * 3.1, fl + seed))) : 0.0;
        if (closed > 0.5) { col = shut * (0.78 + 0.22 * slat); fRough = 0.6; }
        else {
          fGlass = 1.0;
          float wx = isRound ? fx : (fx - 0.3) / 0.4, wy = isRound ? fy : (fy - 0.22) / 0.6;
          float fw = max(0.05, fwidth(wx) * 1.2);
          bool frm = !isRound && (wx < fw || wx > 1.0 - fw || wy < fw * 0.7 || wy > 1.0 - fw * 0.7 || abs(wx - 0.5) < fw * 0.6 || abs(wy - 0.62) < fw * 0.5) && fwidth(fx) < 0.08;
          col = frm ? frameC : vec3(0.015, 0.017, 0.02);
          if (frm) { fGlass = 0.0; fRough = 0.5; }
          float on = step(0.58, rnd);
          float wrongLight = (type > 3.5 && type < 4.5) ? step(rnd, d) : 0.0;
          float lit = max(on * uNight, wrongLight);
          if (!frm && vivid) {
            vec2 rid = vec2(cell, fl + seed * 31.0);
            vec4 rm = roomBehind(rid, fx, fy, bay, floorH, bay * 1.25, lit, 0.0);
            vec3 inside = rm.rgb;
            // tende, tendine e veneziane
            float ct = h1(rid + 9.1), a = 0.0;
            vec3 cc = mix(vec3(0.93, 0.91, 0.86), vec3(0.72, 0.5, 0.4), step(0.88, ct));
            if (ct < 0.35) a = 0.0;
            else if (ct < 0.6) a = max(smoothstep(0.26, 0.1, wx), smoothstep(0.74, 0.9, wx)) * (0.8 + 0.2 * sin(wx * 70.0));
            else if (ct < 0.8) a = 0.5 + 0.08 * sin(wx * 45.0);
            else { float drop = 0.25 + 0.6 * h1(rid + 2.2); a = step(1.0 - drop, wy) * (0.8 + 0.2 * step(0.5, fract(wy * 28.0))); cc = vec3(0.82, 0.8, 0.74); }
            fInt = mix(inside, cc * (rm.a * 0.9 + 0.04), a);
          } else if (!frm) fLit = lit;
        }
      }
    }
    }
  } else if (part < 1.5) {
    col = vec3(0.36, 0.35, 0.34) * (0.85 + 0.2 * vnoise(vWPos.xz * 0.8));
  } else if (part < 2.5) {
    float row = floor(vUv2.y / 0.33);
    float tile = h1(vec2(floor(vUv2.x / 0.24 + row * 0.5), row));
    vec3 terra = mix(vec3(0.55, 0.27, 0.17), vec3(0.42, 0.25, 0.19), tile);
    terra *= 0.8 + 0.25 * smoothstep(0.0, 0.33, fract(vUv2.y / 0.33));
    terra *= 0.9 + 0.1 * sin(vUv2.x / 0.24 * 6.283);
    // muschio e sporco, qualche tegola sostituita
    col = mix(terra, vec3(0.3, 0.31, 0.26), 0.3 * vnoise(vWPos.xz * 0.4) + 0.15 * step(0.93, h1(floor(vUv2 / vec2(0.24, 0.33)) + 5.0)));
    fRough = 0.7;
  } else if (part > 3.5 && part < 4.5) {
    // cupola: coppi rossi lungo i meridiani, costoloni di marmo bianco agli spigoli
    float u = vUv2.x, k = vUv2.y;
    float edge = min(fract(u), 1.0 - fract(u));
    float rib = 1.0 - smoothstep(0.025, 0.05, edge);
    vec2 q = vec2(fract(u) * 26.0, k * 11.0);
    vec3 terra = mix(vec3(0.62, 0.29, 0.16), vec3(0.5, 0.25, 0.17), h1(floor(q) + floor(u)));
    terra *= 0.78 + 0.28 * smoothstep(0.0, 0.5, fract(q.y)) * smoothstep(0.0, 0.25, min(fract(q.x), 1.0 - fract(q.x)) * 4.0);
    col = mix(terra * (0.9 + 0.15 * vnoise(vUv2 * 4.0)), vec3(0.9, 0.88, 0.83), rib);
    if (k < 0.3) col = vec3(0.88, 0.86, 0.8) * (fract(k * 10.0) < 0.5 ? 1.0 : 0.85);
    fRough = mix(0.72, 0.4, rib);
  } else {
    col *= 0.95;
  }
  col *= 1.0 - uWet * 0.22 * (1.0 - fGlass);
  diffuseColor.rgb = col;
}
`;
const B_FRAG_NORMAL = /* glsl */`
#ifndef VID_LITE
{
  // intonaco ruvido: la luce radente rivela la grana del muro
  float nA = vnoise(vUv2 * 7.0) - 0.5, nB = vnoise(vUv2 * 7.0 + 31.0) - 0.5;
  normal = normalize(normal + vec3(nA, nB, 0.0) * 0.07 * (1.0 - fGlass));
}
#endif
`;
const B_FRAG_ROUGH = 'roughnessFactor = mix(fRough, 0.04, fGlass) * (1.0 - uWet * 0.45 * (1.0 - fGlass));';
// di notte la luce dei lampioni sale sui muri: calda in basso, si spegne verso i piani alti
const B_FRAG_EMIT = 'totalEmissiveRadiance += fInt + vec3(1.0, 0.7, 0.4) * fLit * 2.2 + vec3(1.0, 0.96, 0.9) * vDrift.a * 1.2 + diffuseColor.rgb * vec3(1.0, 0.68, 0.4) * uNight * 0.16 * (1.0 - smoothstep(1.5, 13.0, vWPos.y)) * (1.0 - fGlass) * step(vInfo.z, 0.5);';

function injectBuilding(mat, env, driftU, depthOnly) {
  mat.onBeforeCompile = (shader) => {
    Object.assign(shader.uniforms, driftU, { uWet: env.uWet, uNight: env.uNight, uTime: env.uTime, uSkyAmb: env.uSkyAmb, uInterior: env.uInterior });
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', '#include <common>\n' + B_VERT_HEAD)
      .replace('#include <begin_vertex>', depthOnly ? B_VERT_BEGIN_DEPTH : B_VERT_BEGIN);
    if (depthOnly) return;
    shader.fragmentShader = shader.fragmentShader
      .replace('#include <common>', '#include <common>\n' + B_FRAG_HEAD)
      .replace('#include <color_fragment>', '#include <color_fragment>\n' + B_FRAG_COLOR)
      .replace('#include <normal_fragment_maps>', '#include <normal_fragment_maps>\n' + B_FRAG_NORMAL)
      .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\n' + B_FRAG_ROUGH)
      .replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\n' + B_FRAG_EMIT);
  };
  mat.customProgramCacheKey = () => (depthOnly ? 'vid-building-depth' : 'vid-building-5' + (mat.defines && mat.defines.VID_LITE !== undefined ? '-lite' : ''));
}

const ID_VERT = /* glsl */`
attribute float aBid; attribute vec4 aInfo; attribute vec2 aDims;
uniform sampler2D uDriftTex; uniform float uDriftW;
varying float vBidOut;
void main(){
  vec4 dr = texelFetch(uDriftTex, ivec2(int(mod(aBid, uDriftW)), int(floor(aBid / uDriftW))), 0);
  float dtype = floor(dr.g * 255.0 + 0.5);
  vec3 p = position;
  float extra = dtype < 0.5 ? floor(dr.r * 3.4) * aInfo.y : 0.0;
  p.y += clamp((position.y - aDims.x) / max(aDims.y - aDims.x, 0.1), 0.0, 1.0) * extra;
  vBidOut = aBid;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
}`;
const ID_FRAG = /* glsl */`
varying float vBidOut;
void main(){
  float n = vBidOut + 1.0;
  gl_FragColor = vec4(mod(n, 256.0) / 255.0, mod(floor(n / 256.0), 256.0) / 255.0, floor(n / 65536.0) / 255.0, 1.0);
}`;

// ---------- superfici a terra: asfalto, lastre di pietra, cubetti, prato ----------
const G_VERT_HEAD = 'attribute float aKind; varying float vKind; varying vec3 vWPos;';
const G_VERT_BEGIN = 'vec3 transformed = vec3(position); vKind = aKind; vWPos = (modelMatrix * vec4(position, 1.0)).xyz;';
const G_FRAG_HEAD = `uniform float uWet; varying float vKind; varying vec3 vWPos;\n${HASH_GLSL}`;
const G_FRAG_COLOR = /* glsl */`
float gRough = 0.9, gPuddle = 0.0;
{
  vec3 col = diffuseColor.rgb;
  float dist = length(vWPos - cameraPosition);
  float near = 1.0 - smoothstep(8.0, 45.0, dist);
  vec2 p = vWPos.xz;
  float k = floor(vKind + 0.5);
  if (k == 0.0) {
    // asfalto: grana, rattoppi, macchie d'olio, crepe
    col *= 0.88 + 0.2 * vnoise(p * 0.15) + (h1(floor(p * 6.0)) - 0.5) * 0.08 * near;
    float patchN = vnoise(p * 0.07 + 13.0);
    col *= mix(1.0, 0.82, smoothstep(0.62, 0.66, patchN));
    col *= 1.0 - 0.12 * smoothstep(0.75, 0.95, vnoise(p * 0.5 + 7.0));
    float crack = abs(vnoise(p * 0.9) - 0.5);
    col *= 1.0 - 0.25 * smoothstep(0.015, 0.0, crack) * near;
    gRough = 0.92;
  } else if (k == 1.0) {
    vec2 q = p / vec2(1.4, 0.7); q.x += step(1.0, mod(floor(q.y), 2.0)) * 0.5;
    vec2 f = fract(q);
    float joint = min(min(f.x, 1.0 - f.x) * 1.4, min(f.y, 1.0 - f.y) * 0.7);
    col *= mix(0.72, 0.92 + 0.16 * h1(floor(q)), smoothstep(0.0, 0.025, joint) * near + (1.0 - near) * 0.95);
    col *= 0.92 + 0.12 * vnoise(p * 0.2);
    gRough = 0.8;
  } else if (k == 3.0) {
    // porfido a ventaglio
    vec2 q = p * 3.6; q.x += sin(q.y * 0.35) * 1.2;
    vec2 f = fract(q); float j = min(min(f.x, 1.0 - f.x), min(f.y, 1.0 - f.y));
    vec3 porfido = mix(vec3(0.42, 0.33, 0.3), vec3(0.5, 0.45, 0.42), h1(floor(q)));
    col = mix(col, porfido * mix(0.55, 1.0, smoothstep(0.0, 0.12, j)), near * 0.9 + 0.1);
    gRough = 0.75;
  } else if (k == 4.0) {
    // prato di città: chiazze secche, terra battuta, trifoglio
    float n1 = vnoise(p * 0.6), n2 = vnoise(p * 4.0), n3 = vnoise(p * 0.12 + 5.0);
    vec3 green = mix(vec3(0.24, 0.32, 0.16), vec3(0.36, 0.4, 0.2), n1);
    vec3 dry = vec3(0.45, 0.42, 0.3);
    col = mix(green, dry, smoothstep(0.55, 0.85, n3) * 0.7) * (0.8 + 0.3 * n2);
    col = mix(col, vec3(0.36, 0.3, 0.24), smoothstep(0.78, 0.9, vnoise(p * 0.3 + 2.0)) * 0.8);
    gRough = 0.95;
  }
  // pozzanghere quando piove: nelle conche dell'asfalto e tra le pietre
  float hollow = vnoise(p * 0.22 + 3.0) * 0.7 + vnoise(p * 0.9) * 0.3;
  gPuddle = smoothstep(0.72 - uWet * 0.22, 0.76 - uWet * 0.2, hollow) * step(k, 3.5) * smoothstep(0.15, 0.5, uWet);
  col *= 1.0 - uWet * 0.3;
  col = mix(col, col * 0.45, gPuddle);
  diffuseColor.rgb = col;
}
`;
function groundMaterial(env) {
  const m = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9, metalness: 0 });
  m.onBeforeCompile = (shader) => {
    shader.uniforms.uWet = env.uWet;
    shader.vertexShader = shader.vertexShader.replace('#include <common>', '#include <common>\n' + G_VERT_HEAD).replace('#include <begin_vertex>', G_VERT_BEGIN);
    shader.fragmentShader = shader.fragmentShader
      .replace('#include <common>', '#include <common>\n' + G_FRAG_HEAD)
      .replace('#include <color_fragment>', '#include <color_fragment>\n' + G_FRAG_COLOR)
      .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\nroughnessFactor = mix(mix(gRough, 0.2, uWet * step(vKind, 3.5)), 0.02, gPuddle);')
      .replace('#include <normal_fragment_maps>', '#include <normal_fragment_maps>' + String.fromCharCode(10) + 'normal = normalize(mix(normal, (viewMatrix * vec4(0.0, 1.0, 0.0, 0.0)).xyz, gPuddle));');
  };
  m.customProgramCacheKey = () => 'vid-ground-2';
  return m;
}

const WATER_VERT = /* glsl */`
uniform mat4 uReflMatrix;
varying vec3 vWorld; varying vec4 vRefl;
void main(){ vec4 w = modelMatrix * vec4(position, 1.0); vWorld = w.xyz; vRefl = uReflMatrix * w; gl_Position = projectionMatrix * viewMatrix * w; }`;
const WATER_FRAG = /* glsl */`
uniform vec3 uSunDir; uniform vec3 uSunColor; uniform vec3 uSkyAmb; uniform vec3 uFogColor; uniform float uFogDensity;
uniform float uNight; uniform float uWet; uniform float uTime; uniform float uDream;
uniform sampler2D tReflect; uniform float uReflOn;
varying vec3 vWorld; varying vec4 vRefl;
${HASH_GLSL}
// increspature: più ottave di rumore che scorrono con la corrente del canale
vec2 ripple(vec2 p, float t){
  vec2 g = vec2(0.0);
  float e = 0.08;
  float a = 1.0;
  for (int i = 0; i < 4; i++) {
    vec2 q = p * (0.35 * pow(2.1, float(i))) + vec2(t * (0.12 + 0.05 * float(i)), t * 0.07 * float(i));
    float c = vnoise(q);
    g += vec2(vnoise(q + vec2(e, 0.0)) - c, vnoise(q + vec2(0.0, e)) - c) / e * a;
    a *= 0.55;
  }
  return g;
}
void main(){
  vec2 p = vWorld.xz;
  vec2 g = ripple(p, uTime);
  // gocce di pioggia: cerchi che si allargano
  if (uWet > 0.05) {
    vec2 cell = floor(p * 1.5); vec2 f = fract(p * 1.5) - 0.5;
    float t = fract(uTime * 0.7 + h1(cell));
    float r = length(f) - t * 0.5;
    g += normalize(f + 1e-4) * cos(r * 60.0) * smoothstep(0.06, 0.0, abs(r)) * (1.0 - t) * step(0.5, h1(cell + 3.0)) * uWet * 2.5;
  }
  vec3 N = normalize(vec3(-g.x * 0.09, 1.0, -g.y * 0.09));
  vec3 V = normalize(cameraPosition - vWorld);
  float fres = 0.02 + 0.98 * pow(1.0 - max(dot(N, V), 0.0), 5.0);
  // acqua dei Navigli: verde-bruna, torbida
  vec3 deep = vec3(0.03, 0.05, 0.04) * (uSkyAmb * 1.4 + uSunColor * 0.2) + vec3(0.004, 0.006, 0.005);
  vec3 refl = mix(uSkyAmb * 1.5, uFogColor, 0.3);
  if (uReflOn > 0.5) {
    vec2 ruv = vRefl.xy / vRefl.w + N.xz * 0.045;
    refl = texture2D(tReflect, ruv).rgb;
  }
  vec3 c = mix(deep, refl, clamp(fres * 1.15 + 0.1, 0.0, 1.0));
  c += uSunColor * pow(max(dot(reflect(-V, N), uSunDir), 0.0), 220.0) * 4.0;
  if (uReflOn < 0.5) c += vec3(1.0, 0.7, 0.4) * uNight * 0.25 * smoothstep(0.65, 1.0, vnoise(vec2(p.x * 0.5, p.y * 3.0 + sin(uTime + p.x) * 0.6)));
  c = mix(c, vec3(0.62, 0.86, 0.95) * 0.6, uDream * 0.2);
  float dist = length(vWorld - cameraPosition);
  c = mix(c, uFogColor, 1.0 - exp(-pow(uFogDensity * dist, 2.0)));
  gl_FragColor = vec4(c, 1.0);
}`;

// ---------- utilità geometriche ----------
function outwardNormal(ring, i, ccw) {
  const [x1, z1] = ring[i], [x2, z2] = ring[(i + 1) % ring.length];
  const dx = x2 - x1, dz = z2 - z1, len = Math.hypot(dx, dz) || 1;
  return ccw ? [dz / len, -dx / len] : [-dz / len, dx / len];
}

function newAcc() { return { pos: [], nor: [], fuv: [], bid: [], col: [], info: [], dims: [], kind: [] }; }

function pushWalls(acc, ring, base, top, extra, inward, closed = true) {
  const ccw = signedArea(ring) > 0;
  let u = 0;
  const n = closed ? ring.length : ring.length - 1;
  for (let i = 0; i < n; i++) {
    const a = ring[i], b = ring[(i + 1) % ring.length];
    const len = Math.hypot(b[0] - a[0], b[1] - a[1]);
    let [nx, nz] = outwardNormal(ring, i, ccw);
    if (inward) { nx = -nx; nz = -nz; }
    const v = [[a[0], base, a[1], u, 0], [b[0], base, b[1], u + len, 0], [b[0], top, b[1], u + len, top - base], [a[0], top, a[1], u, top - base]];
    const order = (ccw !== inward) ? [0, 2, 1, 0, 3, 2] : [0, 1, 2, 0, 2, 3];
    for (const k of order) {
      acc.pos.push(v[k][0], v[k][1], v[k][2]); acc.nor.push(nx, 0, nz); acc.fuv.push(v[k][3], v[k][4]);
      extra(acc);
    }
    u += len;
  }
}

function pushCap(acc, outer, holes, y, ny, extra) {
  const contour = outer.map((p) => new THREE.Vector2(p[0], p[1]));
  const hs = holes.map((h) => h.map((p) => new THREE.Vector2(p[0], p[1])));
  let tris;
  try { tris = THREE.ShapeUtils.triangulateShape(contour, hs); } catch (e) { return; }
  const all = contour.concat(...hs);
  for (const t of tris) {
    const [a, b, c] = t.map((i) => all[i]);
    const cross = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
    const idx = (cross > 0) === (ny > 0) ? [t[0], t[2], t[1]] : [t[0], t[1], t[2]];
    for (const i of idx) {
      acc.pos.push(all[i].x, y, all[i].y); acc.nor.push(0, ny, 0); acc.fuv.push(all[i].x, all[i].y);
      extra(acc);
    }
  }
}

function pushTri(acc, a, b, c, uvs, extra) {
  const ab = new THREE.Vector3().subVectors(b, a), ac = new THREE.Vector3().subVectors(c, a);
  const n = new THREE.Vector3().crossVectors(ab, ac).normalize();
  [a, b, c].forEach((p, i) => { acc.pos.push(p.x, p.y, p.z); acc.nor.push(n.x, n.y, n.z); acc.fuv.push(uvs[i][0], uvs[i][1]); extra(acc); });
}

// rettangolo orientato di area minima (per i tetti a falde)
export function minRect(ring) {
  let best = null;
  for (let i = 0; i < ring.length; i++) {
    const a = ring[i], b = ring[(i + 1) % ring.length];
    const l = Math.hypot(b[0] - a[0], b[1] - a[1]);
    if (l < 0.5) continue;
    const ux = (b[0] - a[0]) / l, uz = (b[1] - a[1]) / l, vx = -uz, vz = ux;
    let u0 = Infinity, u1 = -Infinity, v0 = Infinity, v1 = -Infinity;
    for (const p of ring) {
      const u = p[0] * ux + p[1] * uz, v = p[0] * vx + p[1] * vz;
      u0 = Math.min(u0, u); u1 = Math.max(u1, u); v0 = Math.min(v0, v); v1 = Math.max(v1, v);
    }
    const area = (u1 - u0) * (v1 - v0);
    if (!best || area < best.area) best = { area, ux, uz, vx, vz, u0, u1, v0, v1 };
  }
  return best;
}

function geometryFrom(acc, withBuildingAttrs) {
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(acc.pos, 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(acc.nor, 3));
  if (withBuildingAttrs) {
    g.setAttribute('aFacadeUv', new THREE.Float32BufferAttribute(acc.fuv, 2));
    g.setAttribute('aBid', new THREE.Float32BufferAttribute(acc.bid, 1));
    g.setAttribute('aColor', new THREE.Float32BufferAttribute(acc.col, 3));
    g.setAttribute('aInfo', new THREE.Float32BufferAttribute(acc.info, 4));
    g.setAttribute('aDims', new THREE.Float32BufferAttribute(acc.dims, 2));
  } else {
    g.setAttribute('color', new THREE.Float32BufferAttribute(acc.col, 3));
    g.setAttribute('aKind', new THREE.Float32BufferAttribute(acc.kind, 1));
  }
  g.computeBoundingSphere();
  return g;
}

// ---------- edifici ----------
// tetto a cupola (profilo a sesto acuto, come quella del Brunelleschi) o a piramide, sopra un poligono qualsiasi
function pushRoofCone(acc, ring, y0, h, dome, extra) {
  const [cx, cz] = centroidOf(ring);
  const steps = dome ? 9 : 1;
  const levels = [];
  for (let k = 0; k <= steps; k++) {
    const a = (k / steps) * Math.PI / 2;
    const s = dome ? Math.cos(a) : 1 - k;
    const y = dome ? y0 + h * Math.pow(Math.sin(a), 0.82) : y0 + h * k;
    levels.push({ s: Math.max(0, s), y });
  }
  const P = (i, L) => new THREE.Vector3(cx + (ring[i % ring.length][0] - cx) * L.s, L.y, cz + (ring[i % ring.length][1] - cz) * L.s);
  for (let k = 0; k < steps; k++) {
    const L0 = levels[k], L1 = levels[k + 1];
    for (let i = 0; i < ring.length; i++) {
      const a = P(i, L0), b = P(i + 1, L0), c = P(i + 1, L1), d = P(i, L1);
      const mid = new THREE.Vector3().add(a).add(b).add(c).multiplyScalar(1 / 3);
      const out = new THREE.Vector3(mid.x - cx, 0.6, mid.z - cz);
      const el = Math.hypot(ring[(i + 1) % ring.length][0] - ring[i][0], ring[(i + 1) % ring.length][1] - ring[i][1]);
      const sl = Math.hypot(h, Math.hypot((ring[i][0] + ring[(i + 1) % ring.length][0]) / 2 - cx, (ring[i][1] + ring[(i + 1) % ring.length][1]) / 2 - cz));
      const uv = dome ? [[i, k], [i + 1, k], [i + 1, k + 1], [i, k + 1]] : [[0, 0], [el, 0], [el * 0.5, sl], [el * 0.5, sl]];
      const tri = (p, q, r, t) => {
        const n = new THREE.Vector3().crossVectors(new THREE.Vector3().subVectors(q, p), new THREE.Vector3().subVectors(r, p));
        if (n.lengthSq() < 1e-8) return;
        if (n.dot(out) < 0) pushTri(acc, p, r, q, [t[0], t[2], t[1]], extra); else pushTri(acc, p, q, r, t, extra);
      };
      tri(a, b, c, [uv[0], uv[1], uv[2]]);
      if (L1.s > 0.001) tri(a, c, d, [uv[0], uv[2], uv[3]]);
    }
  }
}

// facciate in marmo policromo (bianco di Carrara, verde di Prato, rosa di Maremma) e palazzi in pietra forte
const MARBLE = /Santa Maria del Fiore|Campanile di Giotto|Battistero|Basilica di Santa Croce|San Miniato|Duomo di Milano/i;
const STONE = /Palazzo Vecchio|Palazzo Pitti|Palazzo Strozzi|Palazzo Medici|Bargello|Palazzo Rucellai|Orsanmichele|Palazzo Davanzati|Loggia dei Lanzi|Uffizi|Palazzo Gondi|Torre (dei|degli|della)/i;
function centroidOf(r) { let x = 0, z = 0; for (const p of r) { x += p[0]; z += p[1]; } return [x / r.length, z / r.length]; }

function buildBuildings(features, env, driftTex, lite, palette, tileCaps) {
  const acc = newAcc();
  const meta = [];
  const balconies = [];
  const chimneys = [];
  const lanterns = [];
  const outlines = (features.outlines || []).filter((o) => o.tags.name);
  for (const b of features.buildings) {
    const seed = b.seed;
    const t = b.tags;
    const isChurch = t.building === 'church' || t.building === 'cathedral' || t.amenity === 'place_of_worship';
    let color = isChurch ? new THREE.Color('#d8cdb8') : palette[Math.floor(seed * palette.length) % palette.length];
    // colore reale della facciata, quando OpenStreetMap lo conosce
    if (t['building:colour']) { try { const c = new THREE.Color().setStyle(t['building:colour'].replace(/^([0-9a-f]{6})$/i, '#$1')); color = c.lerp(color, 0.25); } catch { /* colore non valido */ } }
    else if (t['building:material'] === 'brick') color = new THREE.Color('#9a5a44');
    // nome proprio o, per le parti di un monumento, il nome del monumento che le contiene
    let name = t.name || '';
    if (t['building:part']) { const c = centroidOf(b.outer); const o = outlines.find((q) => pointInRing(c[0], c[1], q.outer)); if (o) name += ' ' + o.tags.name; }
    let style = 0;
    if (MARBLE.test(name)) { style = 3; color = new THREE.Color('#e9e4d8'); }
    else if (STONE.test(name) || t['building:material'] === 'stone') { style = 2; color = new THREE.Color('#9b8a70'); }
    const levels = Math.max(1, b.levels);
    const floorH = isChurch || style === 3 ? 6 : Math.min(4.2, Math.max(2.9, (b.height - b.minHeight - 3.7) / Math.max(1, levels - 1) || 3.2));
    const shop = (t.shop || t['building:use'] === 'retail' || t.building === 'retail' || t.building === 'commercial') ? 1 : 0;
    const base = b.minHeight;
    // cupole e tetti a piramide: i muri si fermano dove comincia il tetto
    const shape = t['roof:shape'];
    const special = (shape === 'dome' || shape === 'onion' || shape === 'pyramidal' || shape === 'hipped') && !b.holes.length && b.outer.length >= 3;
    let roofH = parseLength(t['roof:height']);
    const rr = minRect(b.outer), shortSide = rr ? Math.min(rr.u1 - rr.u0, rr.v1 - rr.v0) : 6;
    if (special && !isFinite(roofH)) roofH = shape === 'dome' || shape === 'onion' ? shortSide * 0.5 : shortSide * (shape === 'hipped' ? 0.22 : 0.4);
    const top = special ? Math.max(base + 1, b.height - roofH) : b.height;
    const info = style ? style : shop;
    const extraFn = (part) => (a) => {
      a.bid.push(b.bid); a.col.push(color.r, color.g, color.b);
      a.info.push(seed, floorH, part, info); a.dims.push(base, top);
    };
    pushWalls(acc, b.outer, base, top, extraFn(0), false);
    for (const h of b.holes) pushWalls(acc, h, base, top, extraFn(0), true);
    if (special) {
      pushRoofCone(acc, b.outer, top, b.height - top, shape === 'dome' || shape === 'onion', extraFn(shape === 'dome' || shape === 'onion' ? 4 : 2));
      if ((shape === 'dome') && b.height > 60) { const c = centroidOf(b.outer); lanterns.push([c[0], b.height - 1.5, c[1], shortSide]); }
      let cx = 0, cz = 0, rad = 0;
      for (const p of b.outer) { cx += p[0]; cz += p[1]; }
      cx /= b.outer.length; cz /= b.outer.length;
      for (const p of b.outer) rad = Math.max(rad, Math.hypot(p[0] - cx, p[1] - cz));
      meta.push({ bid: b.bid, cx, cz, r: rad, top, floorH, shop, base });
      continue;
    }

    // tetto: a falde se la pianta è quasi rettangolare, altrimenti piano
    const area = Math.abs(signedArea(b.outer));
    const r = minRect(b.outer);
    const short = r ? Math.min(r.u1 - r.u0, r.v1 - r.v0) : 0;
    const wantGable = t['roof:shape'] === 'gabled' || (!t['roof:shape'] && seed < 0.62 && t.building !== 'retail');
    const tower = isChurch && short < 10;
    if (r && !b.holes.length && area / r.area > 0.84 && short > 4 && short < 26 && (wantGable || isChurch) && !tower) {
      let { ux, uz, vx, vz, u0, u1, v0, v1 } = r;
      if (u1 - u0 < v1 - v0) { [ux, uz, vx, vz] = [vx, vz, -ux, -uz]; [u0, u1, v0, v1] = [v0, v1, -u1, -u0]; }
      const e = 0.4, rise = (v1 - v0) * (isChurch ? 0.45 : 0.28);
      const W = (u, v, y) => new THREE.Vector3(u * ux + v * vx, y, u * uz + v * vz);
      const vm = (v0 + v1) / 2, yE = top - 0.12, yR = top + rise;
      const A = W(u0 - e, v0 - e, yE - e * 0.5), B = W(u1 + e, v0 - e, yE - e * 0.5), C = W(u1 + e, vm, yR), D = W(u0 - e, vm, yR);
      const A2 = W(u0 - e, v1 + e, yE - e * 0.5), B2 = W(u1 + e, v1 + e, yE - e * 0.5);
      const slope = Math.hypot(vm - v0 + e, rise + e * 0.5), len = u1 - u0 + 2 * e;
      const ex = extraFn(2);
      // le due falde, orientate verso l'esterno
      const up = (p, q, s) => { const n = new THREE.Vector3().crossVectors(new THREE.Vector3().subVectors(q, p), new THREE.Vector3().subVectors(s, p)); return n.y > 0; };
      const tri = (p, q, s, uv) => (up(p, q, s) ? pushTri(acc, p, q, s, uv, ex) : pushTri(acc, p, s, q, [uv[0], uv[2], uv[1]], ex));
      tri(A, B, C, [[0, 0], [len, 0], [len, slope]]); tri(A, C, D, [[0, 0], [len, slope], [0, slope]]);
      tri(A2, B2, C, [[0, 0], [len, 0], [len, slope]]); tri(A2, C, D, [[0, 0], [len, slope], [0, slope]]);
      // timpani
      const ex3 = extraFn(3);
      const g1 = [W(u0, v0, top), W(u0, v1, top), W(u0, vm, yR)], g2 = [W(u1, v1, top), W(u1, v0, top), W(u1, vm, yR)];
      const out1 = W(-1, 0, 0), out2 = W(1, 0, 0);
      for (const [g, o] of [[g1, out1], [g2, out2]]) {
        const n = new THREE.Vector3().crossVectors(new THREE.Vector3().subVectors(g[1], g[0]), new THREE.Vector3().subVectors(g[2], g[0]));
        const uvs = [[0, 0], [v1 - v0, 0], [(v1 - v0) / 2, rise]];
        if (n.x * o.x + n.z * o.z > 0) pushTri(acc, g[0], g[1], g[2], uvs, ex3); else pushTri(acc, g[0], g[2], g[1], [uvs[0], uvs[2], uvs[1]], ex3);
      }
      pushCap(acc, b.outer, [], top - 0.05, 1, extraFn(1));
      if (!isChurch && seed > 0.2) {
        const nC = 1 + (seed * 10 | 0) % 2;
        for (let k = 0; k < nC; k++) {
          const uu = u0 + (u1 - u0) * (0.25 + 0.5 * ((seed * 7 + k * 0.37) % 1)), vv = vm + (v1 - v0) * 0.12 * (k % 2 ? 1 : -1);
          const p = W(uu, vv, 0);
          chimneys.push([p.x, top + rise * 0.62, p.z, Math.atan2(ux, uz)]);
        }
      }
    } else {
      pushCap(acc, b.outer, b.holes, top, 1, extraFn(tileCaps && !style ? 2 : 1));
    }

    // balconi in ferro: ballatoi lungo il lato lungo o balconcini sulle campate
    if (!isChurch && levels >= 3 && (t.building === 'apartments' || t.building === 'residential' || t.building === 'yes')) {
      const style = seed < 0.3 ? 'gallery' : seed < 0.75 ? 'single' : 'none';
      if (style !== 'none') {
        const ccw = signedArea(b.outer) > 0;
        const bay = 3.2 + seed * 0.9, groundH = shop ? 4.4 : 3.7;
        let u = 0, longest = 0;
        for (let i = 0; i < b.outer.length; i++) { const a = b.outer[i], c = b.outer[(i + 1) % b.outer.length]; longest = Math.max(longest, Math.hypot(c[0] - a[0], c[1] - a[1])); }
        for (let i = 0; i < b.outer.length; i++) {
          const a = b.outer[i], c = b.outer[(i + 1) % b.outer.length];
          const len = Math.hypot(c[0] - a[0], c[1] - a[1]);
          const [nx, nz] = outwardNormal(b.outer, i, ccw);
          const dx = (c[0] - a[0]) / len, dz = (c[1] - a[1]) / len;
          if (style === 'gallery' && len === longest && len > 8) {
            for (let fl = 0; fl < levels - 1; fl++) {
              const y = base + groundH + fl * floorH + 0.18 * floorH - 0.12;
              if (y + 1 > top) break;
              for (let s = 0.3; s < len - 0.3; s += 3) {
                const w = Math.min(3, len - 0.3 - s);
                balconies.push({ x: a[0] + dx * (s + w / 2) + nx * 0.6, y, z: a[1] + dz * (s + w / 2) + nz * 0.6, nx, nz, w, d: 1.2 });
              }
            }
          } else if (style === 'single' && len > 6) {
            for (let k = Math.ceil(u / bay - 0.5); (k + 0.5) * bay < u + len; k++) {
              const s = (k + 0.5) * bay - u;
              if (s < 1 || s > len - 1) continue;
              for (let fl = 0; fl < levels - 1; fl++) {
                if (((k * 7 + fl * 3 + (seed * 100 | 0)) % 5) > 1) continue;
                const y = base + groundH + fl * floorH + 0.18 * floorH - 0.12;
                if (y + 1.2 > top) continue;
                balconies.push({ x: a[0] + dx * s + nx * 0.45, y, z: a[1] + dz * s + nz * 0.45, nx, nz, w: 1.7, d: 0.9 });
              }
            }
          }
          u += len;
        }
      }
    }

    let cx = 0, cz = 0;
    for (const p of b.outer) { cx += p[0]; cz += p[1]; }
    cx /= b.outer.length; cz /= b.outer.length;
    let rad = 0;
    for (const p of b.outer) rad = Math.max(rad, Math.hypot(p[0] - cx, p[1] - cz));
    meta.push({ bid: b.bid, cx, cz, r: rad, top, floorH, shop, base });
  }
  const g = geometryFrom(acc, true);
  const driftU = { uDriftTex: { value: driftTex }, uDriftW: { value: DRIFT_TEX_W } };
  const mat = new THREE.MeshStandardMaterial({ roughness: 0.85, metalness: 0, envMapIntensity: 0.9 });
  if (lite) mat.defines = { VID_LITE: '' };
  injectBuilding(mat, env, driftU, false);
  const depth = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking });
  injectBuilding(depth, env, driftU, true);
  const mesh = new THREE.Mesh(g, mat);
  mesh.customDepthMaterial = depth;
  mesh.castShadow = true; mesh.receiveShadow = true;
  const idMat = new THREE.ShaderMaterial({ uniforms: driftU, vertexShader: ID_VERT, fragmentShader: ID_FRAG });
  const idMesh = new THREE.Mesh(g, idMat);
  mesh.frustumCulled = false; idMesh.frustumCulled = false;
  return { mesh, idMesh, meta, balconies, chimneys, lanterns };
}

// ---------- texture procedurale della ringhiera ----------
function railingTexture() {
  const c = document.createElement('canvas'); c.width = 128; c.height = 64;
  const g = c.getContext('2d');
  g.fillStyle = '#000'; g.fillRect(0, 0, 128, 64);
  g.fillStyle = '#fff';
  g.fillRect(0, 0, 128, 5); g.fillRect(0, 58, 128, 6); g.fillRect(0, 30, 128, 3);
  for (let x = 2; x < 128; x += 9) g.fillRect(x, 0, 3, 64);
  g.strokeStyle = '#fff'; g.lineWidth = 2;
  for (let x = 0; x < 128; x += 18) { g.beginPath(); g.arc(x + 9, 30, 6, 0, Math.PI * 2); g.stroke(); }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = THREE.RepeatWrapping;
  t.anisotropy = 8;
  return t;
}

function boxGeo(w, h, d, x = 0, y = 0, z = 0) { const g = new THREE.BoxGeometry(w, h, d); g.translate(x, y, z); return g; }
function merge(geos) {
  const out = { pos: [], nor: [], uv: [], idx: [] };
  let off = 0;
  for (const g of geos) {
    const p = g.attributes.position, n = g.attributes.normal, u = g.attributes.uv;
    for (let i = 0; i < p.count; i++) {
      out.pos.push(p.getX(i), p.getY(i), p.getZ(i)); out.nor.push(n.getX(i), n.getY(i), n.getZ(i));
      out.uv.push(u ? u.getX(i) : 0, u ? u.getY(i) : 0);
    }
    if (g.index) for (let i = 0; i < g.index.count; i++) out.idx.push(g.index.getX(i) + off);
    else for (let i = 0; i < p.count; i++) out.idx.push(i + off);
    off += p.count;
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(out.pos, 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(out.nor, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(out.uv, 2));
  g.setIndex(out.idx);
  return g;
}
export { merge as mergeGeometries, boxGeo };

function instanced(geo, mat, items, place, opts = {}) {
  if (!items.length) return null;
  const m = new THREE.InstancedMesh(geo, mat, items.length);
  const o = new THREE.Object3D();
  items.forEach((it, i) => { place(o, it, i); o.updateMatrix(); m.setMatrixAt(i, o.matrix); if (opts.color) m.setColorAt(i, opts.color(it, i)); });
  m.castShadow = opts.cast !== false; m.receiveShadow = true;
  m.instanceMatrix.needsUpdate = true;
  return m;
}

// ---------- città ----------
const ROAD_STYLE = {
  footway: ['#9a958d', 1, 0.05], pedestrian: ['#9d978c', 1, 0.05], path: ['#8f8778', 1, 0.05], steps: ['#9a9286', 1, 0.05],
  cycleway: ['#7a4a43', 0, 0.06], service: ['#5e5d61', 0, 0.07], living_street: ['#8a7a72', 3, 0.07]
};

function ribbon(acc, pts, width, y, color, kind) {
  const hw = width / 2;
  for (let i = 0; i < pts.length - 1; i++) {
    const [x1, z1] = pts[i], [x2, z2] = pts[i + 1];
    const dx = x2 - x1, dz = z2 - z1, len = Math.hypot(dx, dz);
    if (len < 0.01) continue;
    const nx = -dz / len * hw, nz = dx / len * hw;
    const ex = dx / len * hw * 0.5, ez = dz / len * hw * 0.5;
    const q = [[x1 - ex + nx, z1 - ez + nz], [x2 + ex + nx, z2 + ez + nz], [x2 + ex - nx, z2 + ez - nz], [x1 - ex - nx, z1 - ez - nz]];
    for (const k of [0, 1, 2, 0, 2, 3]) {
      acc.pos.push(q[k][0], y, q[k][1]); acc.nor.push(0, 1, 0);
      acc.col.push(color.r, color.g, color.b); acc.kind.push(kind);
    }
  }
}

function segDist(x, z, a, b) {
  const dx = b[0] - a[0], dz = b[1] - a[1], l2 = dx * dx + dz * dz || 1;
  const t = Math.max(0, Math.min(1, ((x - a[0]) * dx + (z - a[1]) * dz) / l2));
  return Math.hypot(x - a[0] - dx * t, z - a[1] - dz * t);
}

function facingWater(x, z, rings) {
  let best = null, bd = 25;
  for (const ring of rings) for (let i = 0; i < ring.length; i++) {
    const a = ring[i], b = ring[(i + 1) % ring.length];
    const d = segDist(x, z, a, b);
    if (d < bd) { bd = d; best = [a, b]; }
  }
  if (!best) return 0;
  const mx = (best[0][0] + best[1][0]) / 2, mz = (best[0][1] + best[1][1]) / 2;
  return Math.atan2(mx - x, mz - z);
}

function autoLamps(roads) {
  const out = [];
  for (const r of roads) {
    if (r.width < 6) continue;
    let acc = 0;
    for (let i = 0; i < r.pts.length - 1; i++) {
      const [x1, z1] = r.pts[i], [x2, z2] = r.pts[i + 1];
      const len = Math.hypot(x2 - x1, z2 - z1);
      for (let t = (30 - acc) % 30; t < len; t += 30) {
        const f = t / len, nx = -(z2 - z1) / len, nz = (x2 - x1) / len;
        out.push([x1 + (x2 - x1) * f + nx * (r.width / 2 + 0.6), z1 + (z2 - z1) * f + nz * (r.width / 2 + 0.6)]);
      }
      acc = (acc + len) % 30;
    }
  }
  return out;
}

export function buildCity(features, env, opts = {}) {
  const lite = !!opts.lite;
  const group = new THREE.Group();
  const n = features.buildings.length;
  const driftData = new Uint8Array(DRIFT_TEX_W * Math.max(1, Math.ceil(n / DRIFT_TEX_W)) * 4);
  const driftTex = new THREE.DataTexture(driftData, DRIFT_TEX_W, driftData.length / 4 / DRIFT_TEX_W, THREE.RGBAFormat);
  driftTex.needsUpdate = true;

  const B = buildBuildings(features, env, driftTex, lite, opts.palette ? opts.palette.map((h) => new THREE.Color(h)) : FACADE, !!opts.tileCaps);
  group.add(B.mesh);

  let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
  for (const m of B.meta) { minX = Math.min(minX, m.cx); maxX = Math.max(maxX, m.cx); minZ = Math.min(minZ, m.cz); maxZ = Math.max(maxZ, m.cz); }
  if (!isFinite(minX)) { minX = minZ = -200; maxX = maxZ = 200; }
  const extent = { minX: minX - 120, maxX: maxX + 120, minZ: minZ - 120, maxZ: maxZ + 120 };

  // terreno
  const gmat = groundMaterial(env);
  const ground = newAcc();
  const gc = new THREE.Color('#77746f');
  const [x0, x1, z0, z1] = [extent.minX - 900, extent.maxX + 900, extent.minZ - 900, extent.maxZ + 900];
  for (const [x, z] of [[x0, z0], [x1, z1], [x1, z0], [x0, z0], [x0, z1], [x1, z1]]) {
    ground.pos.push(x, 0, z); ground.nor.push(0, 1, 0); ground.col.push(gc.r, gc.g, gc.b); ground.kind.push(1);
  }
  const grass = new THREE.Color('#ffffff');
  for (const p of features.parks) pushCap(ground, p.outer, [], 0.03, 1, (a) => { a.col.push(grass.r, grass.g, grass.b); a.kind.push(4); });
  const plazaC = new THREE.Color('#a39c90');
  for (const p of features.plazas) pushCap(ground, p.outer, [], 0.035, 1, (a) => { a.col.push(plazaC.r, plazaC.g, plazaC.b); a.kind.push(1); });
  const groundMesh = new THREE.Mesh(geometryFrom(ground, false), gmat.clone());
  groundMesh.material.onBeforeCompile = gmat.onBeforeCompile;
  groundMesh.material.customProgramCacheKey = gmat.customProgramCacheKey;
  Object.assign(groundMesh.material, { stencilWrite: true, stencilRef: 1, stencilFunc: THREE.NotEqualStencilFunc,
    stencilFail: THREE.KeepStencilOp, stencilZFail: THREE.KeepStencilOp, stencilZPass: THREE.KeepStencilOp });
  groundMesh.renderOrder = -1;
  groundMesh.receiveShadow = true;
  group.add(groundMesh);

  // strade e marciapiedi
  const roadsAcc = newAcc();
  const asphalt = new THREE.Color('#66656a');
  const bridges = [];
  for (const r of features.roads) {
    const st = ROAD_STYLE[r.kind];
    const col = st ? new THREE.Color(st[0]) : asphalt;
    const y = r.bridge ? 0.32 : (st ? st[2] : 0.08 + Math.min(r.width, 14) * 0.002);
    if (!st && !r.bridge && r.width >= 6) ribbon(roadsAcc, r.pts, r.width + 4.4, 0.045, new THREE.Color('#99938a'), 1);
    // la pavimentazione vera, quando OpenStreetMap la conosce
    const sf = r.surface;
    const stoneKind = /^(sett|cobblestone|unhewn_cobblestone|cobblestone:flattened|pebblestone)$/.test(sf || '') ? 3 : /^(paving_stones|milanese_paving|concrete:plates)$/.test(sf || '') ? 1 : null;
    ribbon(roadsAcc, r.pts, r.width, y, stoneKind === 3 ? new THREE.Color('#7d6a62') : stoneKind === 1 ? new THREE.Color('#9d978c') : col, stoneKind ?? (st ? st[1] : 0));
    if (r.bridge) bridges.push(r);
  }
  const rail = new THREE.Color('#2b2a2c');
  for (const t of features.trams) ribbon(roadsAcc, t.pts, 1.6, 0.1, rail, 0);
  if (roadsAcc.pos.length) {
    const rm = new THREE.Mesh(geometryFrom(roadsAcc, false), gmat);
    rm.receiveShadow = true;
    group.add(rm);
  }

  // acqua
  const waterPos = [];
  const waterRings = [];
  const mask = newAcc();
  for (const w of features.water) {
    const wa = newAcc();
    pushCap(wa, w.outer, w.holes, WATER_LEVEL, 1, () => {});
    waterPos.push(...wa.pos);
    pushCap(mask, w.outer, w.holes, 0.01, 1, () => {});
    waterRings.push(w.outer);
  }
  for (const w of features.waterways) {
    if (features.water.length && w.kind !== 'stream') continue;
    const tmp = newAcc(); ribbon(tmp, w.pts, w.width, WATER_LEVEL, asphalt, 2); waterPos.push(...tmp.pos);
    const tm = newAcc(); ribbon(tm, w.pts, w.width, 0.01, asphalt, 0); mask.pos.push(...tm.pos);
  }
  let waterMat = null, waterMesh = null;
  if (waterPos.length) {
    const wg = new THREE.BufferGeometry(); wg.setAttribute('position', new THREE.Float32BufferAttribute(waterPos, 3));
    waterMat = new THREE.ShaderMaterial({ uniforms: Object.assign({}, env, opts.reflect || { tReflect: { value: null }, uReflMatrix: { value: new THREE.Matrix4() }, uReflOn: { value: 0 } }), vertexShader: WATER_VERT, fragmentShader: WATER_FRAG });
    waterMesh = new THREE.Mesh(wg, waterMat);
    group.add(waterMesh);
    const mg = new THREE.BufferGeometry(); mg.setAttribute('position', new THREE.Float32BufferAttribute(mask.pos, 3));
    const maskMesh = new THREE.Mesh(mg, new THREE.MeshBasicMaterial({
      colorWrite: false, depthWrite: false, stencilWrite: true, stencilRef: 1, stencilFunc: THREE.AlwaysStencilFunc,
      stencilZPass: THREE.ReplaceStencilOp, side: THREE.DoubleSide }));
    maskMesh.renderOrder = -2;
    group.add(maskMesh);
  }
  const banks = newAcc();
  const stone = new THREE.Color('#8b8173');
  for (const ring of waterRings) pushWalls(banks, ring, WATER_LEVEL - 0.3, 0.14, (a) => { a.col.push(stone.r, stone.g, stone.b); a.kind.push(1); }, true);
  if (banks.pos.length) {
    const bm = new THREE.Mesh(geometryFrom(banks, false), gmat);
    bm.receiveShadow = true;
    group.add(bm);
  }

  // ---------- arredo urbano ----------
  const props = new THREE.Group();
  group.add(props);
  const obstacles = [];
  const ironMat = new THREE.MeshStandardMaterial({ color: 0x1f2421, roughness: 0.55, metalness: 0.6 });
  const add = (m) => { if (m) props.add(m); };

  // balconi e ballatoi
  const railTex = railingTexture();
  // trasparenza morbida: da lontano la ringhiera diventa una velatura scura invece di sbriciolarsi in puntini
  const balconyRailMat = new THREE.MeshStandardMaterial({ color: 0x1d201e, roughness: 0.5, metalness: 0.6, alphaMap: railTex, transparent: true, alphaTest: 0.04, depthWrite: false, side: THREE.DoubleSide });
  const slabMat = new THREE.MeshStandardMaterial({ color: 0x9a948a, roughness: 0.85 });
  const slab = boxGeo(1, 0.12, 1);
  const railFront = new THREE.PlaneGeometry(1, 1); railFront.translate(0, 0.5, 0.5);
  const railSideL = new THREE.PlaneGeometry(1, 1); railSideL.rotateY(Math.PI / 2); railSideL.translate(-0.5, 0.5, 0);
  const railSideR = railSideL.clone(); railSideR.translate(1, 0, 0);
  const railGeo = merge([railFront, railSideL, railSideR]);
  const placeBalcony = (o, it) => { o.position.set(it.x, it.y, it.z); o.rotation.set(0, Math.atan2(it.nx, it.nz), 0); o.scale.set(it.w, 1, it.d); };
  add(instanced(slab, slabMat, B.balconies, placeBalcony));
  add(instanced(railGeo, balconyRailMat, B.balconies, (o, it) => { placeBalcony(o, it); o.position.y += 0.06; }));
  add(instanced(merge([boxGeo(0.7, 1.6, 0.7, 0, 0.8, 0), boxGeo(0.95, 0.15, 0.95, 0, 1.65, 0)]),
    new THREE.MeshStandardMaterial({ color: 0x9a6a55, roughness: 0.9 }), B.chimneys, (o, it) => { o.position.set(it[0], it[1], it[2]); o.rotation.y = it[3]; }));

  // lanterna di marmo in cima alle grandi cupole
  if (B.lanterns.length) {
    const marble = new THREE.MeshStandardMaterial({ color: 0xe8e3d6, roughness: 0.4 });
    const gold = new THREE.MeshStandardMaterial({ color: 0xd9b45a, roughness: 0.25, metalness: 1 });
    for (const [x, y, z, w] of B.lanterns) {
      const r = w * 0.13, h = w * 0.3;
      const g = new THREE.Group();
      const drum = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 1.1, h * 0.55, 8), marble); drum.position.y = h * 0.27;
      const cone = new THREE.Mesh(new THREE.ConeGeometry(r * 0.8, h * 0.45, 8), marble); cone.position.y = h * 0.55 + h * 0.22;
      const ball = new THREE.Mesh(new THREE.SphereGeometry(r * 0.22, 16, 12), gold); ball.position.y = h * 1.02;
      const cross = new THREE.Mesh(new THREE.BoxGeometry(r * 0.05, r * 0.5, r * 0.05), gold); cross.position.y = h * 1.02 + r * 0.45;
      g.add(drum, cone, ball, cross); g.position.set(x, y, z);
      g.traverse((m) => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
      props.add(g);
    }
  }

  // platani con la chioma che ondeggia
  const trees = features.trees;
  if (trees.length) {
    const trunk = new THREE.CylinderGeometry(0.17, 0.3, 4.2, 7); trunk.translate(0, 2.1, 0);
    const blobs = [];
    // chioma di platano: molte masse irregolari, più scure in basso e all'interno
    for (let k = 0; k < (lite ? 7 : 13); k++) {
      const a = k * 2.399, rr = k < 4 ? 0.6 : 1.9 + (k % 3) * 0.35;
      const s = 1.05 + ((k * 0.618) % 1) * 0.75;
      const ico = new THREE.IcosahedronGeometry(s, lite ? 1 : 2);
      const p = ico.attributes.position;
      for (let v = 0; v < p.count; v++) {
        const x = p.getX(v), y = p.getY(v), z = p.getZ(v);
        const n = 1 + 0.18 * Math.sin(x * 3.1 + k) * Math.sin(y * 2.7 + k * 1.3) * Math.sin(z * 3.3);
        p.setXYZ(v, x * n, y * n * 0.85, z * n);
      }
      ico.translate(Math.cos(a) * rr, 5.0 + (k % 4) * 0.7 + (k < 4 ? 1.6 : 0), Math.sin(a) * rr);
      blobs.push(ico);
    }
    const crownGeo = merge(blobs);
    crownGeo.computeVertexNormals();
    const cc = [], cp = crownGeo.attributes.position;
    for (let v = 0; v < cp.count; v++) {
      const y = cp.getY(v), r = Math.hypot(cp.getX(v), cp.getZ(v));
      const k = Math.min(1, 0.55 + (y - 3.8) * 0.12 + r * 0.06);
      cc.push(k, k, k);
    }
    crownGeo.setAttribute('color', new THREE.Float32BufferAttribute(cc, 3));
    const crownMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9, vertexColors: true });
    crownMat.onBeforeCompile = (shader) => {
      shader.uniforms.uTime = env.uTime;
      shader.vertexShader = shader.vertexShader.replace('#include <common>', '#include <common>\nuniform float uTime;')
        .replace('#include <begin_vertex>', `#include <begin_vertex>
          float ph = 0.0;
          #ifdef USE_INSTANCING
          ph = instanceMatrix[3].x * 0.13 + instanceMatrix[3].z * 0.17;
          #endif
          transformed.x += sin(uTime * 1.3 + ph + position.y) * 0.08 * max(position.y - 3.5, 0.0);
          transformed.z += cos(uTime * 1.1 + ph) * 0.06 * max(position.y - 3.5, 0.0);`);
    };
    crownMat.customProgramCacheKey = () => 'vid-crown';
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x8b8473, roughness: 0.9 });
    const placeT = (o, [x, z], i) => { const s = 0.8 + ((i * 0.6180339) % 1) * 0.45; o.position.set(x, 0, z); o.rotation.set(0, i * 2.4, 0); o.scale.set(s, s, s); };
    add(instanced(crownGeo, crownMat, trees, placeT, { color: (it, i) => new THREE.Color().setHSL(0.22 + ((i * 0.37) % 1) * 0.06, 0.42, 0.2 + ((i * 0.71) % 1) * 0.06) }));
    add(instanced(trunk, trunkMat, trees, placeT));
    for (const [x, z] of trees) obstacles.push({ c: [x, z], r: 0.35 });
  }

  // lampioni: palo in ghisa e lanterna
  const lampPos = features.lamps.length ? features.lamps : autoLamps(features.roads);
  const pole = merge([new THREE.CylinderGeometry(0.06, 0.11, 4.4, 8).translate(0, 2.2, 0), boxGeo(0.3, 0.25, 0.3, 0, 0.12, 0), new THREE.CylinderGeometry(0.03, 0.03, 0.5, 6).rotateZ(Math.PI / 2).translate(0.2, 4.3, 0)]);
  const lanternGeo = merge([new THREE.CylinderGeometry(0.18, 0.12, 0.42, 6).translate(0.42, 4.15, 0), new THREE.ConeGeometry(0.26, 0.2, 6).translate(0.42, 4.46, 0)]);
  const lanternMat = new THREE.MeshStandardMaterial({ color: 0x2a2a26, emissive: 0xffc37a, emissiveIntensity: 0, roughness: 0.4 });
  const placeL = (o, [x, z], i) => { o.position.set(x, 0, z); o.rotation.y = (i * 1.7) % 6.28; };
  add(instanced(pole, ironMat, lampPos, placeL));
  add(instanced(lanternGeo, lanternMat, lampPos, placeL, { cast: false }));
  for (const [x, z] of lampPos) obstacles.push({ c: [x, z], r: 0.18 });
  const lampHeads = lampPos.map(([x, z], i) => { const a = (i * 1.7) % 6.28; return [x + Math.cos(a) * 0.42, 4.1, z - Math.sin(a) * 0.42]; });

  // panchine rivolte verso l'acqua
  const benches = features.pois.filter((p) => p.kind === 'bench');
  if (benches.length) {
    const bench = merge([boxGeo(1.8, 0.07, 0.45, 0, 0.45, 0), boxGeo(1.8, 0.4, 0.06, 0, 0.75, -0.22), boxGeo(0.07, 0.45, 0.45, -0.8, 0.22, 0), boxGeo(0.07, 0.45, 0.45, 0.8, 0.22, 0)]);
    const wood = new THREE.MeshStandardMaterial({ color: 0x6b4a32, roughness: 0.8 });
    const items = benches.map((p) => ({ x: p.x, z: p.z, a: facingWater(p.x, p.z, waterRings) }));
    add(instanced(bench, wood, items, (o, it) => { o.position.set(it.x, 0, it.z); o.rotation.y = it.a; }));
    for (const it of items) obstacles.push({ c: [it.x, it.z], r: 0.6 });
  }

  // ringhiere lungo i canali, interrotte dove ci sono i ponti
  const railItems = [];
  const nearBridge = (x, z) => bridges.some((r) => r.pts.some((p, i) => i < r.pts.length - 1 && segDist(x, z, p, r.pts[i + 1]) < r.width / 2 + 1.2));
  for (const ring of waterRings) {
    const ccw = signedArea(ring) > 0;
    for (let i = 0; i < ring.length; i++) {
      const a = ring[i], b = ring[(i + 1) % ring.length];
      const len = Math.hypot(b[0] - a[0], b[1] - a[1]);
      const [nx, nz] = outwardNormal(ring, i, ccw);
      for (let s = 0; s < len; s += 2.4) {
        const w = Math.min(2.4, len - s);
        const x = a[0] + (b[0] - a[0]) * (s + w / 2) / len + nx * 0.35, z = a[1] + (b[1] - a[1]) * (s + w / 2) / len + nz * 0.35;
        if (nearBridge(x, z)) continue;
        railItems.push({ x, z, a: Math.atan2(b[0] - a[0], b[1] - a[1]), w });
      }
    }
  }
  add(instanced(merge([boxGeo(0.05, 0.05, 1, 0, 1.0, 0), boxGeo(0.04, 0.04, 1, 0, 0.55, 0), boxGeo(0.06, 1.0, 0.06, 0, 0.5, -0.48)]),
    ironMat, railItems, (o, it) => { o.position.set(it.x, 0.14, it.z); o.rotation.y = it.a; o.scale.set(1, 1, it.w); }, { cast: false }));

  // auto parcheggiate lungo le strade carrabili
  const cars = [], parkedMeshes = [], parkedSegs = [];
  let ci = 0;
  for (const r of features.roads) {
    if (r.bridge || !/^(residential|tertiary|secondary|unclassified|primary)$/.test(r.kind)) continue;
    for (let i = 0; i < r.pts.length - 1; i++) {
      const [ax, az] = r.pts[i], [bx, bz] = r.pts[i + 1];
      const len = Math.hypot(bx - ax, bz - az);
      const dx = (bx - ax) / len, dz = (bz - az) / len;
      for (const side of [-1, 1]) {
        for (let s = 6; s < len - 6; s += 5.4) {
          ci++;
          if (((Math.imul(ci, 2654435761)) >>> 0) % 100 > 58) continue;
          const off = r.width / 2 - 1.0;
          cars.push({ x: ax + dx * s - dz * off * side, z: az + dz * s + dx * off * side, a: Math.atan2(dx, dz) + (side > 0 ? Math.PI : 0), i: ci });
        }
      }
    }
  }
  if (cars.length) {
    // auto parcheggiate: stessa carrozzeria del traffico, vernice lucida con trasparente
    const cg = carGeometries();
    const PAINT = ['#8f1d1d', '#e7e4dc', '#22252b', '#5b6d78', '#7d7d78', '#1f3550', '#c9b27b', '#3e5b45', '#b8b8b2', '#5a2b33', '#f2f0ea', '#2c2c2e'].map((h) => new THREE.Color(h));
    for (const c of cars) c.color = '#' + PAINT[c.i % PAINT.length].getHexString();
    const place = (o, it) => { o.position.set(it.x, 0.08, it.z); o.rotation.y = it.a; };
    const addP = (m) => { if (m) parkedMeshes.push(m); add(m); };
    addP(instanced(cg.body, new THREE.MeshPhysicalMaterial({ roughness: 0.32, metalness: 0.55, clearcoat: 1, clearcoatRoughness: 0.08 }), cars, place, { color: (it) => PAINT[it.i % PAINT.length] }));
    addP(instanced(cg.glass, new THREE.MeshStandardMaterial({ color: 0x0c0f12, roughness: 0.05, metalness: 0.2 }), cars, place));
    addP(instanced(cg.wheels, new THREE.MeshStandardMaterial({ color: 0x141414, roughness: 0.85 }), cars, place));
    addP(instanced(cg.hubs, new THREE.MeshStandardMaterial({ color: 0x9a9ca0, roughness: 0.3, metalness: 0.9 }), cars, place, { cast: false }));
    addP(instanced(cg.trim, new THREE.MeshStandardMaterial({ color: 0x1a1a1c, roughness: 0.6 }), cars, place, { cast: false }));
    addP(instanced(cg.front, new THREE.MeshStandardMaterial({ color: 0xdedad0, roughness: 0.1 }), cars, place, { cast: false }));
    addP(instanced(cg.rear, new THREE.MeshStandardMaterial({ color: 0x7a0f10, roughness: 0.15 }), cars, place, { cast: false }));
    cars.forEach((c, k) => obstacles.push({ rect: [c.x, c.z, 0.95, 2.15, c.a], car: k }));
  }

  // barche ormeggiate
  const boats = [];
  for (const ring of waterRings) {
    const ccw = signedArea(ring) > 0;
    for (let i = 0; i < ring.length; i += 9) {
      const a = ring[i], b = ring[(i + 1) % ring.length];
      const len = Math.hypot(b[0] - a[0], b[1] - a[1]); if (len < 2) continue;
      const [nx, nz] = outwardNormal(ring, i, ccw);
      boats.push({ x: (a[0] + b[0]) / 2 - nx * 1.6, z: (a[1] + b[1]) / 2 - nz * 1.6, a: Math.atan2(b[0] - a[0], b[1] - a[1]), i });
    }
  }
  if (boats.length) {
    const hull = new THREE.CylinderGeometry(0.9, 0.55, 5.2, 10, 1, false, 0, Math.PI);
    hull.rotateX(Math.PI / 2); hull.rotateZ(Math.PI); hull.scale(1, 0.55, 1);
    const BOAT = ['#d8d2c4', '#2f5a6a', '#8a2e2a', '#e1c56a'].map((h) => new THREE.Color(h));
    add(instanced(hull, new THREE.MeshStandardMaterial({ roughness: 0.6, side: THREE.DoubleSide }), boats,
      (o, it) => { o.position.set(it.x, WATER_LEVEL + 0.25, it.z); o.rotation.set(0, it.a, 0); }, { color: (it) => BOAT[it.i % 4] }));
  }

  // fili e pali del tram
  if (features.trams.length) {
    const wires = [], poles = [];
    for (const t of features.trams) {
      let run = 0;
      for (let i = 0; i < t.pts.length - 1; i++) {
        const [ax, az] = t.pts[i], [bx, bz] = t.pts[i + 1];
        wires.push(ax, 6.1, az, bx, 6.1, bz);
        const len = Math.hypot(bx - ax, bz - az);
        if (len < 0.01) continue;
        // un palo ogni 32 m lungo tutta la linea, non a ogni tratto
        for (let s = (32 - run) % 32; s < len; s += 32) poles.push([ax + (bx - ax) * s / len - (bz - az) / len * 4.2, az + (bz - az) * s / len + (bx - ax) / len * 4.2]);
        run = (run + len) % 32;
      }
    }
    const wg = new THREE.BufferGeometry(); wg.setAttribute('position', new THREE.Float32BufferAttribute(wires, 3));
    props.add(new THREE.LineSegments(wg, new THREE.LineBasicMaterial({ color: 0x222222 })));
    add(instanced(new THREE.CylinderGeometry(0.1, 0.13, 6.6, 8).translate(0, 3.3, 0), ironMat, poles, (o, [x, z]) => o.position.set(x, 0, z)));
  }

  // fontane e giochi
  for (const p of features.pois) {
    if (p.kind === 'fountain') {
      const f = new THREE.Group();
      const stoneM = new THREE.MeshStandardMaterial({ color: 0xb8b0a2, roughness: 0.7, side: THREE.DoubleSide });
      const basin = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 3.4, 0.6, 32, 1, true), stoneM); basin.position.y = 0.3;
      const rim = new THREE.Mesh(new THREE.TorusGeometry(3.25, 0.16, 8, 40), stoneM); rim.rotation.x = Math.PI / 2; rim.position.y = 0.6;
      const colm = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.5, 2.4, 12), stoneM); colm.position.y = 1.2;
      const disk = new THREE.Mesh(new THREE.CircleGeometry(3.15, 32), new THREE.MeshStandardMaterial({ color: 0x2a3f40, roughness: 0.05, metalness: 0.2 })); disk.rotation.x = -Math.PI / 2; disk.position.y = 0.45;
      f.add(basin, rim, colm, disk); f.position.set(p.x, 0, p.z);
      f.traverse((m) => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
      props.add(f); obstacles.push({ c: [p.x, p.z], r: 3.4 });
    } else if (p.kind === 'playground') {
      const f = new THREE.Group();
      const pink = new THREE.MeshStandardMaterial({ color: 0xf2a7b8, roughness: 0.4 });
      const slide = new THREE.Mesh(boxGeo(0.8, 0.08, 4.2), pink); slide.rotation.x = 0.55; slide.position.set(0, 1.25, 1.6);
      const towerM = new THREE.Mesh(boxGeo(1.4, 2.4, 1.4, 0, 1.2, -0.6), new THREE.MeshStandardMaterial({ color: 0x8fd3c7, roughness: 0.5 }));
      const swing = new THREE.Mesh(merge([boxGeo(0.1, 2.6, 0.1, -1.4, 1.3, 0), boxGeo(0.1, 2.6, 0.1, 1.4, 1.3, 0), boxGeo(3, 0.1, 0.1, 0, 2.6, 0)]), ironMat); swing.position.set(4, 0, 0);
      f.add(slide, towerM, swing); f.position.set(p.x, 0, p.z);
      f.traverse((m) => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
      props.add(f); obstacles.push({ c: [p.x, p.z - 0.6], r: 1.1 });
    }
  }

  // collisioni: edifici, sponde, parapetti dei ponti, arredo
  const segs = [];
  for (const b of features.buildings) {
    if (b.minHeight > 2.2) continue;
    for (const ring of [b.outer, ...b.holes]) for (let i = 0; i < ring.length; i++) segs.push([ring[i], ring[(i + 1) % ring.length], 'b']);
  }
  for (const ring of waterRings) for (let i = 0; i < ring.length; i++) segs.push([ring[i], ring[(i + 1) % ring.length], 'w']);
  const parapet = newAcc(), stoneP = newAcc();
  const pcol = new THREE.Color('#2a2d2b');
  for (const r of bridges) {
    for (const side of [-1, 1]) {
      const pts = r.pts.map((p, i) => {
        const a = r.pts[Math.max(0, i - 1)], b = r.pts[Math.min(r.pts.length - 1, i + 1)];
        const dx = b[0] - a[0], dz = b[1] - a[1], l = Math.hypot(dx, dz) || 1;
        return [p[0] - dz / l * r.width / 2 * side, p[1] + dx / l * r.width / 2 * side];
      });
      for (let i = 0; i < pts.length - 1; i++) {
        if (opts.stoneParapets) {
          // spalletta di pietra piena, spessa 45 cm, con il suo coperchio
          const a = pts[i], b = pts[i + 1], L = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1, nx = -(b[1] - a[1]) / L * 0.22, nz = (b[0] - a[0]) / L * 0.22;
          const ring = [[a[0] + nx, a[1] + nz], [b[0] + nx, b[1] + nz], [b[0] - nx, b[1] - nz], [a[0] - nx, a[1] - nz]];
          const ex = (q) => { q.col.push(0.62, 0.57, 0.48); q.kind.push(1); };
          pushWalls(stoneP, ring, 0.3, 1.25, ex, false);
          pushCap(stoneP, ring, [], 1.25, 1, ex);
        } else pushWalls(parapet, [pts[i], pts[i + 1]], 0.3, 1.3, (a) => { a.col.push(pcol.r, pcol.g, pcol.b); a.kind.push(0); }, false, false);
        segs.push([pts[i], pts[i + 1], 'p']);
      }
    }
  }
  if (parapet.pos.length) {
    const pg = new THREE.BufferGeometry();
    pg.setAttribute('position', new THREE.Float32BufferAttribute(parapet.pos, 3));
    pg.setAttribute('normal', new THREE.Float32BufferAttribute(parapet.nor, 3));
    const uvs = [];
    for (let k = 0; k < parapet.fuv.length; k += 2) uvs.push(parapet.fuv[k] / 2.5, (parapet.fuv[k + 1]) / 1.0);
    pg.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    const pm = new THREE.Mesh(pg, new THREE.MeshStandardMaterial({ color: 0x2a2d2b, roughness: 0.5, metalness: 0.6, alphaMap: railTex, transparent: true, alphaTest: 0.04, depthWrite: false, side: THREE.DoubleSide }));
    pm.castShadow = true;
    group.add(pm);
  }
  if (stoneP.pos.length) { const sm = new THREE.Mesh(geometryFrom(stoneP, false), gmat); sm.castShadow = true; sm.receiveShadow = true; group.add(sm); }
  for (const o of obstacles) {
    if (o.rect) {
      const [x, z, hw, hl, a] = o.rect, c = Math.cos(a), s = Math.sin(a);
      const corner = (u, v) => [x + u * c + v * s, z - u * s + v * c];
      const q = [corner(-hw, -hl), corner(hw, -hl), corner(hw, hl), corner(-hw, hl)];
      if (o.car !== undefined) parkedSegs[o.car] = [segs.length, segs.length + 1, segs.length + 2, segs.length + 3];
      for (let i = 0; i < 4; i++) segs.push([q[i], q[(i + 1) % 4], 'o']);
    } else {
      const [x, z] = o.c, r = o.r;
      const q = [[x - r, z - r], [x + r, z - r], [x + r, z + r], [x - r, z + r]];
      for (let i = 0; i < 4; i++) segs.push([q[i], q[(i + 1) % 4], 'o']);
    }
  }

  const buildingRings = features.buildings.filter((b) => b.minHeight <= 2.2).map((b) => b.outer);
  return {
    group, buildings: B, driftTex, driftData, extent, segs, bridges, waterRings, waterMat, waterMesh, buildingRings,
    lamps: { positions: lampPos, heads: lampHeads, lanternMat }, waterLevel: WATER_LEVEL,
    parked: { cars, meshes: parkedMeshes, segs: parkedSegs }
  };
}

export { pointInRing };
