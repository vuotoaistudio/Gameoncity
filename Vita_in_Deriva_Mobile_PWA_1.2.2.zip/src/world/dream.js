// Soglie e luoghi del sogno: porte che compaiono sui palazzi alla deriva e spazi liminali
// (piscine, corridoio d'albergo, cameretta gigante) dove si trova un ricordo.
import * as THREE from 'three';
import { mergeGeometries, boxGeo } from './cityMesh.js';

export const RICORDI = [
  ['Biglietto del tram', 'Sul retro, a matita: «aspettami al ponte, anche se piove». Non c\'è scritto chi doveva arrivare.'],
  ['Una chiave senza portachiavi', 'Apre una porta che hanno murato quando il canale è stato coperto.'],
  ['Cartolina della Darsena', 'Il francobollo è stato staccato con cura. Restano solo i saluti: «qui tutto uguale, tranne noi».'],
  ['Una cassetta registrata dalla radio', 'Alla fine della canzone, per tre secondi, si sente qualcuno ridere in cucina.'],
  ['Un gettone del telefono', 'Era l\'ultimo, quello del bar sotto casa. Non l\'hai mai usato.'],
  ['Uno scontrino di un bar', 'Due caffè, una brioche. Uno dei due caffè non è stato bevuto.'],
  ['Un disegno a pastello', 'Una casa di ringhiera con tutte le finestre accese. Sotto c\'è scritto «la mia».'],
  ['Una conchiglia', 'Trovata in un cortile, lontanissimo dal mare. Se l\'avvicini all\'orecchio senti il tram.'],
  ['Un orologio da polso fermo', 'Segna le 18:40. A quell\'ora, d\'inverno, si accendevano i lampioni sull\'alzaia.'],
  ['La foto di una piscina vuota', 'Agosto, piscina comunale. Il bordo è ancora bagnato, ma non c\'è nessuno.'],
  ['Un mazzo di chiavi della scuola', 'Una porta in fondo al corridoio non l\'ha mai aperta nessuno.'],
  ['Una candelina di compleanno', 'È spenta da sempre, eppure è ancora calda.'],
  ['Una lettera mai spedita', 'Comincia con «Ti ricordi quando la nebbia era così fitta che» e si interrompe.'],
  ['Un biglietto del cinema all\'aperto', 'Il film non lo ricordi. Ricordi le zanzare e una mano vicina alla tua.'],
  ['Una lampadina del pianerottolo', 'Per anni, salendo al buio, hai contato i gradini: diciannove.'],
  ['Un sasso piatto', 'Perfetto per i rimbalzi. Il canale era troppo calmo per lanciarlo.'],
  ['Una ricetta scritta a mano', 'Manca l\'ultimo ingrediente. Chi la scriveva lo sapeva a memoria.'],
  ['Il cartellino di un cappotto smarrito', 'Qualcuno l\'ha cercato per tutto l\'inverno.']
];

const HASH = 'float h1(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }';

// materiale standard con motivo procedurale in coordinate del mondo
function patterned(kind, color, rough, extra = {}) {
  const m = new THREE.MeshStandardMaterial(Object.assign({ color, roughness: rough, metalness: 0 }, extra));
  m.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWP; varying vec3 vWN;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvWP = (modelMatrix * vec4(position, 1.0)).xyz; vWN = normalize(mat3(modelMatrix) * normal);');
    const body = {
      tile: `vec2 q = abs(vWN.y) > 0.5 ? vWP.xz : (abs(vWN.x) > 0.5 ? vWP.zy : vWP.xy);
        vec2 f = fract(q / 0.2); float g = step(0.06, f.x) * step(0.06, f.y);
        float var = h1(floor(q / 0.2));
        vec3 c = diffuseColor.rgb * (0.94 + 0.08 * var);
        if (var > 0.97) c = mix(c, vec3(0.55, 0.82, 0.8), 0.6);
        diffuseColor.rgb = mix(vec3(0.62, 0.64, 0.62), c, g);`,
      carpet: `vec2 q = vWP.xz / 0.9; vec2 f = fract(q) - 0.5; vec2 i = floor(q);
        float dia = step(abs(f.x) + abs(f.y), 0.32); float ring = step(0.36, abs(f.x) + abs(f.y)) * step(abs(f.x) + abs(f.y), 0.42);
        vec3 c = vec3(0.32, 0.07, 0.09);
        c = mix(c, vec3(0.75, 0.55, 0.2), ring);
        c = mix(c, mod(i.x + i.y, 2.0) > 0.5 ? vec3(0.08, 0.3, 0.32) : vec3(0.45, 0.12, 0.14), dia);
        diffuseColor.rgb = c * (0.9 + 0.1 * h1(floor(vWP.xz * 30.0)));`,
      wallpaper: `float x = abs(vWN.x) > 0.5 ? vWP.z : vWP.x;
        float s = step(0.5, fract(x / 0.36));
        vec3 c = mix(vec3(0.86, 0.78, 0.66), vec3(0.8, 0.7, 0.6), s);
        vec2 dot2 = fract(vec2(x, vWP.y) / 0.36) - 0.5; c = mix(c, vec3(0.6, 0.34, 0.36), step(length(dot2), 0.06) * (1.0 - s));
        if (vWP.y < 0.9) c = vec3(0.42, 0.28, 0.2) * (0.9 + 0.1 * step(0.5, fract(vWP.y * 8.0)));
        diffuseColor.rgb = c;`,
      parquet: `vec2 q = vWP.xz * vec2(4.0, 0.9) / 3.0; q.y += floor(q.x) * 0.37; vec2 f = fract(q);
        float g = step(0.04, f.x) * step(0.02, f.y);
        diffuseColor.rgb = mix(vec3(0.25, 0.15, 0.08), vec3(0.62, 0.42, 0.25) * (0.85 + 0.25 * h1(floor(q))), g);`,
      pastel: `float s = step(0.5, fract((abs(vWN.x) > 0.5 ? vWP.z : vWP.x) / 1.6));
        diffuseColor.rgb = mix(vec3(0.95, 0.78, 0.82), vec3(0.78, 0.88, 0.95), s) * (0.92 + 0.08 * h1(floor(vWP.xy * 2.0)));`
    }[kind];
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vWP; varying vec3 vWN;\n${HASH}`)
      .replace('#include <color_fragment>', '#include <color_fragment>\n{' + body + '}');
  };
  m.customProgramCacheKey = () => 'vid-pattern-' + kind;
  return m;
}

const poolWaterMat = () => new THREE.ShaderMaterial({
  uniforms: { uTime: { value: 0 } },
  transparent: true, depthWrite: false,
  vertexShader: 'varying vec3 vW; void main(){ vec4 w = modelMatrix * vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }',
  fragmentShader: `uniform float uTime; varying vec3 vW;
    void main(){
      vec2 p = vW.xz * 1.3;
      float c = 0.0;
      for (int i = 0; i < 3; i++) { float fi = float(i); c += sin(p.x * (1.0 + fi) + uTime * (0.8 + fi * 0.3) + sin(p.y * (1.3 + fi) + uTime)) ; }
      c = pow(abs(c) / 3.0, 3.0);
      vec3 col = mix(vec3(0.25, 0.75, 0.82), vec3(0.85, 1.0, 1.0), c);
      gl_FragColor = vec4(col * 1.25, 0.82);
    }`
});

function rand(seed) { let s = seed >>> 0 || 1; return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296); }

// ---------- spazio a celle: pavimenti, soffitti, muri dove la cella vicina è vuota ----------
function buildCells(o, cells, cs, H, mats, opts = {}) {
  const group = new THREE.Group();
  const segs = [];
  const key = (i, j) => i + ',' + j;
  const floors = [], ceils = [], walls = [], poolFloors = [], poolWalls = [], water = [];
  const P = (i, j) => [o.x + i * cs, o.z + j * cs];
  for (const [k, c] of cells) {
    const [i, j] = k.split(',').map(Number);
    const [x, z] = P(i, j);
    const fl = c.pool ? -1.4 : 0;
    const plane = (y, up) => { const g = new THREE.PlaneGeometry(cs, cs); g.rotateX(up ? -Math.PI / 2 : Math.PI / 2); g.translate(x + cs / 2, y, z + cs / 2); return g; };
    (c.pool ? poolFloors : floors).push(plane(fl, true));
    ceils.push(plane(H, false));
    if (c.pool) water.push(plane(-0.32, true));
    const nb = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    for (const [di, dj] of nb) {
      const n = cells.get(key(i + di, j + dj));
      // muro sul bordo della cella
      const ax = di === 1 ? x + cs : di === -1 ? x : x, az = dj === 1 ? z + cs : dj === -1 ? z : z;
      const bx = di !== 0 ? ax : x + cs, bz = dj !== 0 ? az : z + cs;
      const a = di !== 0 ? [ax, z] : [x, az], b = di !== 0 ? [ax, z + cs] : [x + cs, az];
      const wall = (y0, y1, list) => {
        const len = cs, g = new THREE.PlaneGeometry(len, y1 - y0);
        g.translate(0, (y0 + y1) / 2, 0);
        // la faccia guarda verso l'interno della cella
        g.rotateY(di === 1 ? -Math.PI / 2 : di === -1 ? Math.PI / 2 : dj === 1 ? Math.PI : 0);
        g.translate((a[0] + b[0]) / 2, 0, (a[1] + b[1]) / 2);
        list.push(g);
      };
      if (!n) { wall(c.pool ? -1.4 : 0, H, walls); segs.push([a, b, 'd']); }
      else if (c.pool && !n.pool) { wall(-1.4, 0, poolWalls); }
      if (n && !c.pool && n.pool) segs.push([a, b, 'o']);
      void bx; void bz;
    }
  }
  const mk = (geos, mat) => { if (!geos.length) return; const m = new THREE.Mesh(mergeGeometries(geos), mat); m.receiveShadow = true; group.add(m); return m; };
  mk(floors, mats.floor); mk(ceils, mats.ceil); mk(walls, mats.wall);
  mk(poolFloors, mats.wall); mk(poolWalls, mats.wall);
  let waterMesh = null;
  if (water.length) { waterMesh = new THREE.Mesh(mergeGeometries(water), poolWaterMat()); group.add(waterMesh); }
  return { group, segs, waterMesh };
}

function lightPanels(o, cells, cs, H, every, color) {
  const geos = [], pts = [];
  let n = 0;
  for (const k of cells.keys()) {
    if ((n++ % every) !== 0) continue;
    const [i, j] = k.split(',').map(Number);
    const g = new THREE.PlaneGeometry(cs * 0.45, cs * 0.45); g.rotateX(Math.PI / 2); g.translate(o.x + i * cs + cs / 2, H - 0.02, o.z + j * cs + cs / 2);
    geos.push(g); pts.push([o.x + i * cs + cs / 2, H - 0.5, o.z + j * cs + cs / 2]);
  }
  const m = new THREE.Mesh(mergeGeometries(geos), new THREE.MeshStandardMaterial({ color: 0x111111, emissive: color, emissiveIntensity: 2.4 }));
  return { mesh: m, points: pts };
}

// ---------- i tre luoghi ----------
function piscine(o, seed) {
  const r = rand(seed);
  const cs = 2, R = 7, N = 3, H = 5;
  const cells = new Map();
  const rooms = [];
  for (let a = 0; a < N; a++) for (let b = 0; b < N; b++) {
    rooms.push({ a, b });
    for (let i = 0; i < R; i++) for (let j = 0; j < R; j++) cells.set((a * (R + 1) + i) + ',' + (b * (R + 1) + j), {});
  }
  // aperture fra stanze vicine: albero casuale + qualche anello
  const open = (a1, b1, a2, b2) => {
    const mid = Math.floor(R / 2);
    if (a1 !== a2) { const i = Math.max(a1, a2) * (R + 1) - 1; for (const j of [mid, mid + 1]) cells.set(i + ',' + (b1 * (R + 1) + j - 1), {}); }
    else { const j = Math.max(b1, b2) * (R + 1) - 1; for (const i of [mid, mid + 1]) cells.set((a1 * (R + 1) + i - 1) + ',' + j, {}); }
  };
  const seen = new Set(['0,0']), stack = [[0, 0]];
  const dist = { '0,0': 0 };
  while (stack.length) {
    const [a, b] = stack[stack.length - 1];
    const nb = [[a + 1, b], [a - 1, b], [a, b + 1], [a, b - 1]].filter(([x, y]) => x >= 0 && y >= 0 && x < N && y < N && !seen.has(x + ',' + y));
    if (!nb.length) { stack.pop(); continue; }
    const [x, y] = nb[Math.floor(r() * nb.length)];
    open(a, b, x, y); seen.add(x + ',' + y); dist[x + ',' + y] = dist[a + ',' + b] + 1; stack.push([x, y]);
  }
  if (r() < 0.7) open(1, 1, 2, 1);
  // vasche in alcune stanze
  for (const rm of rooms) {
    if (rm.a === 0 && rm.b === 0) continue;
    if (r() < 0.6) for (let i = 2; i < R - 2; i++) for (let j = 1; j < R - 1; j++) cells.set((rm.a * (R + 1) + i) + ',' + (rm.b * (R + 1) + j), { pool: true });
  }
  let far = '0,0';
  for (const k in dist) if (dist[k] > dist[far]) far = k;
  const [fa, fb] = far.split(',').map(Number);
  const center = (a, b) => [o.x + (a * (R + 1) + R / 2) * cs, o.z + (b * (R + 1) + R / 2) * cs];
  const tileWhite = patterned('tile', 0xeef2ef, 0.25);
  const tileCeil = patterned('tile', 0xf4f4f0, 0.6);
  const built = buildCells(o, cells, cs, H, { floor: tileWhite, wall: tileWhite, ceil: tileCeil });
  const lights = lightPanels(o, new Map([...cells].filter(([, c]) => !c.pool)), cs, H, 7, 0xe8fbff);
  built.group.add(lights.mesh);
  // nel bordo della vasca lontana, il ricordo; la porta d'uscita sul muro opposto
  const [rx, rz] = center(fa, fb);
  const [sx, sz] = center(0, 0);
  return {
    ...built, lights: lights.points, lightColor: 0xdff6ff, lightPower: 14, surface: 'piastrelle', H,
    spawn: [sx - 3, sz, -Math.PI / 2 - 0.6],
    ricordo: [rx - 5.5, 0, rz - 5.5], exit: { x: rx + R - 0.06, z: rz, ny: 0, nx: -1 },
    fog: [0.86, 0.95, 0.96], fogDensity: 0.02, name: 'Le piscine'
  };
}

function corridoio(o, seed) {
  const r = rand(seed);
  const cs = 3, H = 2.7;
  const cells = new Map();
  let i = 0, j = 0, dir = 0, lastMove = [0, 1];
  const dirs = [[0, 1], [1, 0], [0, -1], [-1, 0]];
  cells.set('0,0', {});
  const path = [[0, 0]];
  for (let seg = 0; seg < 5; seg++) {
    const run = 5 + Math.floor(r() * 8);
    for (let k = 0; k < run; k++) {
      const ni = i + dirs[dir][0], nj = j + dirs[dir][1];
      if (cells.has(ni + ',' + nj) || [...cells.keys()].some((kk) => { const [a, b] = kk.split(',').map(Number); return Math.abs(a - ni) + Math.abs(b - nj) === 1 && !(a === i && b === j); })) break;
      i = ni; j = nj; cells.set(i + ',' + j, {}); path.push([i, j]); lastMove = dirs[dir];
    }
    dir = (dir + (r() < 0.5 ? 1 : 3)) % 4;
  }
  // stanza in fondo
  const [ei, ej] = path[path.length - 1];
  const rc = [ei + lastMove[0] * 2, ej + lastMove[1] * 2];
  for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) cells.set((rc[0] + a) + ',' + (rc[1] + b), { room: true });
  const carpet = patterned('carpet', 0xffffff, 0.95), paper = patterned('wallpaper', 0xffffff, 0.85);
  const built = buildCells(o, cells, cs, H, { floor: carpet, wall: paper, ceil: new THREE.MeshStandardMaterial({ color: 0xe6dcc8, roughness: 0.9 }) });
  const lights = lightPanels(o, cells, cs, H, 3, 0xffe2b0);
  lights.mesh.material.emissiveIntensity = 1.3;
  built.group.add(lights.mesh);
  // porte numerate lungo i muri (non si aprono)
  const doorMat = new THREE.MeshStandardMaterial({ color: 0x5a3a2a, roughness: 0.6 });
  const doors = [];
  path.forEach(([pi, pj], k) => {
    if (k % 2 || k === 0) return;
    for (const [di, dj] of dirs) {
      if (cells.has((pi + di) + ',' + (pj + dj))) continue;
      const g = boxGeo(1.0, 2.1, 0.08); g.rotateY(di !== 0 ? Math.PI / 2 : 0);
      g.translate(o.x + pi * cs + cs / 2 + di * (cs / 2 - 0.05), 1.05, o.z + pj * cs + cs / 2 + dj * (cs / 2 - 0.05));
      doors.push(g); break;
    }
  });
  if (doors.length) built.group.add(new THREE.Mesh(mergeGeometries(doors), doorMat));
  const cx = o.x + rc[0] * cs + cs / 2, cz = o.z + rc[1] * cs + cs / 2;
  return {
    ...built, lights: lights.points, lightColor: 0xffd9a0, lightPower: 4, surface: 'moquette', H,
    spawn: [o.x + cs / 2, o.z + cs / 2, Math.PI],
    ricordo: [cx, 0, cz], exit: { x: cx + cs * 1.5 - 0.05, z: cz, nx: -1, ny: 0 },
    fog: [0.28, 0.2, 0.15], fogDensity: 0.035, name: 'Il corridoio'
  };
}

function cameretta(o) {
  const W = 16, D = 12, H = 8;
  const group = new THREE.Group();
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(W, D).rotateX(-Math.PI / 2).translate(o.x + W / 2, 0, o.z + D / 2), patterned('parquet', 0xffffff, 0.6));
  const ceil = new THREE.Mesh(new THREE.PlaneGeometry(W, D).rotateX(Math.PI / 2).translate(o.x + W / 2, H, o.z + D / 2), new THREE.MeshStandardMaterial({ color: 0x2a2f55, roughness: 1 }));
  const wallMat = patterned('pastel', 0xffffff, 0.9);
  const walls = [];
  const segs = [];
  const corners = [[o.x, o.z], [o.x + W, o.z], [o.x + W, o.z + D], [o.x, o.z + D]];
  for (let k = 0; k < 4; k++) {
    const a = corners[k], b = corners[(k + 1) % 4];
    const len = Math.hypot(b[0] - a[0], b[1] - a[1]);
    const g = new THREE.PlaneGeometry(len, H); g.translate(0, H / 2, 0);
    g.rotateY(-Math.atan2(b[1] - a[1], b[0] - a[0]) + Math.PI);
    g.translate((a[0] + b[0]) / 2, 0, (a[1] + b[1]) / 2);
    walls.push(g); segs.push([a, b, 'd']);
  }
  const wallMesh = new THREE.Mesh(mergeGeometries(walls), wallMat); wallMesh.material.side = THREE.DoubleSide;
  group.add(floor, ceil, wallMesh);
  floor.receiveShadow = true;
  // mobili giganti: letto, armadio, scrivania, cubi dei giochi
  const furn = (w, h, d, x, z, color, rot = 0) => {
    const m = new THREE.Mesh(boxGeo(w, h, d, 0, h / 2, 0), new THREE.MeshStandardMaterial({ color, roughness: 0.7 }));
    m.position.set(o.x + x, 0, o.z + z); m.rotation.y = rot; m.castShadow = true; m.receiveShadow = true; group.add(m);
    const c = Math.cos(rot), s = Math.sin(rot), hw = w / 2, hd = d / 2;
    const q = [[-hw, -hd], [hw, -hd], [hw, hd], [-hw, hd]].map(([u, v]) => [o.x + x + u * c + v * s, o.z + z - u * s + v * c]);
    for (let k = 0; k < 4; k++) segs.push([q[k], q[(k + 1) % 4], 'o']);
    return m;
  };
  furn(5.5, 1.6, 8, 3.2, 4.4, 0x8fa6d6);
  furn(5.5, 0.9, 2, 3.2, 1.0, 0xf2f0ea).position.y = 1.6;
  furn(4, 6.5, 2, 13.6, 1.4, 0xb08a64);
  furn(5, 2.6, 2.6, 12.8, 9.6, 0xc9a07a);
  [[8, 3, 0xf2a7b8], [9.4, 3.6, 0x8fd3c7], [8.7, 2.2, 0xf6d58e]].forEach(([x, z, c], k) => furn(1.2, 1.2, 1.2, x, z, c, k * 0.4));
  // televisore a tubo con l'effetto neve
  const tvMat = new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 } },
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
    fragmentShader: `uniform float uTime; varying vec2 vUv;
      float h(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233)) + uTime * 7.0) * 43758.5453); }
      void main(){ float n = h(floor(vUv * vec2(160.0, 120.0))); float scan = 0.85 + 0.15 * sin(vUv.y * 400.0 + uTime * 20.0);
        gl_FragColor = vec4(vec3(n) * scan * 1.6, 1.0); }`
  });
  const tvBody = furn(2.2, 1.7, 1.8, 12.8, 9.3, 0x2b2b2e); tvBody.position.y = 2.6;
  const screen = new THREE.Mesh(new THREE.PlaneGeometry(1.7, 1.25), tvMat); screen.position.set(o.x + 12.8, 2.6 + 0.85, o.z + 9.3 - 0.91); screen.rotation.y = Math.PI;
  group.add(screen);
  // finestra: cielo rosa del tramonto che non finisce
  const win = new THREE.Mesh(new THREE.PlaneGeometry(4, 3.4), new THREE.ShaderMaterial({
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
    fragmentShader: 'varying vec2 vUv; void main(){ vec3 a = vec3(1.6,0.7,0.8), b = vec3(0.5,0.6,1.3); vec3 c = mix(a, b, vUv.y); float f = step(0.04, fract(vUv.x * 2.0)) * step(0.04, fract(vUv.y * 2.0)); gl_FragColor = vec4(mix(vec3(0.95), c, f), 1.0); }'
  }));
  win.position.set(o.x + 8, 4.2, o.z + 0.02); group.add(win);
  // stelle fluorescenti sul soffitto
  const sp = [];
  for (let k = 0; k < 90; k++) sp.push(o.x + Math.random() * W, H - 0.05, o.z + Math.random() * D);
  const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.Float32BufferAttribute(sp, 3));
  group.add(new THREE.Points(sg, new THREE.PointsMaterial({ color: 0xc8ffd8, size: 0.25 })));
  return {
    group, segs, waterMesh: null, tvMat, lights: [[o.x + 8, 5, o.z + 6], [o.x + 12.8, 3.5, o.z + 7.8]], lightColor: 0xffc9d6, lightPower: 10, surface: 'pietra', H,
    spawn: [o.x + 8, o.z + D - 1.5, 0],
    ricordo: [o.x + 6.5, 0, o.z + 9], exit: { x: o.x + 4, z: o.z + D - 0.05, nx: 0, ny: -1 },
    fog: [0.55, 0.42, 0.55], fogDensity: 0.02, name: 'La cameretta'
  };
}

// il cortile dell'infanzia: ballatoi, lenzuola stese, una luna enorme. Cielo aperto.
function cortile(o) {
  const W = 22, H = 17, group = new THREE.Group(), segs = [];
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(W, W).rotateX(-Math.PI / 2).translate(o.x + W / 2, 0, o.z + W / 2), patterned('tile', 0x8d8a84, 0.7));
  floor.receiveShadow = true; group.add(floor);
  const wallMat = new THREE.MeshStandardMaterial({ color: 0xe0b88a, roughness: 0.9, side: THREE.DoubleSide });
  const winMat = new THREE.MeshStandardMaterial({ color: 0x111111, emissive: 0xffc88a, emissiveIntensity: 1.6 });
  const iron = new THREE.MeshStandardMaterial({ color: 0x1d201e, roughness: 0.5, metalness: 0.6 });
  const corners = [[o.x, o.z], [o.x + W, o.z], [o.x + W, o.z + W], [o.x, o.z + W]];
  const wins = [], slabs = [], rails = [];
  for (let k = 0; k < 4; k++) {
    const a = corners[k], b = corners[(k + 1) % 4];
    const dx = (b[0] - a[0]) / W, dz = (b[1] - a[1]) / W, nx = -dz, nz = dx; // verso l'interno
    const g = new THREE.PlaneGeometry(W, H); g.translate(0, H / 2, 0); g.rotateY(Math.atan2(nx, nz)); g.translate((a[0] + b[0]) / 2, 0, (a[1] + b[1]) / 2);
    group.add(new THREE.Mesh(g, wallMat)); segs.push([a, b, 'd']);
    for (let fl = 0; fl < 5; fl++) {
      const y = 0.4 + fl * 3.2;
      if (fl > 0) {
        const sl = new THREE.BoxGeometry(W - 0.4, 0.12, 1.3); sl.rotateY(Math.atan2(nx, nz)); sl.translate((a[0] + b[0]) / 2 + nx * 0.65, y, (a[1] + b[1]) / 2 + nz * 0.65); slabs.push(sl);
        const rl = new THREE.BoxGeometry(W - 0.4, 0.05, 0.05); rl.rotateY(Math.atan2(nx, nz)); rl.translate((a[0] + b[0]) / 2 + nx * 1.28, y + 1.0, (a[1] + b[1]) / 2 + nz * 1.28); rails.push(rl);
      }
      for (let i = 1; i < 7; i++) {
        if ((i * 3 + fl * 5 + k) % 4 === 0) continue;
        const w = new THREE.PlaneGeometry(1.0, 1.6); w.translate(0, 0.8, 0); w.rotateY(Math.atan2(nx, nz));
        w.translate(a[0] + dx * i * W / 7 + nx * 0.02, y + 0.5, a[1] + dz * i * W / 7 + nz * 0.02); wins.push(w);
      }
    }
  }
  group.add(new THREE.Mesh(mergeGeometries(wins), winMat), new THREE.Mesh(mergeGeometries(slabs), wallMat), new THREE.Mesh(mergeGeometries(rails), iron));
  // lenzuola stese tra i ballatoi
  const sheetMat = new THREE.MeshStandardMaterial({ color: 0xf6f2ea, roughness: 0.9, side: THREE.DoubleSide });
  const sheets = [];
  for (let k = 0; k < 7; k++) {
    const sh = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 1.9, 1, 4), sheetMat);
    sh.position.set(o.x + 4 + k * 2.3, 5.5 + (k % 3) * 3.2, o.z + 6 + (k % 2) * 9); sh.userData.ph = k;
    group.add(sh); sheets.push(sh);
  }
  // la luna
  const moon = new THREE.Mesh(new THREE.CircleGeometry(9, 48), new THREE.MeshBasicMaterial({ color: 0xffe6f0, fog: false }));
  moon.position.set(o.x + W / 2, 48, o.z - 30); moon.lookAt(o.x + W / 2, 0, o.z + W / 2);
  group.add(moon);
  return {
    group, segs, waterMesh: null, sheets, lights: [[o.x + W / 2, 6, o.z + W / 2], [o.x + 4, 3, o.z + 4]], lightColor: 0xffd0e0, lightPower: 12, surface: 'pietra', H,
    spawn: [o.x + W / 2, o.z + W - 2, 0], ricordo: [o.x + W / 2, 0, o.z + W / 2 - 2], exit: { x: o.x + W / 2, z: o.z + W - 0.06, nx: 0, ny: -1 },
    fog: [0.42, 0.32, 0.5], fogDensity: 0.012, name: 'Il cortile', openSky: true, nora: [o.x + W / 2, o.z + W / 2 - 2]
  };
}

// ---------- gestore ----------
export class DreamManager {
  constructor(scene, collision) {
    this.scene = scene; this.col = collision;
    this.spaces = new Map();
    this.active = null;     // spazio in cui ci si trova
    this.threshold = null;  // porta che compare sul palazzo alla deriva
    this.doorMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uOpen: { value: 0 } },
      transparent: true, depthWrite: false, side: THREE.DoubleSide,
      vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
      fragmentShader: `uniform float uTime, uOpen; varying vec2 vUv;
        void main(){
          vec2 c = vUv - vec2(0.5, 0.45);
          float frame = step(0.06, vUv.x) * step(vUv.x, 0.94) * step(vUv.y, 0.95);
          vec3 a = vec3(1.5, 0.9, 1.1), b = vec3(0.7, 1.3, 1.4);
          vec3 col = mix(a, b, vUv.y + 0.15 * sin(uTime * 0.7 + vUv.x * 3.0));
          float pulse = 0.85 + 0.15 * sin(uTime * 2.0);
          float alpha = frame * (0.75 + 0.25 * pulse);
          if (frame < 0.5) { col = vec3(0.95, 0.92, 0.88); alpha = 1.0; }
          gl_FragColor = vec4(col * (1.0 + uOpen), alpha);
        }`
    });
    this.door = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 2.7), this.doorMat);
    this.door.visible = false;
    scene.add(this.door);
    this.exitDoor = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 2.7), this.doorMat);
    this.exitDoor.visible = false;
    scene.add(this.exitDoor);
    this.ricordoObj = this._ricordoMesh();
    this.ricordoObj.visible = false;
    scene.add(this.ricordoObj);
    this.lights = [];
  }

  _ricordoMesh() {
    const g = new THREE.Group();
    const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.16, 0), new THREE.MeshStandardMaterial({ color: 0xfff2e6, emissive: 0xffd9b0, emissiveIntensity: 3 }));
    const halo = new THREE.Mesh(new THREE.TorusGeometry(0.32, 0.012, 6, 40), new THREE.MeshBasicMaterial({ color: 0xffe9d6 }));
    g.add(core, halo);
    g.userData = { core, halo };
    return g;
  }

  // cerca un palazzo molto alla deriva vicino al giocatore e ci mette una porta
  updateThreshold(drift, features, pos, now, ease = 0) {
    if (this.active) { this.door.visible = false; return null; }
    if (this.threshold && this.threshold.special) return this.threshold;
    if (this.threshold && (drift.drift[this.threshold.bid] < 0.4 || drift.anchored[this.threshold.bid])) this.threshold = null;
    if (!this.threshold && (!this.nextSearch || now > this.nextSearch)) {
      this.nextSearch = now + 1500;
      let best = null, bd = 30;
      for (const m of drift.city.buildings.meta) {
        const i = m.bid;
        if (drift.anchored[i] || drift.drift[i] < 0.65 - ease || (!ease && !drift.isAnomalyVisible(i)) || m.base > 1) continue;
        const d = Math.hypot(m.cx - pos.x, m.cz - pos.z) - m.r;
        if (d < bd && d > 2) { bd = d; best = i; }
      }
      if (best !== null) {
        const b = features.buildings[best];
        const bp = this._doorOn(b, pos);
        if (bp) this.threshold = { bid: best, x: bp.px + bp.nx * 0.06, z: bp.pz + bp.nz * 0.06, nx: bp.nx, nz: bp.nz };
      }
    }
    const t = this.threshold;
    this.door.visible = !!t;
    if (t) { this.door.position.set(t.x, 1.35, t.z); this.door.rotation.set(0, Math.atan2(t.nx, t.nz), 0); }
    return t;
  }

  // punto della facciata più vicino al giocatore, solo su lati che danno davvero sulla strada
  // (le case a schiera hanno muri in comune: lì una porta porterebbe dentro il palazzo accanto)
  _doorOn(b, pos) {
    let bp = null, bdist = Infinity;
    const ring = b.outer;
    let area = 0;
    for (let k = 0; k < ring.length; k++) { const a = ring[k], c = ring[(k + 1) % ring.length]; area += a[0] * c[1] - c[0] * a[1]; }
    const ccw = area > 0;
    for (let k = 0; k < ring.length; k++) {
      const a = ring[k], c = ring[(k + 1) % ring.length];
      const len = Math.hypot(c[0] - a[0], c[1] - a[1]); if (len < 2.5) continue;
      const dx = (c[0] - a[0]) / len, dz = (c[1] - a[1]) / len;
      const nx = ccw ? dz : -dz, nz = ccw ? -dx : dx;
      let t = (pos.x - a[0]) * dx + (pos.z - a[1]) * dz; t = Math.max(1, Math.min(len - 1, t));
      const px = a[0] + dx * t, pz = a[1] + dz * t, dd = Math.hypot(px - pos.x, pz - pos.z);
      if ((pos.x - px) * nx + (pos.z - pz) * nz < 0.5) continue;
      if (!this.col.isFree(px + nx * 1.6, pz + nz * 1.6)) continue;
      if (dd < bdist) { bdist = dd; bp = { px, pz, nx, nz }; }
    }
    return bp;
  }

  // l'ultima porta: compare su un palazzo preciso (il campanile)
  forceThreshold(b, pos, special) {
    if (this.active) return null;
    if (this.threshold && this.threshold.special === special) return this.threshold;
    const bp = this._doorOn(b, pos);
    if (!bp) return null;
    this.threshold = { bid: b.bid, x: bp.px + bp.nx * 0.06, z: bp.pz + bp.nz * 0.06, nx: bp.nx, nz: bp.nz, special };
    this.door.visible = true;
    this.door.position.set(this.threshold.x, 1.35, this.threshold.z); this.door.rotation.set(0, Math.atan2(bp.nx, bp.nz), 0);
    return this.threshold;
  }

  near(pos, target, r = 3) { return target && Math.hypot(pos.x - target.x, pos.z - target.z) < r; }

  space(bid, special) {
    const k = special ? special + bid : bid;
    if (this.spaces.has(k)) return this.spaces.get(k);
    const o = special ? { x: 40000, z: 40000 } : { x: 20000 + (bid % 40) * 300, z: 20000 + Math.floor(bid / 40) * 300 };
    const seed = bid * 7919 + 13;
    const kind = special || ['piscine', 'corridoio', 'cameretta'][bid % 3];
    const s = kind === 'cortile' ? cortile(o) : kind === 'piscine' ? piscine(o, seed) : kind === 'corridoio' ? corridoio(o, seed) : cameretta(o);
    s.kind = kind; s.bid = bid;
    s.ricordoIndex = (bid * 31 + 7) % RICORDI.length;
    s.group.visible = false;
    this.scene.add(s.group);
    this.col.add(s.segs);
    this.spaces.set(k, s);
    return s;
  }

  enter(bid, special) {
    const s = this.space(bid, special);
    this.active = s; s.group.visible = true;
    s.taken = false;
    this.ricordoObj.visible = !s.nora;
    this.ricordoObj.position.set(s.ricordo[0], s.ricordo[1] + 1.1, s.ricordo[2]);
    this.exitDoor.visible = false;
    this.door.visible = false;
    return s;
  }

  openExit() {
    const s = this.active; if (!s) return;
    s.taken = true;
    const e = s.exit;
    this.exitDoor.visible = true;
    this.exitDoor.position.set(e.x, 1.35, e.z);
    this.exitDoor.rotation.set(0, Math.atan2(e.nx, e.ny), 0);
  }

  takeRicordo() {
    const s = this.active;
    if (!s || s.taken) return null;
    s.taken = true;
    this.ricordoObj.visible = false;
    const e = s.exit;
    this.exitDoor.visible = true;
    this.exitDoor.position.set(e.x, 1.35, e.z);
    this.exitDoor.rotation.set(0, Math.atan2(e.nx, e.ny), 0);
    return RICORDI[s.ricordoIndex];
  }

  leave() {
    const s = this.active;
    if (s) s.group.visible = false;
    this.active = null;
    this.exitDoor.visible = false; this.ricordoObj.visible = false;
    this.threshold = null;
    return s;
  }

  update(dt, t) {
    this.doorMat.uniforms.uTime.value = t;
    if (this.ricordoObj.visible) {
      this.ricordoObj.rotation.y += dt * 0.8;
      this.ricordoObj.userData.halo.rotation.x = t * 0.6;
      this.ricordoObj.position.y += Math.sin(t * 1.6) * 0.002;
    }
    const s = this.active;
    if (s) {
      if (s.waterMesh) s.waterMesh.material.uniforms.uTime.value = t;
      if (s.tvMat) s.tvMat.uniforms.uTime.value = t;
      if (s.sheets) for (const sh of s.sheets) { sh.rotation.y = Math.sin(t * 0.8 + sh.userData.ph) * 0.25; sh.rotation.x = Math.sin(t * 1.1 + sh.userData.ph) * 0.08; }
    }
  }
}
