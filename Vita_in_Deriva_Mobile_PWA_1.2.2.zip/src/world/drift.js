// Deriva: ciò che nessuno guarda scivola nel sogno. Ciò che fotografi resta reale.
import * as THREE from 'three';
import { DRIFT_TEX_W } from './cityMesh.js';

export const ANOMALIES = [
  'un piano in più',
  'finestre che non tornano',
  'colori che non ricordi',
  'una facciata cieca',
  'luci accese senza motivo'
];
const TYPE_WEIGHTS = [0.3, 0.2, 0.2, 0.15, 0.15];
const ID_W = 160, ID_H = 90;
const BASE_RATE = 1 / 240; // piena deriva in circa 4 minuti fuori vista

export class DriftSystem {
  constructor(city) {
    this.city = city;
    const n = city.buildings.meta.length;
    this.n = n;
    this.drift = new Float32Array(n);
    this.type = new Uint8Array(n);
    this.anchored = new Uint8Array(n);
    this.flash = new Float32Array(n);
    this.pixels = new Uint16Array(n);
    this.idScene = new THREE.Scene();
    this.idScene.add(city.buildings.idMesh);
    this.rt = new THREE.WebGLRenderTarget(ID_W, ID_H, { depthBuffer: true });
    this.buf = new Uint8Array(ID_W * ID_H * 4);
    this.rng = 1;
    this.visibleRange = 400;
    this.avg = 0;
  }

  rand() { this.rng = (this.rng * 16807) % 2147483647; return this.rng / 2147483647; }

  pickType(i) {
    let r = (this.rand() + this.city.buildings.meta[i].cx * 0.0137) % 1;
    for (let k = 0; k < TYPE_WEIGHTS.length; k++) { if (r < TYPE_WEIGHTS[k]) return k; r -= TYPE_WEIGHTS[k]; }
    return 0;
  }

  // Versione senza blocchi: la GPU risponde quando è pronta, niente scatti
  sampleAsync(renderer, camera) {
    if (this.pending) return;
    this._renderIds(renderer, camera);
    this.pending = true;
    const pos = camera.position.clone();
    renderer.readRenderTargetPixelsAsync(this.rt, 0, 0, ID_W, ID_H, this.buf)
      .then(() => { this._count(pos); })
      .catch(() => {})
      .finally(() => { this.pending = false; });
  }

  _renderIds(renderer, camera) {
    const prevClear = renderer.getClearColor(new THREE.Color()), prevAlpha = renderer.getClearAlpha();
    const prevTarget = renderer.getRenderTarget();
    renderer.setRenderTarget(this.rt);
    renderer.setClearColor(0x000000, 1);
    renderer.clear();
    renderer.render(this.idScene, camera);
    renderer.setRenderTarget(prevTarget);
    renderer.setClearColor(prevClear, prevAlpha);
  }

  _count(cam) {
    this.pixels.fill(0);
    const meta = this.city.buildings.meta, range2 = this.visibleRange * this.visibleRange;
    for (let p = 0; p < this.buf.length; p += 4) {
      const id = this.buf[p] + this.buf[p + 1] * 256 + this.buf[p + 2] * 65536;
      if (id > 0 && id <= this.n) this.pixels[id - 1]++;
    }
    for (let i = 0; i < this.n; i++) {
      if (!this.pixels[i]) continue;
      const m = meta[i], dx = m.cx - cam.x, dz = m.cz - cam.z;
      if (dx * dx + dz * dz > range2) this.pixels[i] = 0;
    }
  }

  // Passaggio di identificazione sincrono: solo per lo scatto, quando serve la risposta subito
  sample(renderer, camera) {
    this._renderIds(renderer, camera);
    renderer.readRenderTargetPixels(this.rt, 0, 0, ID_W, ID_H, this.buf);
    this._count(camera.position);
  }

  update(dt, rateMul) {
    const data = this.city.driftData;
    let sum = 0, near = 0;
    for (let i = 0; i < this.n; i++) {
      if (this.anchored[i]) { this.drift[i] = 0; }
      else if (this.pixels[i] < 2) {
        if (this.drift[i] === 0) this.type[i] = this.pickType(i);
        const v = 0.6 + (this.city.buildings.meta[i].cz * 0.031 % 1 + 1) % 1 * 0.8;
        this.drift[i] = Math.min(1, this.drift[i] + BASE_RATE * rateMul * v * dt);
      }
      if (this.flash[i] > 0) this.flash[i] = Math.max(0, this.flash[i] - dt / 1.4);
      const o = i * 4;
      data[o] = Math.round(this.drift[i] * 255);
      data[o + 1] = this.type[i];
      data[o + 2] = this.anchored[i] * 255;
      data[o + 3] = Math.round(this.flash[i] * 255);
      if (this.pixels[i]) { sum += this.drift[i]; near++; }
    }
    this.avg = near ? sum / near : 0;
    this.city.driftTex.needsUpdate = true;
  }

  isAnomalyVisible(i) {
    const d = this.drift[i], t = this.type[i];
    if (t === 0) return Math.floor(d * 3.4) >= 1;
    if (t === 4) return d > 0.2;
    return d > 0.3;
  }

  // Scatto: restituisce gli edifici inquadrati in modo significativo
  framed(minPixels) {
    const out = [];
    for (let i = 0; i < this.n; i++) if (this.pixels[i] >= minPixels) out.push({ bid: i, px: this.pixels[i] });
    out.sort((a, b) => b.px - a.px);
    return out;
  }

  anchor(bids, withFlash) {
    for (const b of bids) {
      if (b < 0 || b >= this.n) continue;
      this.anchored[b] = 1;
      this.drift[b] = 0;
      if (withFlash) this.flash[b] = 1;
    }
  }

  release(bids) { for (const b of bids) if (b >= 0 && b < this.n) this.anchored[b] = 0; }

  anchoredList() { const l = []; for (let i = 0; i < this.n; i++) if (this.anchored[i]) l.push(i); return l; }
}
