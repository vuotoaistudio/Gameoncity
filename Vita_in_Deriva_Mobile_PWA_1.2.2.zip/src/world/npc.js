// La gente della città: passanti che camminano sui marciapiedi, persone ferme con un ruolo,
// e i personaggi della storia. Modelli leggeri (5 pezzi, un solo materiale) per reggere anche sul telefono.
import * as THREE from 'three';
import { OPTIONS } from '../player/avatar.js';
import { limbGeo, pelvisGeo, torsoGeo, garmentExtras, coatSkirtGeo, skullGeo, faceParts, hairGeos, hatGeos, handGeo, shoeGeos } from '../player/human.js';
import { bark } from '../systems/story.js';
import { loc } from '../systems/locale.js';

// fumetto sopra la testa: testo a capo, bordo morbido; rosa se la frase è strana, rosso se è un insulto
function bubbleSprite(text, tone) {
  text = loc(text);
  const c = document.createElement('canvas'); c.width = 512; c.height = 160;
  const g = c.getContext('2d');
  g.font = '500 28px Karla, "Helvetica Neue", Arial, sans-serif';
  const words = text.split(' '), lines = []; let line = '';
  for (const w of words) { const t = line ? line + ' ' + w : w; if (g.measureText(t).width > 440 && line) { lines.push(line); line = w; } else line = t; }
  lines.push(line);
  const L = lines.slice(0, 3), h = 26 + L.length * 34;
  g.fillStyle = tone === 'rude' ? 'rgba(60,14,14,0.86)' : tone === 'strange' ? 'rgba(40,18,40,0.86)' : 'rgba(14,14,18,0.82)';
  g.beginPath(); g.roundRect(8, 160 - h - 14, 496, h, 18); g.fill();
  g.beginPath(); g.moveTo(240, 146); g.lineTo(256, 158); g.lineTo(272, 146); g.fill();
  g.fillStyle = tone === 'rude' ? '#ffb0a0' : tone === 'strange' ? '#f2b8c6' : '#eee9e2';
  g.textAlign = 'center'; g.textBaseline = 'top';
  L.forEach((l, i) => g.fillText(l, 256, 160 - h - 14 + 13 + i * 34));
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false }));
  sp.scale.set(3.2, 1.0, 1); sp.renderOrder = 9;
  return sp;
}

// un solo materiale per tutta la folla: colori nei vertici, un velo di "sheen" da tessuto
const MAT = new THREE.MeshPhysicalMaterial({ vertexColors: true, roughness: 0.8, metalness: 0, sheen: 0.6, sheenRoughness: 0.7, sheenColor: new THREE.Color(0.35, 0.33, 0.31) });
const C = (h) => new THREE.Color(h);

function colored(geo, color) {
  const g = geo.index ? geo.toNonIndexed() : geo;
  const c = new THREE.Color(color), n = g.attributes.position.count, arr = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { arr[i * 3] = c.r; arr[i * 3 + 1] = c.g; arr[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  g.deleteAttribute('uv');
  return g;
}
function mergeColored(list) {
  let n = 0; for (const g of list) n += g.attributes.position.count;
  const pos = new Float32Array(n * 3), nor = new Float32Array(n * 3), col = new Float32Array(n * 3);
  let o = 0;
  for (const g of list) {
    pos.set(g.attributes.position.array, o * 3); nor.set(g.attributes.normal.array, o * 3); col.set(g.attributes.color.array, o * 3);
    o += g.attributes.position.count;
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  g.computeBoundingSphere();
  return g;
}
const T = (g, x, y, z) => { g.translate(x, y, z); return g; };

function rng(seed) { let s = seed >>> 0 || 1; return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296); }

// aspetto per ruolo
function lookFor(role, r) {
  const pick = (a) => a[Math.floor(r() * a.length)];
  const skin = pick(OPTIONS.skin);
  const muted = ['#3b3f46', '#5b4a3c', '#2f3a4a', '#6b5b4a', '#4a4f3e', '#7a6a5a', '#2a2a2e', '#8a7a68', '#5a2f30', '#405a66'];
  const L = { skin, hairStyle: pick(['corti', 'corti', 'lunghi', 'raccolti', 'ricci', 'rasati']), hair: pick(OPTIONS.hairColor.slice(0, 5)), top: pick(muted), bottom: pick(['#22252b', '#3a4a66', '#5b4636', '#2b2b2b', '#6b6458']), shoes: '#1b1a19',
    coat: r() < 0.35, hat: null, backpack: null, hood: false, phones: false, scale: 0.92 + r() * 0.14, width: 0.9 + r() * 0.25 };
  if (role === 'anziano') { L.hair = pick(['#bdbdbd', '#d8d8d8', '#8e8e8e']); L.coat = true; L.hat = r() < 0.5 ? '#4a3f35' : null; L.scale *= 0.96; }
  if (role === 'rider') { L.top = pick(['#1fb5a8', '#f28c28', '#e3d23a']); L.backpack = L.top; L.hat = '#222'; }
  if (role === 'turista') { L.top = pick(['#e8e2d0', '#a8d0e6', '#f2b8c6', '#ffffff']); L.hat = pick(['#e8d9a8', '#3a6a9a', null]); L.backpack = '#3a3a3a'; }
  if (role === 'studente') { L.top = pick(['#6a3a8a', '#2a5a3a', '#8a2a2a', '#3a3a6a']); L.backpack = pick(['#222', '#4a2a2a']); L.phones = r() < 0.6; L.coat = false; }
  if (role === 'impiegato') { L.top = pick(['#1f2430', '#2a2a2a', '#3a3f4a']); L.bottom = L.top; L.coat = r() < 0.6; }
  if (role === 'cameriere') { L.top = '#f2efe8'; L.bottom = '#141414'; L.apron = true; L.coat = false; }
  if (role === 'musicista') { L.top = pick(['#6a4a2a', '#2a4a5a']); L.hat = '#2a2a2a'; L.instrument = true; }
  if (role === 'pusher') { L.top = pick(['#141414', '#1c2026', '#2a2a2a']); L.hood = true; L.bottom = '#1a1a1a'; L.coat = false; }
  if (role === 'senzatetto') { L.top = '#5a5040'; L.bottom = '#3a3428'; L.coat = true; L.hat = '#3a3a3a'; L.sitting = true; }
  if (role === 'vigile') { L.top = '#1b2740'; L.bottom = '#1b2740'; L.hat = '#f2f2f2'; L.coat = false; L.backpack = null; L.phones = false; L.scale = 1.02; }
  return L;
}

function buildModel(L) {
  const w = L.width;
  const skinC = new THREE.Color(L.skin);
  const lips = skinC.clone().multiply(new THREE.Color(0.86, 0.6, 0.6));
  const roleColor = { skin: L.skin, eye: '#f0ede7', iris: '#2a1c12', lips, brow: L.hair };
  // stessi giunti del giocatore: anche a 0.95, colonna a 1.03, testa a 1.82, spalle a 1.585
  const core = [colored(T(pelvisGeo(w), 0, 0.95, 0), L.bottom), colored(T(torsoGeo(w, L.coat ? 'cappotto' : L.hood ? 'felpa' : 'giacca'), 0, 1.03, 0), L.top)];
  for (const g of garmentExtras(w, L.coat ? 'cappotto' : L.hood ? 'felpa' : 'giacca')) core.push(colored(T(g, 0, 1.03, 0), L.top));
  if (L.coat) core.push(colored(T(coatSkirtGeo(w), 0, 0.95, 0), L.top));
  const HY = 1.82;
  core.push(colored(T(skullGeo(), 0, HY, 0), L.skin));
  for (const p of faceParts()) core.push(colored(T(p.geo, 0, HY, 0), roleColor[p.role] || L.skin));
  if (!L.hood) for (const g of hairGeos(L.hairStyle || 'corti')) core.push(colored(T(g, 0, HY, 0), L.hair));
  if (L.hood) core.push(colored((() => { const g = new THREE.SphereGeometry(0.148, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.62); g.scale(1, 1.05, 1.05); return T(g, 0, HY - 0.01, -0.025); })(), L.top));
  if (L.apron) core.push(colored(T(new THREE.BoxGeometry(0.3 * w, 0.55, 0.02), 0, 0.85, 0.13), '#1a1a1a'));
  if (L.hat) core.push(colored((() => { const g = new THREE.CylinderGeometry(0.128, 0.128, 0.06, 16); return T(g, 0, HY + 0.12, 0.005); })(), L.hat), colored(T(new THREE.BoxGeometry(0.2, 0.015, 0.1), 0, HY + 0.095, 0.12), L.hat));
  if (L.backpack) core.push(colored((() => { const g = new THREE.SphereGeometry(0.2, 12, 10); g.scale(0.85, 1.1, 0.6); return T(g, 0, 1.36, -0.2); })(), L.backpack));
  if (L.phones) for (const g of hatGeos('cuffie')) core.push(colored(T(g, 0, HY, 0), '#e8e2d6'));
  if (L.instrument) core.push(colored((() => { const g = new THREE.BoxGeometry(0.42, 0.34, 0.14); g.rotateZ(0.3); return T(g, 0.05, 1.25, 0.2); })(), '#7a4a2a'));
  // braccio intero (spalla, gomito, mano) e gamba intera (coscia, stinco, scarpa)
  const arm = (s) => { const parts = [colored(limbGeo(0.3, 0.054 * Math.sqrt(w), 0.045, 0.16, 10), L.top), colored(T(limbGeo(0.265, 0.045, 0.036, 0.12, 10), 0, -0.3, 0), L.top)];
    for (const g of handGeo()) { if (s < 0) g.rotateY(Math.PI); parts.push(colored(T(g, 0, -0.575, 0), L.skin)); }
    return mergeColored(parts); };
  const leg = () => { const sg = shoeGeos(); const parts = [colored(limbGeo(0.44, 0.084 * Math.sqrt(w), 0.06, 0.1, 10), L.bottom), colored(T(limbGeo(0.42, 0.06, 0.045, 0.16, 10), 0, -0.44, 0), L.bottom)];
    for (const g of sg.upper) parts.push(colored(T(g, 0, -0.835, 0), L.shoes));
    for (const g of sg.sole) parts.push(colored(T(g, 0, -0.835, 0), '#dcd8cf'));
    return mergeColored(parts); };
  const root = new THREE.Group();
  const coreM = new THREE.Mesh(mergeColored(core), MAT);
  const aL = new THREE.Mesh(arm(-1), MAT), aR = new THREE.Mesh(arm(1), MAT);
  const lL = new THREE.Mesh(leg(), MAT), lR = new THREE.Mesh(leg(), MAT);
  aL.position.set(-0.2 * w, 1.585, 0); aR.position.set(0.2 * w, 1.585, 0);
  lL.position.set(-0.095 * w, 0.91, 0); lR.position.set(0.095 * w, 0.91, 0);
  root.add(coreM, aL, aR, lL, lR);
  root.scale.setScalar(L.scale);
  root.rotation.order = 'YXZ'; // per cadere all'indietro rispetto a dove guarda
  return { root, parts: { core: coreM, aL, aR, lL, lR }, meshes: [coreM, aL, aR, lL, lR] };
}

// ---------- marciapiedi come percorsi ----------
const SIDE_STYLE = new Set(['footway', 'pedestrian', 'path', 'steps', 'living_street', 'cycleway']);
function offsetLine(pts, d) {
  return pts.map((p, i) => {
    const a = pts[Math.max(0, i - 1)], b = pts[Math.min(pts.length - 1, i + 1)];
    const dx = b[0] - a[0], dz = b[1] - a[1], l = Math.hypot(dx, dz) || 1;
    return [p[0] - dz / l * d, p[1] + dx / l * d];
  });
}
function buildPaths(roads, col) {
  const paths = [];
  const push = (pts) => {
    // spezza dove il percorso entra in un edificio o nell'acqua
    let cur = [];
    const dense = [];
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i], b = pts[i + 1], len = Math.hypot(b[0] - a[0], b[1] - a[1]);
      const n = Math.max(1, Math.ceil(len / 4));
      for (let k = 0; k < n; k++) dense.push([a[0] + (b[0] - a[0]) * k / n, a[1] + (b[1] - a[1]) * k / n]);
    }
    dense.push(pts[pts.length - 1]);
    for (const p of dense) {
      if (col.isFree(p[0], p[1]) || col.onBridge(p[0], p[1])) cur.push(p);
      else { if (cur.length > 3) paths.push(cur); cur = []; }
    }
    if (cur.length > 3) paths.push(cur);
  };
  for (const r of roads) {
    if (r.pts.length < 2) continue;
    if (r.bridge) { push(r.pts); continue; }
    if (SIDE_STYLE.has(r.kind)) { push(offsetLine(r.pts, Math.min(1.4, r.width / 4))); push(offsetLine(r.pts, -Math.min(1.4, r.width / 4)).reverse()); }
    else if (r.width >= 6) { push(offsetLine(r.pts, r.width / 2 + 1.3)); push(offsetLine(r.pts, -(r.width / 2 + 1.3)).reverse()); }
  }
  for (const p of paths) {
    p.len = [0];
    for (let i = 1; i < p.length; i++) p.len.push(p.len[i - 1] + Math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1]));
    p.total = p.len[p.len.length - 1];
  }
  return paths.filter((p) => p.total > 8);
}
function pointAt(path, d) {
  d = Math.max(0, Math.min(path.total, d));
  let i = 1; while (i < path.len.length - 1 && path.len[i] < d) i++;
  const a = path[i - 1], b = path[i], t = (d - path.len[i - 1]) / ((path.len[i] - path.len[i - 1]) || 1);
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, Math.atan2(b[0] - a[0], b[1] - a[1])];
}

const WALK_ROLES = [['passante', 6], ['anziano', 1.6], ['rider', 1], ['turista', 1.2], ['studente', 1.6], ['impiegato', 1.4]];
function pickRole(r) {
  let t = r() * WALK_ROLES.reduce((s, x) => s + x[1], 0);
  for (const [k, w] of WALK_ROLES) { if (t < w) return k; t -= w; }
  return 'passante';
}
const SPEED = { passante: 1.35, anziano: 0.85, rider: 2.1, turista: 1.0, studente: 1.45, impiegato: 1.55 };
// macchia scura sotto chi è a terra dopo una rissa
const BLOOD_GEO = new THREE.CircleGeometry(0.32, 14).rotateX(-Math.PI / 2);
const BLOOD_MAT = new THREE.MeshBasicMaterial({ color: 0x3a0608, transparent: true, opacity: 0.7, depthWrite: false });

export class Crowd {
  constructor(scene, features, collision, shops, opts = {}) {
    this.scene = scene; this.col = collision;
    this.r = rng(4242);
    this.paths = buildPaths(features.roads, collision);
    this.npcs = [];
    this.group = new THREE.Group();
    scene.add(this.group);
    const count = this.paths.length ? (opts.count || 30) : 0;
    for (let i = 0; i < count; i++) this.npcs.push(this._walker(i));
    this._statics(features, shops);
    this.t = 0; this.shadowT = 0;
  }

  _spawnModel(role, seed, extra) {
    const L = lookFor(role, rng(seed));
    Object.assign(L, extra || {});
    const m = buildModel(L);
    this.group.add(m.root);
    return { ...m, L };
  }

  _walker(i) {
    const role = pickRole(this.r);
    const m = this._spawnModel(role, 1000 + i * 77);
    const n = { kind: 'walker', role, ...m, speed: SPEED[role] * (0.85 + this.r() * 0.3), state: 'walk', timer: 0, phase: this.r() * 6, path: null, d: 0, x: 0, z: 0, facing: 0,
      rude: role !== 'turista' && this.r() < 0.18, voice: 0.8 + this.r() * 0.7 };
    n.maxHp = n.hp = n.rude ? 80 : role === 'anziano' ? 40 : 60;
    this._place(n, null);
    return n;
  }

  _place(n, player, minD = 0, maxD = 1e9) {
    for (let k = 0; k < 40; k++) {
      const p = this.paths[Math.floor(this.r() * this.paths.length)];
      const d = this.r() * p.total;
      const [x, z] = pointAt(p, d);
      const dist = player ? Math.hypot(x - player.x, z - player.z) : 0;
      if (player && (dist < minD || dist > maxD)) continue;
      n.path = p; n.d = d; n.x = x; n.z = z; n.state = 'walk';
      this._calm(n); n.hp = n.maxHp; n.robbed = false;
      return true;
    }
    return false;
  }

  _static(role, x, z, facing, extra = {}) {
    const m = this._spawnModel(role, Math.floor(x * 13 + z * 7) & 0xffff, extra.look);
    const n = { kind: 'static', role, ...m, state: 'static', x, z, facing, phase: this.r() * 6, voice: 0.8 + this.r() * 0.7, homeX: x, homeZ: z, homeF: facing, ...extra };
    n.maxHp = n.hp = role === 'pusher' ? 90 : 60;
    m.root.position.set(x, 0, z); m.root.rotation.y = facing;
    if (m.L.sitting) { m.parts.lL.rotation.x = -1.4; m.parts.lR.rotation.x = -1.4; m.root.position.y = -0.45; }
    this.npcs.push(n);
    return n;
  }

  _statics(features, shops) {
    // camerieri davanti a bar e caffè
    const bars = shops.filter((s) => s.type === 'bar' || s.type === 'caffe');
    bars.forEach((s, i) => { if (i % 2 === 0) this._static('cameriere', s.x + s.nx * 1.2, s.z + s.nz * 1.2, Math.atan2(s.nx, s.nz)); });
    // Marta, la barista del bar della storia
    const ring = shops.find((s) => /ringhiera/i.test(s.name)) || bars[0];
    this.storyBar = ring ? ring.name : null;
    if (ring) this._static('cameriere', ring.x - ring.nx * 0.2, ring.z - ring.nz * 0.2, Math.atan2(ring.nx, ring.nz), { story: 'marta', name: 'Marta, la barista', look: { top: '#2a4a3a', hair: '#6b4425', apron: true } });
    // Aldo sulla riva della Darsena, Teo sul primo ponte, il Biondo in un vicolo
    const benches = features.pois.filter((p) => p.kind === 'bench');
    // la Darsena a Milano; altrove lo specchio d'acqua più grande (l'Arno a Firenze)
    const area = (r) => { let a = 0; for (let i = 0; i < r.length; i++) { const p = r[i], q = r[(i + 1) % r.length]; a += p[0] * q[1] - q[0] * p[1]; } return Math.abs(a / 2); };
    const dars = features.water.find((w) => /darsena/i.test(w.name || '')) || features.water.slice().sort((a, b) => area(b.outer) - area(a.outer))[0];
    let aldoSpot = null;
    if (dars) {
      // sulla riva, il più vicino possibile al centro della mappa, con l'acqua davanti
      const R = dars.outer;
      let bd = Infinity;
      for (let i = 0; i < R.length; i++) {
        const a = R[i], b = R[(i + 1) % R.length], L = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
        const nx = (b[1] - a[1]) / L, nz = -(b[0] - a[0]) / L;
        for (const sg of [1, -1]) {
          const x = (a[0] + b[0]) / 2 + nx * sg * 3, z = (a[1] + b[1]) / 2 + nz * sg * 3;
          const d = Math.hypot(x, z);
          if (d < bd && this.col.isFree(x, z)) { bd = d; aldoSpot = [x, z, Math.atan2(-nx * sg, -nz * sg)]; }
        }
      }
    }
    if (!aldoSpot && benches.length) aldoSpot = [benches[0].x, benches[0].z, 0];
    if (aldoSpot) this._static('anziano', aldoSpot[0], aldoSpot[1], aldoSpot[2], { story: 'aldo', name: 'Aldo', look: { hat: '#4a3f35' } });
    const bridges = features.roads.filter((r) => r.bridge);
    if (bridges.length) {
      const b = bridges[Math.min(1, bridges.length - 1)], m = Math.floor(b.pts.length / 2);
      const a = b.pts[Math.max(0, m - 1)], c = b.pts[Math.min(b.pts.length - 1, m)];
      const x = (a[0] + c[0]) / 2, z = (a[1] + c[1]) / 2, dx = c[0] - a[0], dz = c[1] - a[1], l = Math.hypot(dx, dz) || 1;
      this._static('musicista', x - dz / l * (b.width / 2 - 0.5), z + dx / l * (b.width / 2 - 0.5), Math.atan2(dz, -dx), { story: 'teo', name: 'Teo', busker: true });
    }
    // pusher e senzatetto nei vicoli
    const alleys = features.roads.filter((r) => r.kind === 'living_street' && !r.bridge && r.pts.length >= 2);
    const spots = [];
    for (const r of alleys) {
      const p = r.pts[r.pts.length - 1], q = r.pts[r.pts.length - 2];
      const dx = p[0] - q[0], dz = p[1] - q[1], l = Math.hypot(dx, dz) || 1;
      const x = p[0] - dx / l * 6 + (-dz / l) * 1.6, z = p[1] - dz / l * 6 + (dx / l) * 1.6;
      if (this.col.isFree(x, z)) spots.push([x, z, Math.atan2(-dx, -dz)]);
    }
    spots.forEach((s, i) => {
      if (i === 0) this._static('pusher', s[0], s[1], s[2], { story: 'biondo', name: 'Il Biondo', look: { hair: '#d8b679', hood: false } });
      else if (i % 3 === 1) this._static('pusher', s[0], s[1], s[2]);
      else if (i === 2) this._static('senzatetto', s[0], s[1], s[2]);
    });
  }

  find(story) { return this.npcs.find((n) => n.story === story); }

  say(n, text, tone) {
    if (n.bubble) { n.root.parent && this.group.remove(n.bubble); n.bubble.material.map.dispose(); }
    n.bubble = bubbleSprite(text, tone);
    n.bubbleT = 2.5 + text.length * 0.045;
    this.group.add(n.bubble);
    if (this.onSay) this.onSay(n, text, tone);
  }

  // il commesso che si affaccia sulla porta quando entri in un negozio
  clerk(x, z, facing, look) {
    if (!this.clerkNpc) this.clerkNpc = this._static('cameriere', x, z, facing, { name: 'Commesso', look });
    const c = this.clerkNpc;
    c.x = x; c.z = z; c.facing = facing; c.root.position.set(x, 0, z); c.root.rotation.y = facing; c.hidden = false;
    return c;
  }
  hideClerk() { if (this.clerkNpc) { this.clerkNpc.hidden = true; this.clerkNpc.x = this.clerkNpc.z = 1e6; } }

  // ctx: { player: {x,z}, night, dt }
  update(dt, ctx) {
    this.t += dt;
    const P = ctx.player, gone = [];
    this.shadowT -= dt;
    const doShadow = this.shadowT <= 0; if (doShadow) this.shadowT = 1;
    // battute: ogni tanto qualcuno vicino dice qualcosa
    this.barkT = (this.barkT ?? 4) - dt;
    if (this.barkT <= 0) {
      this.barkT = 5 + Math.random() * 7;
      const near = this.npcs.filter((n) => n.kind === 'walker' && n.root.visible && !n.talking && !this.busy(n) && Math.hypot(n.x - P.x, n.z - P.z) < 12);
      if (near.length) { const n = near[Math.floor(Math.random() * near.length)]; const b = bark(n, ctx); this.say(n, b.text, b.rude ? 'rude' : b.strange ? 'strange' : ''); }
    }
    for (const n of this.npcs) {
      if (n.bubble) {
        n.bubbleT -= dt;
        n.bubble.position.set(n.x, 2.55 * n.L.scale + (n.L.sitting ? -0.45 : 0), n.z);
        n.bubble.material.opacity = Math.min(1, n.bubbleT * 2);
        if (n.bubbleT <= 0) { this.group.remove(n.bubble); n.bubble.material.map.dispose(); n.bubble = null; }
      }
      const dist = Math.hypot(n.x - P.x, n.z - P.z);
      const visible = dist < 140 && !n.hidden && !(n.night && ctx.night < 0.3 && !n.talking);
      n.root.visible = visible;
      if (doShadow) for (const m of n.meshes) m.castShadow = dist < 28;
      if (n.kind === 'police') { if (n.leaving && dist > 70) gone.push(n); else this._act(n, dt, P); continue; }
      if (n.kind === 'walker' && dist > 160) { this._place(n, P, 60, 130); continue; }
      if (this.busy(n)) { if (visible) this._act(n, dt, P); continue; }
      if (n.kind === 'walker') {
        if (!visible) continue;
        this._walk(n, dt, P);
      } else {
        if (!visible) continue;
        this._idle(n, dt, P);
      }
    }
    for (const n of gone) this.remove(n);
    // a volte due passanti si fermano a parlare
    if (Math.random() < dt * 0.3) {
      const a = this.npcs[Math.floor(Math.random() * this.npcs.length)];
      if (a && a.kind === 'walker' && a.state === 'walk' && !this.busy(a)) {
        for (const b of this.npcs) {
          if (b === a || b.kind !== 'walker' || b.state !== 'walk' || this.busy(b)) continue;
          if (Math.hypot(a.x - b.x, a.z - b.z) < 2.2) {
            const t = 6 + Math.random() * 8;
            a.state = b.state = 'chat'; a.timer = b.timer = t;
            a.facing = Math.atan2(b.x - a.x, b.z - a.z); b.facing = Math.atan2(a.x - b.x, a.z - b.z);
            break;
          }
        }
      }
    }
  }

  _walk(n, dt, P) {
    if (n.talking) { this._faceTalk(n, dt, P); return; }
    if (n.state === 'idle' || n.state === 'chat') {
      n.timer -= dt;
      this._pose(n, dt, 0, n.state);
      if (n.timer <= 0) n.state = 'walk';
      return;
    }
    // si scansa se il giocatore è proprio davanti
    const ahead = Math.hypot(n.x + Math.sin(n.facing) * 1.2 - P.x, n.z + Math.cos(n.facing) * 1.2 - P.z) < 0.9;
    const v = ahead ? 0.2 : n.speed;
    n.d += v * dt;
    if (n.d >= n.path.total) {
      // continua su un percorso che parte da qui, altrimenti torna indietro
      const end = n.path[n.path.length - 1];
      const next = this.paths.find((p) => p !== n.path && Math.hypot(p[0][0] - end[0], p[0][1] - end[1]) < 6 && Math.random() < 0.7);
      if (next) { n.path = next; n.d = 0; }
      else { n.path = this._reverse(n.path); n.d = 0; }
    }
    const [x, z, a] = pointAt(n.path, n.d);
    n.x = x; n.z = z;
    let df = a - n.facing; while (df > Math.PI) df -= 2 * Math.PI; while (df < -Math.PI) df += 2 * Math.PI;
    n.facing += df * Math.min(1, dt * 6);
    n.root.position.set(x, 0, z); n.root.rotation.y = n.facing;
    if (Math.random() < dt * 0.015) { n.state = 'idle'; n.timer = 2 + Math.random() * 5; }
    this._pose(n, dt, v, 'walk');
  }

  _reverse(p) {
    if (p.rev) return p.rev;
    const r = p.slice().reverse();
    r.len = [0]; for (let i = 1; i < r.length; i++) r.len.push(r.len[i - 1] + Math.hypot(r[i][0] - r[i - 1][0], r[i][1] - r[i - 1][1]));
    r.total = r.len[r.len.length - 1];
    p.rev = r; r.rev = p;
    return r;
  }

  _idle(n, dt, P) {
    if (n.giveT > 0) {
      n.giveT -= dt;
      const p = n.parts, k = Math.min(1, (1.2 - n.giveT) / 0.3, n.giveT / 0.3);
      p.aR.rotation.x = -1.2 * Math.max(0, k); p.aL.rotation.x = -0.2;
      if (n.talking) this._faceTalk(n, dt, P);
      return;
    }
    if (n.lookAround > 0) { n.lookAround -= dt; n.root.rotation.y = n.facing + Math.sin(n.lookAround * 5) * 0.6; return; }
    if (n.talking) { this._faceTalk(n, dt, P); return; }
    n.root.rotation.y = n.facing;
    this._pose(n, dt, 0, n.busker ? 'play' : n.role === 'pusher' ? 'lean' : 'idle');
  }

  _faceTalk(n, dt, P) {
    n.talking -= dt;
    if (n.talking <= 0) n.talking = 0;
    const target = Math.atan2(P.x - n.x, P.z - n.z);
    let df = target - n.root.rotation.y; while (df > Math.PI) df -= 2 * Math.PI; while (df < -Math.PI) df += 2 * Math.PI;
    n.root.rotation.y += df * Math.min(1, dt * 5);
    if (n.kind === 'walker') n.facing = n.root.rotation.y;
    this._pose(n, dt, 0, 'chat');
  }

  _pose(n, dt, v, mode) {
    n.phase += dt * (v > 0.1 ? 2.2 + v * 1.6 : 1);
    const p = n.parts, s = Math.sin(n.phase), amp = Math.min(1, v / 1.6) * 0.6;
    if (n.L.sitting) { p.aL.rotation.x = -0.4; p.aR.rotation.x = -0.4; return; }
    if (mode === 'walk') {
      p.lL.rotation.x = s * amp; p.lR.rotation.x = -s * amp;
      p.aL.rotation.x = -s * amp * 0.8; p.aR.rotation.x = s * amp * 0.8;
      p.aL.rotation.z = p.aR.rotation.z = 0;
      p.core.position.y = Math.abs(Math.cos(n.phase)) * 0.03 * amp;
      if (n.chase) { p.aR.rotation.x = -0.4; } // il vigile tiene la radio
    } else if (mode === 'play') {
      p.lL.rotation.x = p.lR.rotation.x = 0;
      p.aL.rotation.x = -0.9; p.aR.rotation.x = -0.7 + Math.sin(this.t * 7) * 0.15;
      p.core.position.y = Math.sin(this.t * 2) * 0.01;
    } else if (mode === 'chat') {
      p.lL.rotation.x = p.lR.rotation.x = 0;
      p.aR.rotation.x = -0.5 + Math.sin(this.t * 3 + n.phase) * 0.35; p.aL.rotation.x = -0.1;
    } else if (mode === 'fight') {
      // in guardia
      p.lL.rotation.x = 0.25; p.lR.rotation.x = -0.2;
      p.aL.rotation.x = -1.2; p.aR.rotation.x = -1.0; p.aL.rotation.z = 0.2; p.aR.rotation.z = -0.2;
      p.core.position.y = Math.sin(this.t * 6) * 0.015;
    } else if (mode === 'lean') {
      p.lL.rotation.x = 0.1; p.lR.rotation.x = -0.05; p.aL.rotation.x = -0.25; p.aR.rotation.x = -0.25;
      p.aL.rotation.z = 0.25; p.aR.rotation.z = -0.25;
    } else {
      // fermo: guarda il telefono
      p.lL.rotation.x = p.lR.rotation.x = 0;
      p.aR.rotation.x = -1.1; p.aL.rotation.x = -0.05;
      p.core.position.y = Math.sin(this.t * 1.5 + n.phase) * 0.006;
    }
  }

  // la persona più vicina con cui parlare
  nearest(P, maxD = 2.6) {
    let best = null, bd = maxD;
    for (const n of this.npcs) {
      if (!n.root.visible) continue;
      const d = Math.hypot(n.x - P.x, n.z - P.z);
      if (d < bd) { bd = d; best = n; }
    }
    return best;
  }

  talkTo(n, seconds = 8) { n.talking = seconds; }
  give(n) { n.giveT = 1.2; }
  lookAround(n) { n.lookAround = 1.2; }

  // spinge il giocatore fuori dalle persone (non si attraversano)
  // restituisce la persona urtata (per farla reagire)
  pushOut(P, speed, ctx) {
    let hit = null;
    for (const n of this.npcs) {
      if (!n.root.visible || n.ko > 0) continue;
      const dx = P.x - n.x, dz = P.z - n.z, d = Math.hypot(dx, dz);
      if (d < 0.6 && d > 1e-4) { P.x = n.x + dx / d * 0.6; P.z = n.z + dz / d * 0.6; hit = n; }
    }
    if (hit && speed > 2.2 && !this.busy(hit) && (!hit.lastBump || this.t - hit.lastBump > 6)) {
      hit.lastBump = this.t;
      if (hit.kind === 'walker') { hit.state = 'idle'; hit.timer = 1.5; }
      this.talkTo(hit, 2);
      const b = bark(hit, Object.assign({ bump: true }, ctx));
      this.say(hit, b.text, b.rude ? 'rude' : '');
      if (b.rude && ctx.violence && hit.kind === 'walker' && Math.random() < 0.3) { hit.aggro = true; hit.talking = 0; }
    }
    return hit;
  }

  // ---------- violenza (solo se attivata nelle impostazioni) ----------
  busy(n) { return n.ko > 0 || n.flee > 0 || n.aggro || n.chase || n.leaving || n.returning || n.hitT > 0; }
  _calm(n) {
    n.ko = 0; n.koFall = 0; n.flee = 0; n.aggro = false; n.chase = false; n.leaving = false; n.returning = null; n.hitT = 0; n.punchT = 0; n.catchT = 0;
    n.root.rotation.x = 0; n.root.position.y = n.L.sitting ? -0.45 : 0;
    if (n.blood) { this.group.remove(n.blood); n.blood = null; }
  }

  // colpo ricevuto: barcolla, oppure va a terra svenuto e ci resta un po'
  hurt(n, dmg) {
    n.hp -= dmg; n.hitT = 0.35; n.talking = 0;
    if (n.bubble) n.bubbleT = Math.min(n.bubbleT, 0.4);
    if (n.hp > 0) return 'hit';
    n.ko = 35 + Math.random() * 25; n.koFall = 0; n.aggro = false; n.chase = false; n.flee = 0; n.returning = null;
    return 'ko';
  }

  // chi vede la scena scappa urlando; i duri restano a guardare. Restituisce quanti hanno visto.
  panic(x, z, radius, except) {
    let seen = 0;
    for (const n of this.npcs) {
      if (n === except || n === this.clerkNpc || !n.root.visible || n.ko > 0 || n.kind === 'police' || n.story === 'nora') continue;
      const d = Math.hypot(n.x - x, n.z - z);
      if (d > radius) continue;
      seen++;
      if (n.role === 'pusher' || n.rude || n.aggro || n.L.sitting) continue;
      n.flee = 6 + Math.random() * 5; n.fleeFrom = { x, z }; n.talking = 0; n.state = 'walk';
    }
    return seen;
  }

  spawnPolice(P) {
    const m = this._spawnModel('vigile', 9000 + Math.floor(this.t * 10));
    const n = { kind: 'police', role: 'vigile', name: 'Polizia locale', ...m, speed: 1.4, state: 'walk', timer: 0, phase: 0, path: null, d: 0, x: 0, z: 0, facing: 0, voice: 0.75, maxHp: 160, hp: 160 };
    if (!this._place(n, P, 35, 70) && !this._place(n, P, 15, 120)) { this.remove(n, true); return null; }
    m.root.position.set(n.x, 0, n.z);
    n.chase = true;
    this.npcs.push(n);
    return n;
  }
  remove(n, notListed) {
    this._calm(n);
    if (n.bubble) { this.group.remove(n.bubble); n.bubble.material.map.dispose(); n.bubble = null; }
    this.group.remove(n.root);
    for (const mm of n.meshes) mm.geometry.dispose();
    if (!notListed) { const i = this.npcs.indexOf(n); if (i >= 0) this.npcs.splice(i, 1); }
  }
  get police() { return this.npcs.filter((n) => n.kind === 'police'); }

  _act(n, dt, P) {
    const r = n.root;
    if (n.ko > 0) {
      n.koFall = Math.min(1, n.koFall + dt * 2.6);
      const e = n.koFall * n.koFall;
      r.rotation.x = -Math.PI / 2 * e; r.position.y = (n.L.sitting ? -0.3 : 0) * (1 - e) + 0.12 * e;
      if (n.koFall >= 1 && !n.blood) {
        n.blood = new THREE.Mesh(BLOOD_GEO, BLOOD_MAT);
        n.blood.position.set(n.x - Math.sin(n.facing) * 1.45 * n.L.scale, 0.03, n.z - Math.cos(n.facing) * 1.45 * n.L.scale);
        this.group.add(n.blood);
      }
      n.ko -= dt;
      if (n.ko <= 0) {
        // si rialza intontito e se ne va
        const fx = P.x, fz = P.z;
        this._calm(n); n.hp = Math.round(n.maxHp * 0.5);
        if (n.kind === 'police') n.leaving = true;
        else if (!n.L.sitting) { n.flee = 8; n.fleeFrom = { x: fx, z: fz }; }
      }
      return;
    }
    if (n.hitT > 0) {
      n.hitT -= dt;
      r.rotation.x = -0.3 * Math.sin(Math.max(0, n.hitT) / 0.35 * Math.PI);
      if (n.hitT <= 0) r.rotation.x = 0;
      if (!n.aggro && !n.chase && !(n.flee > 0)) { this._pose(n, dt, 0, 'idle'); return; }
    }
    const d = Math.hypot(P.x - n.x, P.z - n.z);
    if (n.flee > 0) {
      n.flee -= dt;
      this._move(n, n.fleeFrom.x, n.fleeFrom.z, n.role === 'anziano' ? 1.7 : 3.6, dt, true);
      if (n.flee <= 0) { n.flee = 0; this._goHome(n); }
      return;
    }
    if (n.aggro || n.chase) {
      if (d > (n.chase ? 220 : 26)) { n.aggro = false; if (n.kind === 'police') { n.chase = false; n.leaving = true; } else this._goHome(n); return; }
      if (d > 1.05) { this._move(n, P.x, P.z, n.chase ? 3.9 : 3.2, dt, false); n.catchT = 0; }
      else {
        this._face(n, P, dt);
        this._pose(n, dt, 0, 'fight');
        if (n.chase) { n.catchT += dt; if (n.catchT > 1.0) { n.catchT = 0; if (this.onCatch) this.onCatch(n); } }
        if (n.aggro) {
          n.atkT = (n.atkT ?? 0.4) - dt;
          if (n.atkT <= 0) { n.atkT = 0.95 + Math.random() * 0.6; n.punchT = 0.32; if (this.onHitPlayer) this.onHitPlayer(n); }
        }
      }
      if (n.punchT > 0) { n.punchT -= dt; const u = 1 - n.punchT / 0.32, ext = u < 0.35 ? u / 0.35 : 1 - (u - 0.35) / 0.65; n.parts.aR.rotation.x = -0.6 - 1.0 * ext; }
      return;
    }
    if (n.leaving) { this._move(n, P.x, P.z, 1.5, dt, true); return; }
    if (n.returning) {
      const g = n.returning;
      n.retT = (n.retT || 0) + dt;
      if (Math.hypot(g.x - n.x, g.z - n.z) < 0.5 || n.retT > 25) {
        n.x = g.x; n.z = g.z; r.position.set(n.x, r.position.y, n.z);
        if (g.path) { n.path = g.path; n.d = g.d; n.state = 'walk'; }
        else { n.facing = n.homeF; r.rotation.y = n.facing; }
        n.returning = null; n.retT = 0;
      } else this._move(n, g.x, g.z, 1.4, dt, false);
    }
  }

  _goHome(n) {
    if (n.kind === 'police') { n.leaving = true; return; }
    if (n.kind === 'static') { n.returning = { x: n.homeX, z: n.homeZ }; return; }
    let best = null, bd = Infinity;
    for (const p of this.paths) for (let i = 0; i < p.length; i++) {
      const d = (p[i][0] - n.x) ** 2 + (p[i][1] - n.z) ** 2;
      if (d < bd) { bd = d; best = { x: p[i][0], z: p[i][1], path: p, d: p.len[i] }; }
    }
    n.returning = best;
  }

  _face(n, P, dt) {
    const target = Math.atan2(P.x - n.x, P.z - n.z);
    let df = target - n.facing; while (df > Math.PI) df -= 2 * Math.PI; while (df < -Math.PI) df += 2 * Math.PI;
    n.facing += df * Math.min(1, dt * 8); n.root.rotation.y = n.facing;
  }

  // passo libero verso (o lontano da) un punto, girando attorno a muri, alberi e acqua
  _move(n, tx, tz, speed, dt, away) {
    let dx = tx - n.x, dz = tz - n.z; if (away) { dx = -dx; dz = -dz; }
    const base = Math.atan2(dx, dz), s = speed * dt;
    n.side = n.side || (Math.random() < 0.5 ? 1 : -1);
    let moved = false;
    for (const off of [0, 0.5, -0.5, 1.1, -1.1, 1.7, -1.7, 2.4, -2.4]) {
      const a = base + off * n.side, x = n.x + Math.sin(a) * s, z = n.z + Math.cos(a) * s;
      if (this.col.isFree(x, z) || this.col.onBridge(x, z)) {
        n.x = x; n.z = z; moved = true;
        let df = a - n.facing; while (df > Math.PI) df -= 2 * Math.PI; while (df < -Math.PI) df += 2 * Math.PI;
        n.facing += df * Math.min(1, dt * 8);
        break;
      }
    }
    if (!moved) n.side = -n.side;
    n.root.position.set(n.x, n.root.position.y, n.z); n.root.rotation.y = n.facing;
    this._pose(n, dt, moved ? speed : 0, 'walk');
  }
}
