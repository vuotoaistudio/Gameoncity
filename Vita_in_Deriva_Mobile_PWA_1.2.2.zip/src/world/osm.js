// Conversione dei dati OpenStreetMap (formato Overpass "out geom") in elementi in metri.
// Funzioni pure: usate dal client e dai test in Node.

const M_PER_DEG = 111320;

export function makeProjection(center) {
  const my = M_PER_DEG, mx = M_PER_DEG * Math.cos(center.lat * Math.PI / 180);
  // x verso est, z verso sud (in Three.js il nord è -z)
  return {
    toXZ: (lat, lon) => [(lon - center.lon) * mx, -(lat - center.lat) * my],
    toLatLon: (x, z) => ({ lat: center.lat - z / my, lon: center.lon + x / mx })
  };
}

const ROAD_WIDTH = {
  motorway: 16, trunk: 14, primary: 12, secondary: 10, tertiary: 9, unclassified: 7,
  residential: 7, living_street: 6, service: 4.5, pedestrian: 8, footway: 2.6, path: 2,
  cycleway: 2.2, steps: 2.6, track: 3, corridor: 0
};
const WATERWAY_WIDTH = { river: 24, canal: 16, stream: 3, ditch: 1.5, drain: 1.5 };

const DEFAULT_HEIGHT = {
  apartments: 16, residential: 14, house: 8, detached: 8, terrace: 10, commercial: 14, retail: 8,
  office: 18, industrial: 9, warehouse: 9, church: 20, cathedral: 30, chapel: 9, school: 12,
  university: 16, hospital: 18, garage: 3, garages: 3, shed: 3, kiosk: 3, hut: 3, roof: 0,
  train_station: 14, civic: 14, public: 14, hotel: 18, yes: 13
};

export function parseLength(v) {
  if (v == null) return NaN;
  const m = String(v).replace(',', '.').match(/-?\d+(\.\d+)?/);
  if (!m) return NaN;
  let n = parseFloat(m[0]);
  if (/ft|'/.test(String(v))) n *= 0.3048;
  return n;
}

export function signedArea(ring) {
  let a = 0;
  for (let i = 0, n = ring.length; i < n; i++) {
    const [x1, z1] = ring[i], [x2, z2] = ring[(i + 1) % n];
    a += x1 * z2 - x2 * z1;
  }
  return a / 2;
}

export function pointInRing(x, z, ring) {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [xi, zi] = ring[i], [xj, zj] = ring[j];
    if ((zi > z) !== (zj > z) && x < (xj - xi) * (z - zi) / (zj - zi) + xi) inside = !inside;
  }
  return inside;
}

function cleanRing(pts) {
  const out = [];
  for (const p of pts) {
    const q = out[out.length - 1];
    if (!q || Math.hypot(p[0] - q[0], p[1] - q[1]) > 0.05) out.push(p);
  }
  if (out.length > 1) {
    const a = out[0], b = out[out.length - 1];
    if (Math.hypot(a[0] - b[0], a[1] - b[1]) < 0.05) out.pop();
  }
  return out;
}

// Unisce i tratti di una relazione multipoligono in anelli chiusi
export function stitchRings(segments) {
  const segs = segments.map((s) => s.slice());
  const rings = [];
  const key = (p) => p[0].toFixed(3) + ',' + p[1].toFixed(3);
  while (segs.length) {
    let ring = segs.shift();
    let guard = 0;
    while (key(ring[0]) !== key(ring[ring.length - 1]) && guard++ < 1000) {
      const end = key(ring[ring.length - 1]);
      const i = segs.findIndex((s) => key(s[0]) === end || key(s[s.length - 1]) === end);
      if (i < 0) break;
      let s = segs.splice(i, 1)[0];
      if (key(s[0]) !== end) s = s.slice().reverse();
      ring = ring.concat(s.slice(1));
    }
    if (ring.length >= 4) rings.push(ring);
  }
  return rings;
}

function hash32(n) {
  n = (n ^ 61) ^ (n >>> 16); n = n + (n << 3); n = n ^ (n >>> 4);
  n = Math.imul(n, 0x27d4eb2d); n = n ^ (n >>> 15);
  return (n >>> 0) / 4294967296;
}

export function buildingHeight(tags, id) {
  let h = parseLength(tags.height);
  const levels = parseFloat(tags['building:levels']);
  if (!isFinite(h)) {
    if (isFinite(levels)) h = levels * 3.3 + (tags['roof:levels'] ? parseFloat(tags['roof:levels']) * 2.5 : 0.8);
    else h = (DEFAULT_HEIGHT[tags.building] ?? DEFAULT_HEIGHT[tags['building:part']] ?? 13) * (0.85 + hash32(id) * 0.3);
  }
  let minH = parseLength(tags.min_height);
  if (!isFinite(minH)) {
    const ml = parseFloat(tags['building:min_level']);
    minH = isFinite(ml) ? ml * 3.3 : 0;
  }
  return { height: Math.max(h, minH + 2.5), minHeight: minH, levels: isFinite(levels) ? levels : Math.max(1, Math.round(h / 3.3)) };
}

export function parseOSM(data, center) {
  const proj = makeProjection(center);
  const toXZ = (g) => g.map((p) => proj.toXZ(p.lat, p.lon));
  const out = { outlines: [], buildings: [], roads: [], water: [], waterways: [], parks: [], plazas: [], pois: [], lamps: [], trees: [], trams: [], proj };
  for (const e of data.elements || []) {
    const t = e.tags || {};
    if (e.type === 'node') {
      const [x, z] = proj.toXZ(e.lat, e.lon);
      if (t.highway === 'street_lamp') out.lamps.push([x, z]);
      else if (t.natural === 'tree') out.trees.push([x, z]);
      else if (t.amenity || t.shop || t.leisure) out.pois.push({ x, z, kind: t.amenity || t.leisure || 'shop', shop: t.shop, name: t.name || null, id: e.id, tags: t });
      continue;
    }
    if (e.type === 'way' && e.geometry) {
      const pts = toXZ(e.geometry);
      const closed = e.geometry.length > 3 && e.geometry[0].lat === e.geometry[e.geometry.length - 1].lat && e.geometry[0].lon === e.geometry[e.geometry.length - 1].lon;
      if ((t.building || t['building:part']) && closed) {
        if (t.building === 'roof' || t.building === 'construction' || t.location === 'underground') continue;
        const ring = cleanRing(pts);
        if (ring.length >= 3 && Math.abs(signedArea(ring)) > 4) out.buildings.push(Object.assign({ id: e.id, outer: ring, holes: [], tags: t }, buildingHeight(t, e.id)));
      } else if (t.highway && t.area === 'yes' && closed) {
        out.plazas.push({ outer: cleanRing(pts), name: t.name || null });
      } else if (t.highway && t.area !== 'yes') {
        const w = ROAD_WIDTH[t.highway];
        if (w === undefined || w === 0 || t.tunnel === 'yes' || t.layer && parseInt(t.layer) < 0) continue;
        const lanes = parseInt(t.lanes);
        const width = parseLength(t.width) || (isFinite(lanes) && w >= 6 ? Math.max(w * 0.7, lanes * 3.2) : w);
        out.roads.push({ pts, width, kind: t.highway, name: t.name || null, bridge: t.bridge === 'yes' || t.bridge === 'viaduct', id: e.id,
          oneway: t.oneway === 'yes' || t.oneway === '1' ? 1 : t.oneway === '-1' ? -1 : 0, surface: t.surface || null, service: t.service || null });
      } else if (t.natural === 'water' && closed) {
        out.water.push({ outer: cleanRing(pts), holes: [], name: t.name || null });
      } else if (t.waterway && WATERWAY_WIDTH[t.waterway] && t.tunnel !== 'culvert' && t.tunnel !== 'yes') {
        out.waterways.push({ pts, width: parseLength(t.width) || WATERWAY_WIDTH[t.waterway], kind: t.waterway, name: t.name || null });
      } else if ((t.leisure || t.landuse) && closed) {
        out.parks.push({ outer: cleanRing(pts), kind: t.leisure || t.landuse, name: t.name || null });
      } else if (t.railway === 'tram') {
        out.trams.push({ pts });
      }
      continue;
    }
    if (e.type === 'relation' && e.members) {
      const outerSegs = [], innerSegs = [];
      for (const m of e.members) {
        if (m.type !== 'way' || !m.geometry) continue;
        (m.role === 'inner' ? innerSegs : outerSegs).push(toXZ(m.geometry));
      }
      const outers = stitchRings(outerSegs).map(cleanRing).filter((r) => r.length >= 3);
      const inners = stitchRings(innerSegs).map(cleanRing).filter((r) => r.length >= 3);
      for (const outer of outers) {
        const holes = inners.filter((h) => pointInRing(h[0][0], h[0][1], outer));
        if (t.building) out.buildings.push(Object.assign({ id: e.id, outer, holes, tags: t }, buildingHeight(t, e.id)));
        else if (t.natural === 'water') out.water.push({ outer, holes, name: t.name || null });
      }
    }
  }
  // edifici scomposti in parti (Simple 3D Buildings): la sagoma esterna lascia il posto alle parti
  const parts = out.buildings.filter((b) => b.tags['building:part']);
  if (parts.length) {
    const centroid = (r) => { let x = 0, z = 0; for (const p of r) { x += p[0]; z += p[1]; } return [x / r.length, z / r.length]; };
    const pc = parts.map((p) => centroid(p.outer));
    out.buildings = out.buildings.filter((b) => {
      if (b.tags['building:part'] || !b.tags.building) return true;
      let covered = 0;
      for (let i = 0; i < parts.length; i++) if (pointInRing(pc[i][0], pc[i][1], b.outer)) covered += Math.abs(signedArea(parts[i].outer));
      if (covered < Math.abs(signedArea(b.outer)) * 0.5) return true;
      out.outlines.push({ outer: b.outer, tags: b.tags });
      return false;
    });
  }
  // indice stabile e ordinamento deterministico
  out.buildings.sort((a, b) => a.id - b.id);
  out.buildings.forEach((b, i) => { b.bid = i; b.seed = hash32(b.id); });
  return out;
}

export function addressOf(b) {
  const t = b.tags || {};
  if (t.name) return t.name;
  if (t['addr:street']) return t['addr:street'] + (t['addr:housenumber'] ? ' ' + t['addr:housenumber'] : '');
  return null;
}
