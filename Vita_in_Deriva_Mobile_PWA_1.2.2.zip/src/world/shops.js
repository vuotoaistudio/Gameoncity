// Negozi: insegne sulle facciate (accese di notte) e punto d'ingresso davanti alla porta.
import * as THREE from 'three';
import { classifyShop, SHOP_TYPES } from '../systems/economy.js';
import { signedArea } from './osm.js';

function signTexture(text, type, w = 1024, h = 192) {
  const st = SHOP_TYPES[type];
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d');
  const [bg, fg] = st.sign;
  if (st.neon) {
    g.fillStyle = '#05100a'; g.fillRect(0, 0, w, h);
    g.shadowColor = fg; g.shadowBlur = 30;
  } else {
    g.fillStyle = bg; g.fillRect(0, 0, w, h);
    g.strokeStyle = fg; g.globalAlpha = 0.5; g.lineWidth = 6; g.strokeRect(14, 14, w - 28, h - 28); g.globalAlpha = 1;
  }
  g.fillStyle = fg;
  g.textAlign = 'center'; g.textBaseline = 'middle';
  let size = 96;
  const font = type === 'archivio' || type === 'caffe' ? 'Gloock, Georgia, serif' : type === 'coffeeshop' ? '"IBM Plex Mono", monospace' : 'Karla, "Helvetica Neue", Arial, sans-serif';
  do { g.font = `700 ${size}px ${font}`; size -= 4; } while (g.measureText(text).width > w - 90 && size > 30);
  g.fillText(text, w / 2, h / 2 + 4);
  if (st.neon) g.fillText(text, w / 2, h / 2 + 4);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

function iconTexture(kind) {
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const g = c.getContext('2d');
  if (kind === 'cross') {
    g.fillStyle = '#0b0f0c'; g.fillRect(0, 0, 256, 256);
    g.fillStyle = '#2fe27a'; g.fillRect(96, 30, 64, 196); g.fillRect(30, 96, 196, 64);
  } else {
    g.fillStyle = '#123a7a'; g.fillRect(0, 0, 256, 256);
    g.fillStyle = '#fff'; g.font = '700 200px Karla, Arial, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('T', 128, 140);
  }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export function buildShops(features, collision) {
  const group = new THREE.Group();
  const shops = [];
  const signMats = [];
  // facciate candidate: lati di edifici a terra
  const edges = [];
  for (const b of features.buildings) {
    if (b.minHeight > 1) continue;
    const ccw = signedArea(b.outer) > 0;
    for (let i = 0; i < b.outer.length; i++) {
      const a = b.outer[i], c = b.outer[(i + 1) % b.outer.length];
      const len = Math.hypot(c[0] - a[0], c[1] - a[1]);
      if (len < 3) continue;
      const dx = (c[0] - a[0]) / len, dz = (c[1] - a[1]) / len;
      edges.push({ a, dx, dz, len, nx: ccw ? dz : -dz, nz: ccw ? -dx : dx, bid: b.bid });
    }
  }
  let id = 0;
  for (const p of features.pois) {
    const type = classifyShop(p);
    if (!type) continue;
    let best = null, bd = 9;
    for (const e of edges) {
      let t = (p.x - e.a[0]) * e.dx + (p.z - e.a[1]) * e.dz;
      t = Math.max(1.2, Math.min(e.len - 1.2, t));
      const px = e.a[0] + e.dx * t, pz = e.a[1] + e.dz * t;
      const d = Math.hypot(px - p.x, pz - p.z);
      if (d < bd && (p.x - px) * e.nx + (p.z - pz) * e.nz > -0.5 && collision.isFree(px + e.nx * 1.4, pz + e.nz * 1.4)) { bd = d; best = { px, pz, e }; }
    }
    if (!best) continue;
    const { px, pz, e } = best;
    const name = p.name || SHOP_TYPES[type].label;
    const yaw = Math.atan2(e.nx, e.nz);
    // insegna sopra la vetrina
    const tex = signTexture(name, type);
    const mat = new THREE.MeshStandardMaterial({ map: tex, emissiveMap: tex, emissive: 0xffffff, emissiveIntensity: 0.2, roughness: 0.5 });
    signMats.push({ mat, neon: !!SHOP_TYPES[type].neon });
    const sw = Math.min(e.len - 0.6, 4.2);
    const sign = new THREE.Mesh(new THREE.BoxGeometry(sw, sw * 0.1875, 0.08), [null, null, null, null, mat, null].map((m) => m || new THREE.MeshStandardMaterial({ color: 0x222222 })));
    sign.position.set(px + e.nx * 0.08, 3.25, pz + e.nz * 0.08);
    sign.rotation.y = yaw;
    group.add(sign);
    // insegne a bandiera: la T dei tabacchi, la croce della farmacia
    const st = SHOP_TYPES[type];
    if (st.tabacchi || st.cross) {
      const itex = iconTexture(st.cross ? 'cross' : 'T');
      const im = new THREE.MeshStandardMaterial({ map: itex, emissiveMap: itex, emissive: 0xffffff, emissiveIntensity: 0.3, side: THREE.DoubleSide });
      signMats.push({ mat: im, neon: !!st.cross, pulse: !!st.cross });
      const flag = new THREE.Mesh(new THREE.PlaneGeometry(0.75, 0.75), im);
      const along = sw / 2 + 0.6;
      flag.position.set(px + e.dx * along + e.nx * 0.5, 3.9, pz + e.dz * along + e.nz * 0.5);
      flag.rotation.y = yaw + Math.PI / 2;
      group.add(flag);
    }
    // tavolini fuori da bar e caffè
    if (type === 'bar' || type === 'caffe' || type === 'coffeeshop') {
      for (const k of [-1, 1]) {
        const tx = px + e.nx * 2.2 + e.dx * k * 1.6, tz = pz + e.nz * 2.2 + e.dz * k * 1.6;
        if (!collision.isFree(tx, tz)) continue;
        const table = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.04, 16), new THREE.MeshStandardMaterial({ color: 0xd9d4ca, roughness: 0.4 }));
        table.position.set(tx, 0.74, tz);
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.74, 6), new THREE.MeshStandardMaterial({ color: 0x222, metalness: 0.6, roughness: 0.4 }));
        leg.position.set(tx, 0.37, tz);
        table.castShadow = leg.castShadow = true;
        group.add(table, leg);
      }
    }
    shops.push({ id: id++, type, name, x: px + e.nx * 1.1, z: pz + e.nz * 1.1, nx: e.nx, nz: e.nz, bid: e.bid, doorX: px, doorZ: pz });
  }
  return {
    group, shops,
    update(night, t) {
      for (const s of signMats) {
        const base = s.neon ? 0.5 + night * 2.2 : 0.15 + night * 0.9;
        s.mat.emissiveIntensity = s.pulse ? base * (0.7 + 0.3 * Math.sin(t * 3)) : base;
      }
    }
  };
}
