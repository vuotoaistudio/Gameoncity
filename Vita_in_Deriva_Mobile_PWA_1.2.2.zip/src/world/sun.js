// Posizione del sole calcolata in locale (formule NOAA semplificate, errore < 1°).
const RAD = Math.PI / 180;

export function sunPosition(date, lat, lon) {
  const d = date.getTime() / 86400000 + 2440587.5 - 2451545.0;
  const g = ((357.529 + 0.98560028 * d) % 360) * RAD;
  const q = (280.459 + 0.98564736 * d) % 360;
  const L = (q + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g)) * RAD;
  const e = (23.439 - 0.00000036 * d) * RAD;
  const ra = Math.atan2(Math.cos(e) * Math.sin(L), Math.cos(L));
  const dec = Math.asin(Math.sin(e) * Math.sin(L));
  const gmst = ((18.697374558 + 24.06570982441908 * d) % 24 + 24) % 24;
  const H = (gmst * 15 + lon) * RAD - ra;
  const la = lat * RAD;
  const alt = Math.asin(Math.sin(la) * Math.sin(dec) + Math.cos(la) * Math.cos(dec) * Math.cos(H));
  const az = Math.atan2(-Math.sin(H), Math.cos(la) * Math.tan(dec) - Math.sin(la) * Math.cos(H));
  return { altitude: alt, azimuth: (az + 2 * Math.PI) % (2 * Math.PI) };
}

// Vettore direzione verso il sole nel sistema del gioco (x = est, y = su, -z = nord)
export function sunDirection(pos) {
  const c = Math.cos(pos.altitude);
  return [Math.sin(pos.azimuth) * c, Math.sin(pos.altitude), -Math.cos(pos.azimuth) * c];
}

export function localTimeString(date, timeZone) {
  return new Intl.DateTimeFormat('it-IT', { timeZone, hour: '2-digit', minute: '2-digit' }).format(date);
}

// Fase lunare 0..1 (0 = luna nuova, 0,5 = piena), dalla lunazione media
export function moonPhase(date) {
  const ref = Date.UTC(2000, 0, 6, 18, 14);
  const p = ((date.getTime() - ref) / 86400000) / 29.530588853;
  return p - Math.floor(p);
}
