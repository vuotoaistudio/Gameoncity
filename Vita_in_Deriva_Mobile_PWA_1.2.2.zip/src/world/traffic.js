// Traffico: auto sulle strade carrabili vere (rispettano i sensi unici, svoltano agli incroci,
// frenano se davanti c'è qualcuno) e tram sui binari. Solo attorno al giocatore, per risparmiare.
import * as THREE from 'three';
import { carGeometries, tramGeometries } from '../fx/vehicles.js';

const DRIVABLE = /^(primary|secondary|tertiary|unclassified|residential|living_street|service|primary_link|secondary_link|tertiary_link)$/;
const PAINT = ['#8f1d1d', '#e7e4dc', '#22252b', '#5b6d78', '#7d7d78', '#1f3550', '#c9b27b', '#3e5b45', '#b8b8b2', '#5a2b33', '#f2f0ea', '#2c2c2e', '#a33a2a', '#3d4f6b'].map((h) => new THREE.Color(h));
const key = (p) => p[0].toFixed(1) + ',' + p[1].toFixed(1);

function buildGraph(ways) {
  const nodes = new Map();
  ways.forEach((w, wi) => w.pts.forEach((p, i) => {
    const k = key(p);
    if (!nodes.has(k)) nodes.set(k, []);
    nodes.get(k).push({ w: wi, i });
  }));
  const len = ways.map((w) => { let L = 0; for (let i = 0; i < w.pts.length - 1; i++) L += Math.hypot(w.pts[i + 1][0] - w.pts[i][0], w.pts[i + 1][1] - w.pts[i][1]); return L; });
  return { nodes, len };
}

export class Traffic {
  constructor(scene, features, opts = {}) {
    this.scene = scene;
    this.carWays = features.roads.filter((r) => DRIVABLE.test(r.kind) && r.pts.length > 1 && !/parking_aisle|driveway/.test(r.service || ''))
      .map((r) => ({ pts: r.pts, oneway: r.oneway, width: r.width, y: r.bridge ? 0.32 : 0.08, main: !/service|living_street/.test(r.kind) }));
    this.tramWays = features.trams.filter((t) => t.pts.length > 1).map((t) => ({ pts: t.pts, oneway: 0, width: 3, y: 0.1 }));
    this.cg = buildGraph(this.carWays);
    this.tg = buildGraph(this.tramWays);
    this.nCars = this.carWays.length ? (opts.cars ?? 24) : 0;
    this.nTrams = this.tramWays.length ? (opts.trams ?? 3) : 0;
    this.cars = []; this.trams = [];
    this.group = new THREE.Group();
    scene.add(this.group);
    this.night = 0;
    this._meshes();
    this.honk = null; this.bell = null;
    this.enabled = true;
  }

  _meshes() {
    const o = new THREE.Object3D();
    const inst = (geo, mat, n, shadow) => { const m = new THREE.InstancedMesh(geo, mat, Math.max(1, n)); m.count = 0; m.castShadow = !!shadow; m.receiveShadow = true; m.frustumCulled = false; m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); this.group.add(m); return m; };
    const g = carGeometries();
    this.carHalf = g.half;
    this.headMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(1, 0.95, 0.85) });
    this.tailMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0.6, 0.02, 0.02) });
    const N = this.nCars;
    this.cm = {
      body: inst(g.body, new THREE.MeshPhysicalMaterial({ roughness: 0.32, metalness: 0.55, clearcoat: 1, clearcoatRoughness: 0.08 }), N, true),
      glass: inst(g.glass, new THREE.MeshStandardMaterial({ color: 0x0c0f12, roughness: 0.05, metalness: 0.2 }), N, true),
      wheels: inst(g.wheels, new THREE.MeshStandardMaterial({ color: 0x141414, roughness: 0.85 }), N, true),
      hubs: inst(g.hubs, new THREE.MeshStandardMaterial({ color: 0x9a9ca0, roughness: 0.3, metalness: 0.9 }), N, false),
      trim: inst(g.trim, new THREE.MeshStandardMaterial({ color: 0x1a1a1c, roughness: 0.6 }), N, false),
      front: inst(g.front, this.headMat, N, false),
      rear: inst(g.rear, this.tailMat, N, false)
    };
    const t = tramGeometries();
    this.tramHalf = t.half; this.tramLen = t.length;
    const T = this.nTrams;
    this.tm = {
      lower: inst(t.lower, new THREE.MeshPhysicalMaterial({ color: 0xe07a1f, roughness: 0.4, metalness: 0.2, clearcoat: 0.6 }), T, true),
      upper: inst(t.upper, new THREE.MeshStandardMaterial({ color: 0xece2c6, roughness: 0.5 }), T, true),
      glass: inst(t.glass, new THREE.MeshStandardMaterial({ color: 0x14181b, roughness: 0.05, metalness: 0.3, emissive: 0x000000 }), T, false),
      under: inst(t.under, new THREE.MeshStandardMaterial({ color: 0x1b1b1b, roughness: 0.8 }), T, true),
      panto: inst(t.panto, new THREE.MeshStandardMaterial({ color: 0x2a2a2a, roughness: 0.5, metalness: 0.6 }), T, false),
      lights: inst(t.lights, this.headMat, T, false),
      tail: inst(t.tail, this.tailMat, T, false)
    };
    this._o = o;
  }

  // posiziona un veicolo su un tratto a caso fra minR e maxR dal giocatore
  _spawn(v, ways, graph, center, minR, maxR) {
    for (let k = 0; k < 40; k++) {
      const wi = Math.floor(Math.random() * ways.length), w = ways[wi];
      if (v.kind === 'car' && !w.main && Math.random() < 0.7) continue;
      const i = Math.floor(Math.random() * (w.pts.length - 1));
      const a = w.pts[i], b = w.pts[i + 1];
      const d = Math.hypot((a[0] + b[0]) / 2 - center.x, (a[1] + b[1]) / 2 - center.z);
      if (d < minR || d > maxR) continue;
      const dir = w.oneway === 1 ? 1 : w.oneway === -1 ? -1 : (Math.random() < 0.5 ? 1 : -1);
      Object.assign(v, { w: wi, i: dir > 0 ? i : i + 1, dir, t: Math.random() * Math.hypot(b[0] - a[0], b[1] - a[1]), v: v.vmax * 0.6, stopT: 0 });
      return true;
    }
    return false;
  }

  _segment(v, ways) {
    const w = ways[v.w], a = w.pts[v.i], b = w.pts[v.i + v.dir];
    return b ? { a, b, L: Math.hypot(b[0] - a[0], b[1] - a[1]) || 0.01, w } : null;
  }

  // arrivato a un nodo: prosegue o svolta su un'altra strada che parte da lì
  _next(v, ways, graph) {
    const w = ways[v.w];
    const ni = v.i + v.dir;
    const node = w.pts[ni];
    const opts = [];
    for (const e of graph.nodes.get(key(node)) || []) {
      const ww = ways[e.w];
      for (const d of [1, -1]) {
        if (ww.oneway === 1 && d < 0) continue;
        if (ww.oneway === -1 && d > 0) continue;
        if (!ww.pts[e.i + d]) continue;
        if (e.w === v.w && d === -v.dir) continue;
        opts.push({ w: e.w, i: e.i, dir: d, same: e.w === v.w });
      }
    }
    if (!opts.length) {
      if (!w.oneway && w.pts[ni - v.dir]) { v.i = ni; v.dir = -v.dir; v.t = 0; v.v *= 0.2; return true; }
      return false;
    }
    const same = opts.find((p) => p.same);
    const pick = same && Math.random() < 0.6 ? same : opts[Math.floor(Math.random() * opts.length)];
    v.w = pick.w; v.i = pick.i; v.dir = pick.dir; v.t = 0;
    if (!pick.same) v.v *= 0.55;
    return true;
  }

  _pose(v, ways) {
    const s = this._segment(v, ways);
    if (!s) return null;
    const f = Math.min(1, v.t / s.L);
    const dx = (s.b[0] - s.a[0]) / s.L, dz = (s.b[1] - s.a[1]) / s.L;
    const lane = s.w.oneway || v.kind === 'tram' ? (v.kind === 'tram' ? 0 : 0.6) : Math.min(1.7, s.w.width * 0.22 + 0.2);
    const x = s.a[0] + (s.b[0] - s.a[0]) * f + dz * -lane, z = s.a[1] + (s.b[1] - s.a[1]) * f + -dx * -lane;
    return { x, z, yaw: Math.atan2(dx, dz), dx, dz, y: s.w.y };
  }

  update(dt, player, night, active) {
    this.night = night;
    const lightOn = night > 0.35;
    this.headMat.color.setScalar(lightOn ? 3.2 : 0.55);
    this.tailMat.color.setRGB(lightOn ? 2.2 : 0.5, 0.02, 0.02);
    const P = player;
    if (!active) { for (const m of [...Object.values(this.cm), ...Object.values(this.tm)]) m.count = 0; return; }
    while (this.cars.length < this.nCars) this.cars.push({ kind: 'car', vmax: 8 + Math.random() * 5, color: PAINT[this.cars.length % PAINT.length], w: -1 });
    while (this.trams.length < this.nTrams) this.trams.push({ kind: 'tram', vmax: 7.5, w: -1 });
    const all = [];
    for (const [list, ways, graph, maxR] of [[this.cars, this.carWays, this.cg, 190], [this.trams, this.tramWays, this.tg, 320]]) {
      for (const v of list) {
        if (v.cool > 0) { v.cool -= dt; continue; }
        if (v.w < 0 || !v.pose || Math.hypot(v.pose.x - P.x, v.pose.z - P.z) > maxR + 40) {
          if (!this._spawn(v, ways, graph, P, v.w < 0 ? 15 : 80, maxR)) { v.w = -1; v.pose = null; continue; }
        }
        // davanti c'è qualcuno? (persone, giocatore, altri veicoli)
        let want = v.vmax;
        const pose = v.pose || this._pose(v, ways);
        if (pose) {
          const look = v.kind === 'tram' ? 14 : 9;
          const ax = pose.x + pose.dx * (look * 0.5 + (v.kind === 'tram' ? this.tramLen / 2 : 2)), az = pose.z + pose.dz * (look * 0.5 + (v.kind === 'tram' ? this.tramLen / 2 : 2));
          const blockR = look * 0.55;
          if (Math.hypot(P.x - ax, P.z - az) < blockR) {
            want = 0;
            if (v.v > 2.5 && !v.warned) { v.warned = true; (v.kind === 'tram' ? this.bell : this.honk)?.(pose.x, pose.z); }
          } else v.warned = false;
          for (const u of all) if (u.pose && Math.hypot(u.pose.x - ax, u.pose.z - az) < blockR * 0.8 && (u.pose.dx * pose.dx + u.pose.dz * pose.dz) > -0.2) want = Math.min(want, u.v * 0.8);
        }
        v.v += Math.max(-9 * dt, Math.min(2.6 * dt, want - v.v));
        if (v.v < 0) v.v = 0;
        v.t += v.v * dt;
        let s = this._segment(v, ways), guard = 0;
        while (s && v.t > s.L && guard++ < 8) {
          v.t -= s.L;
          if (!this._next(v, ways, graph)) { v.w = -1; s = null; break; }
          s = this._segment(v, ways);
        }
        if (v.w < 0 || !s) { v.pose = null; continue; }
        v.pose = this._pose(v, ways);
        v.spin = (v.spin || 0) + v.v * dt / 0.31;
        all.push(v);
      }
    }
    // istanze
    const o = this._o;
    let nc = 0;
    for (const v of this.cars) {
      if (!v.pose) continue;
      o.position.set(v.pose.x, v.pose.y, v.pose.z);
      // assetto: la macchina si abbassa in frenata
      o.rotation.set((v.lastV !== undefined ? Math.max(-0.03, Math.min(0.03, (v.lastV - v.v) * 0.08)) : 0), v.pose.yaw, 0);
      v.lastV = v.v;
      o.updateMatrix();
      for (const m of Object.values(this.cm)) m.setMatrixAt(nc, o.matrix);
      this.cm.body.setColorAt(nc, v.color);
      nc++;
    }
    for (const m of Object.values(this.cm)) { m.count = nc; m.instanceMatrix.needsUpdate = true; }
    if (this.cm.body.instanceColor) this.cm.body.instanceColor.needsUpdate = true;
    let nt = 0;
    for (const v of this.trams) {
      if (!v.pose) continue;
      o.position.set(v.pose.x, v.pose.y, v.pose.z); o.rotation.set(0, v.pose.yaw, 0); o.updateMatrix();
      for (const m of Object.values(this.tm)) m.setMatrixAt(nt, o.matrix);
      nt++;
    }
    for (const m of Object.values(this.tm)) { m.count = nt; m.instanceMatrix.needsUpdate = true; }
    this.tm.glass.material.emissive.setRGB(lightOn ? 0.5 : 0, lightOn ? 0.42 : 0, lightOn ? 0.3 : 0);
  }

  // i veicoli spingono via il giocatore invece di attraversarlo
  pushOut(pos) {
    for (const list of [this.cars, this.trams]) for (const v of list) {
      if (!v.pose) continue;
      const [hw, hl] = v.kind === 'tram' ? this.tramHalf : this.carHalf;
      const dx = pos.x - v.pose.x, dz = pos.z - v.pose.z;
      const lz = dx * v.pose.dx + dz * v.pose.dz, lx = dx * v.pose.dz - dz * v.pose.dx;
      const r = 0.35;
      if (Math.abs(lx) < hw + r && Math.abs(lz) < hl + r) {
        const px = hw + r - Math.abs(lx), pz = hl + r - Math.abs(lz);
        if (px < pz) { const s = Math.sign(lx) || 1; pos.x += v.pose.dz * px * s; pos.z += -v.pose.dx * px * s; }
        else { const s = Math.sign(lz) || 1; pos.x += v.pose.dx * pz * s; pos.z += v.pose.dz * pz * s; }
      }
    }
  }

  positions() { return [...this.cars, ...this.trams].filter((v) => v.pose).map((v) => ({ x: v.pose.x, z: v.pose.z, tram: v.kind === 'tram' })); }
}
