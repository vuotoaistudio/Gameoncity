// Meteo reale da Open-Meteo; se la fonte non risponde usa un meteo simulato e lo dichiara.

export const WMO_IT = {
  0: 'sereno', 1: 'quasi sereno', 2: 'poco nuvoloso', 3: 'coperto', 45: 'nebbia', 48: 'nebbia con brina',
  51: 'pioggerella leggera', 53: 'pioggerella', 55: 'pioggerella fitta', 56: 'pioggerella gelata', 57: 'pioggerella gelata',
  61: 'pioggia leggera', 63: 'pioggia', 65: 'pioggia forte', 66: 'pioggia gelata', 67: 'pioggia gelata forte',
  71: 'neve leggera', 73: 'neve', 75: 'neve forte', 77: 'granelli di neve', 80: 'rovesci leggeri', 81: 'rovesci',
  82: 'rovesci violenti', 85: 'rovesci di neve', 86: 'rovesci di neve forti', 95: 'temporale', 96: 'temporale con grandine', 99: 'temporale con grandine forte'
};

// Medie mensili indicative di Milano (temperatura °C, probabilità di pioggia, nuvolosità)
const CLIMATE = [
  [3, 0.22, 60], [5, 0.2, 55], [10, 0.22, 55], [14, 0.3, 55], [18, 0.32, 50], [23, 0.27, 40],
  [25, 0.2, 30], [24, 0.25, 35], [20, 0.25, 45], [14, 0.33, 60], [8, 0.3, 70], [4, 0.25, 70]
];

function hash(n) { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); }

export function simulateWeather(date) {
  const m = date.getUTCMonth(), day = Math.floor(date.getTime() / 86400000), hour = date.getUTCHours();
  const [t, pRain, cloud] = CLIMATE[m];
  const block = day * 4 + Math.floor(hour / 6);
  const rainy = hash(block) < pRain;
  const foggy = !rainy && (m >= 9 || m <= 1) && hash(block + 7) < 0.25 && (hour < 9 || hour > 18);
  const clouds = rainy ? 85 + hash(block + 1) * 15 : Math.min(100, cloud * (0.4 + hash(block + 2) * 1.2));
  const precip = rainy ? 0.3 + hash(block + 3) * 3 : 0;
  const code = rainy ? (precip > 2 ? 65 : precip > 1 ? 63 : 61) : foggy ? 45 : clouds > 85 ? 3 : clouds > 50 ? 2 : clouds > 20 ? 1 : 0;
  return {
    source: 'simulato', temperature: Math.round(t + (hash(block + 4) - 0.5) * 6), precipitation: precip,
    cloudCover: Math.round(clouds), windSpeed: Math.round(3 + hash(block + 5) * 15), windDirection: Math.round(hash(block + 6) * 360),
    visibility: foggy ? 300 + hash(block + 8) * 700 : rainy ? 6000 : 20000, weatherCode: code, updated: date.toISOString()
  };
}

// Meteo reale direttamente da Open-Meteo (senza chiave). Se la rete lo blocca, meteo simulato dichiarato.
export async function fetchWeather(center) {
  try {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 6000);
    const q = `latitude=${center.lat}&longitude=${center.lon}&current=temperature_2m,precipitation,cloud_cover,wind_speed_10m,wind_direction_10m,visibility,weather_code`;
    const r = await fetch('https://api.open-meteo.com/v1/forecast?' + q, { signal: ctl.signal });
    clearTimeout(timer);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const c = (await r.json()).current;
    if (!c || typeof c.temperature_2m !== 'number') throw new Error('risposta non valida');
    return {
      source: 'open-meteo', temperature: Math.round(c.temperature_2m), precipitation: c.precipitation || 0,
      cloudCover: c.cloud_cover ?? 30, windSpeed: c.wind_speed_10m ?? 5, windDirection: c.wind_direction_10m ?? 0,
      visibility: Math.min(30000, c.visibility ?? 20000), weatherCode: c.weather_code ?? 0, updated: new Date().toISOString()
    };
  } catch (err) {
    return simulateWeather(new Date());
  }
}

export function describeWeather(w) {
  return (WMO_IT[w.weatherCode] || 'variabile') + ' · ' + w.temperature + '°C';
}

// meteo scelto dal giocatore nelle impostazioni
export function presetWeather(kind) {
  const base = { source: 'scelto', temperature: 16, precipitation: 0, cloudCover: 10, windSpeed: 6, windDirection: 220, visibility: 25000, weatherCode: 0, updated: new Date().toISOString() };
  const P = {
    clear: {},
    clouds: { cloudCover: 75, weatherCode: 3 },
    rain: { precipitation: 2.2, cloudCover: 95, weatherCode: 63, visibility: 6000, windSpeed: 14, temperature: 12 },
    storm: { precipitation: 5, cloudCover: 100, weatherCode: 95, visibility: 3500, windSpeed: 30, temperature: 14 },
    fog: { cloudCover: 90, weatherCode: 45, visibility: 450, windSpeed: 2, temperature: 7 },
    snow: { precipitation: 1.2, cloudCover: 100, weatherCode: 73, visibility: 2500, windSpeed: 5, temperature: -1 }
  }[kind];
  return P ? Object.assign(base, P) : null;
}
