const CACHE_VERSION = 'vid-mobile-v1.2.2';
const SHELL_CACHE = CACHE_VERSION + '-shell';
const RUNTIME_CACHE = CACHE_VERSION + '-runtime';
const CORE_ASSETS = [
  "/",
  "/index.html",
  "/manifest.webmanifest",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
  "/icons/icon-maskable-512.png",
  "/data/cities/index.json",
  "/src/fx/mirror.js",
  "/src/fx/post.js",
  "/src/fx/props.js",
  "/src/fx/rain.js",
  "/src/fx/sky.js",
  "/src/fx/vehicles.js",
  "/src/main.js",
  "/src/net/avatars.js",
  "/src/net/client.js",
  "/src/net/voice.js",
  "/src/player/avatar.js",
  "/src/player/controller.js",
  "/src/player/human.js",
  "/src/systems/audio.js",
  "/src/systems/combat.js",
  "/src/systems/driving.js",
  "/src/systems/economy.js",
  "/src/systems/jobs.js",
  "/src/systems/locale.js",
  "/src/systems/realestate.js",
  "/src/systems/story.js",
  "/src/systems/substances.js",
  "/src/ui/life.js",
  "/src/ui/minimap.js",
  "/src/world/atmosphere.js",
  "/src/world/cityMesh.js",
  "/src/world/dream.js",
  "/src/world/drift.js",
  "/src/world/npc.js",
  "/src/world/osm.js",
  "/src/world/shops.js",
  "/src/world/sun.js",
  "/src/world/traffic.js",
  "/src/world/weather.js",
  "/lib/addons/math/SimplexNoise.js",
  "/lib/addons/postprocessing/EffectComposer.js",
  "/lib/addons/postprocessing/GTAOPass.js",
  "/lib/addons/postprocessing/MaskPass.js",
  "/lib/addons/postprocessing/OutputPass.js",
  "/lib/addons/postprocessing/Pass.js",
  "/lib/addons/postprocessing/RenderPass.js",
  "/lib/addons/postprocessing/ShaderPass.js",
  "/lib/addons/postprocessing/UnrealBloomPass.js",
  "/lib/addons/shaders/CopyShader.js",
  "/lib/addons/shaders/GTAOShader.js",
  "/lib/addons/shaders/LuminosityHighPassShader.js",
  "/lib/addons/shaders/OutputShader.js",
  "/lib/addons/shaders/PoissonDenoiseShader.js",
  "/lib/three.module.js"
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(SHELL_CACHE).then((cache) => cache.addAll(CORE_ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key.startsWith('vid-mobile-') && key !== SHELL_CACHE && key !== RUNTIME_CACHE).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api/') || url.pathname === '/ws') return;
  if (req.mode === 'navigate') {
    event.respondWith(fetch(req).then((response) => {
      if (response.ok) caches.open(RUNTIME_CACHE).then((cache) => cache.put('/index.html', response.clone()));
      return response;
    }).catch(async () => (await caches.match(req)) || (await caches.match('/index.html'))));
    return;
  }
  if (/\.(?:json)$/.test(url.pathname) && url.pathname.startsWith('/data/cities/')) {
    event.respondWith(fetch(req).then((response) => {
      if (response.ok) caches.open(RUNTIME_CACHE).then((cache) => cache.put(req, response.clone()));
      return response;
    }).catch(async () => (await caches.match(req)) || new Response('{"error":"offline"}', { status: 503, headers: { 'Content-Type': 'application/json' } })));
    return;
  }
  event.respondWith(caches.match(req).then((cached) => cached || fetch(req).then((response) => {
    if (response.ok && response.type === 'basic') caches.open(RUNTIME_CACHE).then((cache) => cache.put(req, response.clone()));
    return response;
  })));
});
